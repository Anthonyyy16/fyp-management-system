<?php
/**
 * 
 */

if (!defined('GOOGLE_CLIENT_ID')) {
    require_once 'google_config.php';
}

require_once 'db_connect.php';

/**
 * 
 * 
 * @return array ['success' => bool, 'meeting_link' => string, 'event_id' => string, 'message' => string]
 */
function createGoogleMeetEvent($user_id, $title, $description, $start_time, $end_time, $attendees = []) {
    global $conn;
    
    try {
        $access_token = getAccessToken($user_id);
        
        if (!$access_token) {
            error_log('User ' . $user_id . ' has not authorized Google Calendar');
            return [
                'success' => false,
                'meeting_link' => null,
                'event_id' => null,
                'message' => 'Google authorization required. Please authorize Google Calendar first.'
            ];
        }
        
        $stmt = $conn->prepare("SELECT google_email FROM users WHERE id = ?");
        if (!$stmt) {
            throw new Exception('Database prepare error: ' . $conn->error);
        }
        
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user_data = $result->fetch_assoc();
        $stmt->close();
        
        if (!$user_data || !$user_data['google_email']) {
            error_log('User ' . $user_id . ' email not found in database');
            return [
                'success' => false,
                'meeting_link' => null,
                'event_id' => null,
                'message' => 'User Google email not found'
            ];
        }
        
        $organizer_email = $user_data['google_email'];
        
        
        $attendees_list = [];
        foreach ($attendees as $email) {
            
            if ($email !== $organizer_email) {
                $attendees_list[] = [
                    'email' => $email,
                    'displayName' => explode('@', $email)[0],  
                    'responseStatus' => 'needsAction'
                ];
            }
        }
        
        
        if (empty($attendees_list)) {
            $attendees_list[] = [
                'email' => $organizer_email,
                'displayName' => explode('@', $organizer_email)[0],
                'responseStatus' => 'accepted'
            ];
        }
        
        
        
        $safe_request_id = 'meet_' . bin2hex(random_bytes(8));
        
        
        
        $event = [
            'summary' => $title,
            'description' => $description,
            'start' => [
                'dateTime' => $start_time,
                'timeZone' => GOOGLE_CALENDAR_TIMEZONE
            ],
            'end' => [
                'dateTime' => $end_time,
                'timeZone' => GOOGLE_CALENDAR_TIMEZONE
            ],
            'attendees' => $attendees_list,
            'conferenceData' => [
                'createRequest' => [
                    'requestId' => $safe_request_id  
                ]
            ]
        ];
        
        error_log('Creating Google Meet event: title=' . $title . ', organizer=' . $organizer_email);
        error_log('Event data: ' . json_encode($event));
        
        
        $ch = curl_init('https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1');
        
        $json_event = json_encode($event);
        error_log('JSON Event: ' . $json_event);
        
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS => $json_event,
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);
        
        if ($curl_error) {
            throw new Exception('cURL Error: ' . $curl_error);
        }
        
        if ($http_code === 401) {
            error_log('Access token expired for user ' . $user_id . ', attempting refresh');
            
            $token_file = TOKENS_DIR . DIRECTORY_SEPARATOR . 'user_' . intval($user_id) . '_token.json';
            if (file_exists($token_file)) {
                $token_data = json_decode(file_get_contents($token_file), true);
                
                if (isset($token_data['refresh_token'])) {
                    $new_token = refreshAccessToken($token_data['refresh_token']);
                    if ($new_token) {
                        saveTokenData($user_id, $new_token);
                        
                        
                        return createGoogleMeetEvent($user_id, $title, $description, $start_time, $end_time, $attendees);
                    }
                }
            }
            
            return [
                'success' => false,
                'meeting_link' => null,
                'event_id' => null,
                'message' => 'Google authorization expired. Please re-authorize.'
            ];
        }
        
        if ($http_code !== 200 && $http_code !== 201) {
            $error_data = json_decode($response, true);
            $error_msg = $error_data['error']['message'] ?? 'Unknown error';
            $error_detail = json_encode($error_data['error'] ?? []);
            error_log('Google Calendar API Error Response: ' . $error_detail);
            throw new Exception('Google API Error (HTTP ' . $http_code . '): ' . $error_msg);
        }
        
        $event_data = json_decode($response, true);
        
        if (!isset($event_data['id'])) {
            throw new Exception('No event ID in API response: ' . json_encode($event_data));
        }
        
        $meeting_link = null;
        if (isset($event_data['conferenceData']['entryPoints'])) {
            foreach ($event_data['conferenceData']['entryPoints'] as $entry) {
                if ($entry['entryPointType'] === 'video') {
                    $meeting_link = $entry['uri'];
                    break;
                }
            }
        }
        
        if (!$meeting_link && isset($event_data['hangoutLink'])) {
            $meeting_link = $event_data['hangoutLink'];
        }
        
        if (!$meeting_link) {
            throw new Exception('No Google Meet link found in response');
        }
        
        error_log('Google Meet event created successfully: event_id=' . $event_data['id'] . ', link=' . $meeting_link);
        
        return [
            'success' => true,
            'meeting_link' => $meeting_link,
            'event_id' => $event_data['id'],
            'message' => 'Google Meet event created successfully',
            'start_time' => $event_data['start']['dateTime'] ?? $event_data['start']['date'] ?? null,
            'end_time' => $event_data['end']['dateTime'] ?? $event_data['end']['date'] ?? null,
        ];
        
    } catch (Exception $e) {
        error_log('Error creating Google Meet event: ' . $e->getMessage());
        
        return [
            'success' => false,
            'meeting_link' => null,
            'event_id' => null,
            'message' => 'Error: ' . $e->getMessage()
        ];
    }
}

/**
 * 
 * 
 * @return array ['success' => bool, 'message' => string]
 */
function deleteGoogleMeetEvent($user_id, $event_id) {
    global $conn;
    
    try {
        
        $access_token = getAccessToken($user_id);
        
        if (!$access_token) {
            return [
                'success' => false,
                'message' => 'Google authorization required'
            ];
        }
        
        
        $ch = curl_init('https://www.googleapis.com/calendar/v3/calendars/primary/events/' . urlencode($event_id));
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => 'DELETE',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $access_token,
            ],
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 204 || $http_code === 200) {
            error_log('Google Meet event deleted: event_id=' . $event_id);
            return [
                'success' => true,
                'message' => 'Event deleted successfully'
            ];
        } else {
            throw new Exception('Failed to delete event (HTTP ' . $http_code . ')');
        }
        
    } catch (Exception $e) {
        error_log('Error deleting Google Meet event: ' . $e->getMessage());
        
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}

/**
 * 
 * 
 * @return array ['success' => bool, 'meeting_link' => string, 'event_id' => string, 'message' => string]
 */
function updateGoogleMeetEvent($user_id, $event_id, $updates = []) {
    global $conn;
    
    try {
        
        $access_token = getAccessToken($user_id);
        
        if (!$access_token) {
            return [
                'success' => false,
                'message' => 'Google authorization required'
            ];
        }
        
        
        $ch = curl_init('https://www.googleapis.com/calendar/v3/calendars/primary/events/' . urlencode($event_id));
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $access_token,
            ],
        ]);
        
        $response = curl_exec($ch);
        curl_close($ch);
        
        $event = json_decode($response, true);
        
        if (!isset($event['id'])) {
            throw new Exception('Event not found');
        }
        
        
        $event = array_merge($event, $updates);
        
        
        $ch = curl_init('https://www.googleapis.com/calendar/v3/calendars/primary/events/' . urlencode($event_id));
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => 'PUT',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $access_token,
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS => json_encode($event),
        ]);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code !== 200) {
            throw new Exception('Failed to update event (HTTP ' . $http_code . ')');
        }
        
        $updated_event = json_decode($response, true);
        
        $meeting_link = null;
        if (isset($updated_event['conferenceData']['entryPoints'])) {
            foreach ($updated_event['conferenceData']['entryPoints'] as $entry) {
                if ($entry['entryPointType'] === 'video') {
                    $meeting_link = $entry['uri'];
                    break;
                }
            }
        }
        
        if (!$meeting_link && isset($updated_event['hangoutLink'])) {
            $meeting_link = $updated_event['hangoutLink'];
        }
        
        error_log('Google Meet event updated: event_id=' . $event_id);
        
        return [
            'success' => true,
            'meeting_link' => $meeting_link,
            'event_id' => $updated_event['id'],
            'message' => 'Event updated successfully'
        ];
        
    } catch (Exception $e) {
        error_log('Error updating Google Meet event: ' . $e->getMessage());
        
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}

?>
