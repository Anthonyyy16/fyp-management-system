<?php
session_start();

require_once 'db_connect.php';



// Gemini API configuration
$GEMINI_API_KEY = 'AIzaSyAUbaoqgmmaeOD0V7L7PtoZbgnd14wsEJI';
$GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

// Function to test Gemini API
function testGeminiAPI($message) {
    global $GEMINI_API_KEY, $GEMINI_API_URL;
    
    $data = [
        'contents' => [
            [
                'parts' => [
                    [
                        'text' => $message
                    ]
                ]
            ]
        ]
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $GEMINI_API_URL . '?key=' . $GEMINI_API_KEY);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json'
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    return [
        'response' => $response,
        'http_code' => $http_code,
        'curl_error' => $curl_error,
        'raw_data' => $data
    ];
}

// Handle AJAX test request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'test_api') {
    header('Content-Type: application/json');
    
    $message = trim($_POST['message'] ?? 'Hello, can you respond to this test message?');
    
    if (empty($message)) {
        echo json_encode(['success' => false, 'error' => 'Message cannot be empty']);
        exit;
    }
    
    $result = testGeminiAPI($message);
    
    echo json_encode([
        'success' => true,
        'api_result' => $result,
        'formatted_response' => null
    ]);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gemini API Test - GIGABYTE</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: #f5f5f5;
            padding: 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h1 {
            color: #333;
            margin-bottom: 10px;
        }

        .header p {
            color: #666;
        }

        .test-section {
            margin-bottom: 30px;
        }

        .test-section h3 {
            color: #333;
            margin-bottom: 15px;
            padding: 10px;
            background: #f8f9fa;
            border-left: 4px solid #0381fe;
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #333;
        }

        .input-group input,
        .input-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
        }

        .input-group textarea {
            height: 100px;
            resize: vertical;
        }

        .btn {
            background: #0381fe;
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s;
        }

        .btn:hover {
            background: #0266d1;
            transform: translateY(-2px);
        }

        .btn:disabled {
            background: #bdc3c7;
            cursor: not-allowed;
            transform: none;
        }

        .result-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }

        .result-item {
            margin-bottom: 15px;
        }

        .result-item strong {
            color: #333;
            display: block;
            margin-bottom: 5px;
        }

        .code-block {
            background: #2d3748;
            color: #e2e8f0;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            white-space: pre-wrap;
        }

        .status {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }

        .status.success {
            background: #d4edda;
            color: #155724;
        }

        .status.error {
            background: #f8d7da;
            color: #721c24;
        }

        .status.warning {
            background: #fff3cd;
            color: #856404;
        }

        .loading {
            display: none;
            text-align: center;
            padding: 20px;
            color: #666;
        }

        .loading i {
            font-size: 24px;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #0381fe;
            text-decoration: none;
            font-weight: 500;
        }

        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="chatbot.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to Chatbot
        </a>

        <div class="header">
            <h1><i class="fas fa-robot"></i> Gemini API Test</h1>
            <p>Test the Gemini API directly to see if it's working properly</p>
        </div>

        <div class="test-section">
            <h3>API Configuration</h3>
            <div class="result-item">
                <strong>API Key:</strong> 
                <code><?php echo substr($GEMINI_API_KEY, 0, 10) . '...' . substr($GEMINI_API_KEY, -5); ?></code>
            </div>
            <div class="result-item">
                <strong>API URL:</strong> 
                <code><?php echo $GEMINI_API_URL; ?></code>
            </div>
        </div>

        <div class="test-section">
            <h3>Send Test Message</h3>
            <div class="input-group">
                <label for="testMessage">Test Message:</label>
                <textarea id="testMessage" placeholder="Enter your test message here...">Hello! Can you please respond with a simple greeting? This is a test message to verify the API is working.</textarea>
            </div>
            <button class="btn" onclick="testAPI()" id="testBtn">
                <i class="fas fa-paper-plane"></i> Send Test Message
            </button>
        </div>

        <div class="loading" id="loading">
            <i class="fas fa-spinner"></i>
            <p>Testing API connection...</p>
        </div>

        <div class="result-section" id="results" style="display: none;">
            <h3>Test Results</h3>
            <div id="resultContent"></div>
        </div>
    </div>

    <script>
        async function testAPI() {
            const message = document.getElementById('testMessage').value.trim();
            const testBtn = document.getElementById('testBtn');
            const loading = document.getElementById('loading');
            const results = document.getElementById('results');
            const resultContent = document.getElementById('resultContent');

            if (!message) {
                alert('Please enter a test message');
                return;
            }

            testBtn.disabled = true;
            loading.style.display = 'block';
            results.style.display = 'none';

            try {
                const formData = new FormData();
                formData.append('action', 'test_api');
                formData.append('message', message);

                const response = await fetch('ai.php', {
                    method: 'POST',
                    body: formData
                });

                const data = await response.json();
                
                loading.style.display = 'none';
                results.style.display = 'block';

                if (data.success) {
                    const apiResult = data.api_result;
                    
                    let html = `
                        <div class="result-item">
                            <strong>HTTP Status Code:</strong>
                            <span class="status ${apiResult.http_code === 200 ? 'success' : 'error'}">
                                ${apiResult.http_code}
                            </span>
                        </div>
                    `;

                    if (apiResult.curl_error) {
                        html += `
                            <div class="result-item">
                                <strong>CURL Error:</strong>
                                <span class="status error">${apiResult.curl_error}</span>
                            </div>
                        `;
                    }

                    html += `
                        <div class="result-item">
                            <strong>Raw API Response:</strong>
                            <div class="code-block">${escapeHtml(apiResult.response)}</div>
                        </div>
                    `;

                    if (apiResult.http_code === 200) {
                        try {
                            const responseObj = JSON.parse(apiResult.response);
                            if (responseObj.candidates && responseObj.candidates[0] && 
                                responseObj.candidates[0].content && 
                                responseObj.candidates[0].content.parts && 
                                responseObj.candidates[0].content.parts[0]) {
                                
                                const aiResponse = responseObj.candidates[0].content.parts[0].text;
                                html += `
                                    <div class="result-item">
                                        <strong>✅ AI Response (Success!):</strong>
                                        <div style="background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin-top: 10px;">
                                            ${escapeHtml(aiResponse)}
                                        </div>
                                    </div>
                                `;
                            } else {
                                html += `
                                    <div class="result-item">
                                        <strong>❌ Unexpected Response Format:</strong>
                                        <div style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin-top: 10px;">
                                            The API responded but the format is not as expected.
                                        </div>
                                    </div>
                                `;
                            }
                        } catch (e) {
                            html += `
                                <div class="result-item">
                                    <strong>❌ JSON Parse Error:</strong>
                                    <div style="background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin-top: 10px;">
                                        Could not parse API response as JSON: ${e.message}
                                    </div>
                                </div>
                            `;
                        }
                    }

                    html += `
                        <div class="result-item">
                            <strong>Request Data Sent:</strong>
                            <div class="code-block">${JSON.stringify(apiResult.raw_data, null, 2)}</div>
                        </div>
                    `;

                    resultContent.innerHTML = html;
                } else {
                    resultContent.innerHTML = `
                        <div class="result-item">
                            <strong>❌ Test Failed:</strong>
                            <span class="status error">${data.error || 'Unknown error'}</span>
                        </div>
                    `;
                }
            } catch (error) {
                loading.style.display = 'none';
                results.style.display = 'block';
                resultContent.innerHTML = `
                    <div class="result-item">
                        <strong>❌ JavaScript Error:</strong>
                        <span class="status error">${error.message}</span>
                    </div>
                `;
            } finally {
                testBtn.disabled = false;
            }
        }

        function escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        // Auto-test on page load with a simple message
        window.onload = function() {
            document.getElementById('testMessage').value = 'Hi! Please respond with a simple greeting to test the API.';
        };
    </script>
</body>
</html>