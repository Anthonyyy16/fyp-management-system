-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2025-12-12 18:00:45
-- 服务器版本： 10.4.32-MariaDB
-- PHP 版本： 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `fypms`
--

-- --------------------------------------------------------

--
-- 表的结构 `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `batch_year` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='System-wide announcements.';

--
-- 转存表中的数据 `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `content`, `created_by`, `created_at`, `batch_year`) VALUES
(1, 'Welcome FYP 2024/2025!', 'Welcome! Please check deadlines.', 9, '2025-11-08 10:12:04', '2023/2024'),
(2, 'Proposal Briefing', 'Briefing this Friday 3 PM, main hall. Compulsory.', 8, '2025-11-08 10:12:04', '2024/2025'),
(3, 'Welcome FYP 2025/2026', 'Briefing this Friday 2 PM, DTAR hall. Compulsory.', 9, '2025-11-28 07:09:37', '2025/2026');

-- --------------------------------------------------------

--
-- 表的结构 `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `appointment_start` timestamp NULL DEFAULT NULL,
  `appointment_end` timestamp NULL DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','confirmed','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `comment` text DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `google_meeting_link` varchar(500) DEFAULT NULL,
  `google_calendar_event_id` varchar(255) DEFAULT NULL,
  `google_sync_status` enum('pending','synced','failed','deleted') DEFAULT 'pending',
  `google_sync_error` text DEFAULT NULL,
  `cancellation_reason` text DEFAULT NULL COMMENT 'Reason for cancellation',
  `reminder_sent` tinyint(1) DEFAULT 0 COMMENT 'Reminder sent flag',
  `reminder_sent_at` timestamp NULL DEFAULT NULL COMMENT 'When reminder was sent'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `batch_committees`
--

CREATE TABLE `batch_committees` (
  `id` int(11) NOT NULL,
  `batch_year` varchar(20) NOT NULL,
  `committee_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `batch_committees`
--

INSERT INTO `batch_committees` (`id`, `batch_year`, `committee_id`, `created_at`) VALUES
(1, '2025/2026', 5, '2025-11-30 09:46:30'),
(2, '2024/2025', 7, '2025-11-30 10:21:47'),
(3, '2025/2026', 8, '2025-11-30 14:40:07');

-- --------------------------------------------------------

--
-- 表的结构 `chat_contacts`
--

CREATE TABLE `chat_contacts` (
  `user_id` int(11) NOT NULL COMMENT 'FK to users.id (The person adding)',
  `contact_user_id` int(11) NOT NULL COMMENT 'FK to users.id (The person being added)',
  `is_blocked` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores manually added chat contacts.';

-- --------------------------------------------------------

--
-- 表的结构 `chat_groups`
--

CREATE TABLE `chat_groups` (
  `id` int(11) NOT NULL,
  `group_name` varchar(100) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `google_meeting_link` varchar(500) DEFAULT NULL,
  `google_calendar_event_id` varchar(255) DEFAULT NULL,
  `meeting_scheduled_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `chat_group_members`
--

CREATE TABLE `chat_group_members` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `chat_meetings`
--

CREATE TABLE `chat_meetings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `contact_user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `google_meeting_link` varchar(500) DEFAULT NULL,
  `google_calendar_event_id` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) DEFAULT NULL,
  `message` text NOT NULL,
  `text` longtext DEFAULT NULL COMMENT 'Message text (for search optimization)',
  `file_path` varchar(255) DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `edit_timestamp` timestamp NULL DEFAULT NULL COMMENT 'When message was last edited',
  `is_edited` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Whether message has been edited',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_by_sender` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Sender deleted this message',
  `deleted_by_receiver` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Receiver deleted this message',
  `is_group_message` tinyint(1) NOT NULL DEFAULT 0,
  `group_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores chat messages between users.';

-- --------------------------------------------------------

--
-- 表的结构 `courses`
--

CREATE TABLE `courses` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'e.g., Software Engineering',
  `course_code` varchar(20) DEFAULT NULL COMMENT 'e.g., SE',
  `faculty_id` int(11) NOT NULL COMMENT 'FK to faculties.id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `courses`
--

INSERT INTO `courses` (`id`, `name`, `course_code`, `faculty_id`) VALUES
(1, 'Software Engineering', 'SE', 1),
(2, 'Cybersecurity', 'CS', 1),
(3, 'Enterprise Information System', 'EIS', 1),
(4, 'Mechanical Engineering', 'ME', 2);

-- --------------------------------------------------------

--
-- 表的结构 `deadlines`
--

CREATE TABLE `deadlines` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `due_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `batch_year` varchar(20) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores project submission deadlines.';

--
-- 转存表中的数据 `deadlines`
--

INSERT INTO `deadlines` (`id`, `title`, `description`, `due_date`, `batch_year`, `created_by`, `created_at`) VALUES
(1, 'Proposal Submission', 'Submit final proposal PDF.', '2026-11-30 15:59:59', '2024/2025', 9, '2025-11-08 10:12:04'),
(2, 'Interim Report', 'Submit interim report.', '2026-01-30 15:59:59', '2024/2025', 9, '2025-11-08 10:12:04'),
(3, 'Final Report', 'Final report and code.', '2026-04-10 15:59:59', '2024/2025', 7, '2025-11-08 10:12:04');

-- --------------------------------------------------------

--
-- 表的结构 `downloadable_files`
--

CREATE TABLE `downloadable_files` (
  `id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `file_size` int(11) DEFAULT 0,
  `download_count` int(11) DEFAULT 0,
  `upload_date` datetime NOT NULL,
  `batch_year` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `faculties`
--

CREATE TABLE `faculties` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT 'e.g., Faculty of Computer Science and IT',
  `faculty_code` varchar(20) DEFAULT NULL COMMENT 'e.g., FCSIT'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `faculties`
--

INSERT INTO `faculties` (`id`, `name`, `faculty_code`) VALUES
(1, 'Faculty of Computer Science and IT', 'FOCS'),
(2, 'Faculty of Engineering', 'FOE');

-- --------------------------------------------------------

--
-- 表的结构 `fyp_titles`
--

CREATE TABLE `fyp_titles` (
  `id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `batch_year` varchar(50) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `fyp_titles`
--

INSERT INTO `fyp_titles` (`id`, `title`, `description`, `batch_year`, `created_by`, `is_active`, `created_at`) VALUES
(3, 'AI-Powered Healthcare Diagnosis System', 'Develop an AI system that can assist in medical diagnosis using machine learning algorithms.', '2025/2026', 5, 1, '2025-11-29 19:04:35'),
(4, 'Blockchain-based Supply Chain Management', 'Create a transparent and secure supply chain management system using blockchain technology.', '2024/2025', 5, 1, '2025-11-29 19:04:35'),
(5, 'IoT Smart Home Automation System', 'Design and implement a comprehensive smart home system using Internet of Things devices.', '2023/2024', 5, 1, '2025-11-29 19:04:35'),
(6, 'E-commerce Recommendation Engine', 'Build a personalized product recommendation system for online shopping platforms.', '2024/2025', 6, 1, '2025-11-29 19:04:35'),
(7, 'Cybersecurity Threat Detection System', 'Develop an intelligent system to detect and prevent cybersecurity threats in real-time.', '2023/2024', 7, 1, '2025-11-29 19:04:35'),
(8, 'Mobile Learning Application for Programming', 'Create an interactive mobile app for learning programming languages with hands-on exercises.', '2023/2024', 7, 1, '2025-11-29 19:04:35'),
(9, 'Social Media Analytics Dashboard', 'Build a comprehensive analytics dashboard for social media performance tracking.', '2023/2024', 5, 1, '2025-11-29 19:04:35'),
(10, 'Automated Attendance System using Face Recognition', 'Develop a contactless attendance system using facial recognition technology.', '2023/2024', 5, 1, '2025-11-29 19:04:35'),
(18, 'Yolo Modal Detect', 'hCapchart modal', '2024/2025', 5, 1, '2025-11-30 07:43:38'),
(22, '\"An Intelligent, Multi-Platform Language Learning Application with Gamification and Real-Time Speech Recognition\"', 'Multiple platform learning and recognized speech', '2024/2025', 6, 1, '2025-11-30 16:41:42'),
(23, 'AI Chatbot Services: An Advanced Mental Health Management Tool', 'AI Chat with manage the mental health tool', '2024/2025', 6, 1, '2025-11-30 17:00:52');

-- --------------------------------------------------------

--
-- 表的结构 `google_meeting_logs`
--

CREATE TABLE `google_meeting_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `event_id` varchar(255) DEFAULT NULL,
  `meeting_link` varchar(500) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `attendees` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attendees`)),
  `action` enum('created','updated','deleted','joined') DEFAULT 'created',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `google_tokens`
--

CREATE TABLE `google_tokens` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token_json` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `groups`
--

CREATE TABLE `groups` (
  `id` int(11) NOT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `moderator_id` int(11) DEFAULT NULL COMMENT 'FK to users.id (the moderator)',
  `batch_year` varchar(20) DEFAULT NULL COMMENT 'Batch year for the group',
  `status` enum('active','completed') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores project group information.';

--
-- 转存表中的数据 `groups`
--

INSERT INTO `groups` (`id`, `supervisor_id`, `moderator_id`, `batch_year`, `status`, `created_at`) VALUES
(1, 5, 6, '2024/2025', 'active', '2025-11-08 10:12:04'),
(2, 6, 5, '2024/2025', 'active', '2025-11-08 10:12:04'),
(3, 5, 7, '2023/2024', 'active', '2025-11-28 18:28:32'),
(5, 7, 5, '2023/2024', 'active', '2025-11-28 18:28:32'),
(7, 7, 5, '2024/2025', 'active', '2025-11-28 19:09:53'),
(11, 5, 7, '2025/2026', 'active', '2025-11-30 15:51:37'),
(12, 6, 7, '2025/2026', 'active', '2025-11-30 16:56:29'),
(19, NULL, 5, '2024/2025', 'active', '2025-12-05 04:21:51');

-- --------------------------------------------------------

--
-- 表的结构 `group_members`
--

CREATE TABLE `group_members` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL COMMENT 'FK to users.id (who receives the notification)',
  `sender_id` int(11) DEFAULT NULL COMMENT 'FK to users.id (who triggers the notification)',
  `type` enum('submission_approved','submission_rejected','submission_commented','submission_resubmitted','appointment_requested','appointment_approved','appointment_rejected','appointment_commented','deadline_reminder','supervisor_application_submitted','supervisor_application_approved','supervisor_application_rejected','proposal_submitted','proposal_approved','proposal_rejected') DEFAULT NULL,
  `submission_id` int(11) DEFAULT NULL COMMENT 'FK to submissions.id (related submission)',
  `appointment_id` int(11) DEFAULT NULL COMMENT 'FK to appointments.id (related appointment)',
  `proposal_id` int(11) DEFAULT NULL COMMENT 'FK to student_proposals.id (related proposal)',
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores notifications for users.';

--
-- 转存表中的数据 `notifications`
--

INSERT INTO `notifications` (`id`, `recipient_id`, `sender_id`, `type`, `submission_id`, `appointment_id`, `proposal_id`, `message`, `is_read`, `created_at`) VALUES
(6, 5, 1, '', NULL, NULL, NULL, 'Student resubmitted file for \'Proposal Submission\'.', 1, '2025-11-22 19:07:51'),
(37, 1, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:08:23'),
(38, 2, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:08:23'),
(39, 3, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:08:23'),
(40, 4, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:08:23'),
(41, 10, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:08:23'),
(42, 1, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:10:00'),
(43, 2, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:10:04'),
(44, 3, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:10:07'),
(45, 4, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:10:10'),
(46, 10, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:10:13'),
(47, 1, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:10:16'),
(48, 2, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:10:18'),
(49, 3, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:10:21'),
(50, 4, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:10:24'),
(51, 10, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:10:27'),
(52, 1, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:10:30'),
(53, 2, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:10:33'),
(54, 3, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:10:36'),
(55, 4, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:10:38'),
(56, 10, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:10:41'),
(57, 1, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:10:59'),
(58, 2, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:11:02'),
(59, 3, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:05'),
(60, 4, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:08'),
(61, 10, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:11'),
(62, 1, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:11:14'),
(63, 2, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:11:17'),
(64, 3, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:21'),
(65, 4, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:24'),
(66, 10, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:27'),
(67, 1, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:11:29'),
(68, 2, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:11:32'),
(69, 3, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:36'),
(70, 4, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:39'),
(71, 10, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:42'),
(72, 1, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:11:44'),
(73, 2, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:11:47'),
(74, 3, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:50'),
(75, 4, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:53'),
(76, 10, NULL, '', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:11:56'),
(77, 1, NULL, '', NULL, NULL, NULL, 'Test deadline reminder message', 1, '2025-11-23 14:12:38'),
(78, 1, NULL, '', NULL, NULL, NULL, 'Test deadline reminder message', 1, '2025-11-23 14:12:54'),
(79, 1, NULL, '', NULL, NULL, NULL, 'Direct test message', 1, '2025-11-23 14:13:10'),
(80, 1, NULL, '', NULL, NULL, NULL, 'Test deadline reminder message', 1, '2025-11-23 14:14:01'),
(81, 1, NULL, '', NULL, NULL, NULL, 'Method 1 message', 1, '2025-11-23 14:14:17'),
(82, 2, NULL, '', NULL, NULL, NULL, 'Method 2 message', 1, '2025-11-23 14:14:17'),
(83, 1, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Test deadline reminder message', 1, '2025-11-23 14:15:13'),
(84, 1, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:15:22'),
(85, 2, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:15:25'),
(86, 3, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:15:28'),
(87, 4, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:15:31'),
(88, 10, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:15:34'),
(89, 1, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:15:37'),
(90, 2, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:15:40'),
(91, 3, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:15:43'),
(92, 4, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:15:46'),
(93, 10, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:15:49'),
(94, 1, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:15:52'),
(95, 2, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:15:55'),
(96, 3, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:15:58'),
(97, 4, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:16:01'),
(98, 10, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:16:04'),
(99, 1, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:16:07'),
(100, 2, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:16:11'),
(101, 3, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:16:14'),
(102, 4, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:16:17'),
(103, 10, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:16:20'),
(104, 1, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:16:23'),
(105, 2, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.', 1, '2025-11-23 14:16:26'),
(106, 3, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:16:29'),
(107, 4, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:16:32'),
(108, 10, NULL, 'deadline_reminder', NULL, NULL, NULL, 'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.', 0, '2025-11-23 14:16:35'),
(109, 5, 2, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Siti binti Aminah.\n\nProject Title: test title\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 1, '2025-11-23 15:57:46'),
(110, 5, 2, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Siti binti Aminah.\n\nProject Title: test title\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 1, '2025-11-23 16:16:48'),
(111, 2, 5, 'supervisor_application_approved', NULL, NULL, NULL, 'Your supervisor application for \'test title\' has been approved by Dr. Lee Wei.\n\nComment from supervisor: can.', 1, '2025-11-23 16:17:12'),
(112, 5, 2, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Siti binti Aminah.\n\nProject Title: test title\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 1, '2025-11-23 16:22:23'),
(113, 2, 5, 'supervisor_application_approved', NULL, NULL, NULL, 'Your supervisor application for \'test title\' has been approved by Dr. Lee Wei.\n\nComment from supervisor: okok.', 1, '2025-11-23 17:09:41'),
(114, 5, 2, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Siti binti Aminah.\n\nProject Title: test title\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 1, '2025-11-23 17:43:43'),
(115, 2, 5, 'supervisor_application_approved', NULL, NULL, NULL, 'Your supervisor application for \'test title\' has been approved by Dr. Lee Wei.\n\nComment from supervisor: can.', 1, '2025-11-23 17:44:01'),
(123, 5, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from yixiang.\n\nProject Title: test proposal\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 0, '2025-11-28 07:30:17'),
(150, 5, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from student A.\n\nProject Title: test proposal\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 0, '2025-11-28 13:21:21'),
(152, 5, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from student A.\n\nProject Title: test proposal\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 0, '2025-11-28 13:23:27'),
(167, 5, 3, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Charlie Tan.\n\nStudent Email: charlie@student.com\n\nPlease log in to review this application.', 0, '2025-11-29 11:14:38'),
(168, 5, 34, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from test.\n\nStudent Email: 123Test@gmail.com\n\nPlease log in to review this application.', 0, '2025-11-30 06:41:57'),
(169, 34, 5, 'supervisor_application_approved', NULL, NULL, NULL, 'Your supervisor application has been approved by Dr. Lee Wei.', 0, '2025-11-30 13:07:58'),
(170, 5, 35, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from student 2023.\n\nStudent Email: 2023@student.com\n\nPlease log in to review this application.', 0, '2025-11-30 16:16:47'),
(171, 35, 5, 'supervisor_application_approved', NULL, NULL, NULL, 'Your supervisor application has been approved by Dr. Lee Wei.', 0, '2025-11-30 16:17:13'),
(172, 5, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from yixiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 0, '2025-11-30 16:23:11'),
(174, 5, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from yixiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 0, '2025-11-30 16:26:52'),
(178, 6, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from jonh.\n\nStudent Email: john@example.com\n\nPlease log in to review this application.', 1, '2025-12-01 19:24:15'),
(182, 5, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Sim Yi Xiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 0, '2025-12-03 11:24:40'),
(186, 5, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Sim Yi Xiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 0, '2025-12-03 11:31:42'),
(190, 5, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Sim Yi Xiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 1, '2025-12-03 17:08:10'),
(201, 5, NULL, 'proposal_submitted', NULL, NULL, 15, 'Student Jordan has submitted a new FYP proposal: \"Yolo Modal Detect\". Please review it in the Proposal Management system.', 0, '2025-12-04 18:30:56'),
(204, 5, NULL, 'proposal_submitted', NULL, NULL, 16, 'Student Jordan has submitted a new FYP proposal: \"test\". Please review it in the Proposal Management system.', 0, '2025-12-04 19:07:32'),
(205, 5, NULL, 'proposal_submitted', NULL, NULL, 17, 'Student Jordan has submitted a new FYP proposal: \"test\". Please review it in the Proposal Management system.', 0, '2025-12-04 19:08:27'),
(206, 5, NULL, 'proposal_submitted', NULL, NULL, 18, 'Student Jordan has submitted a new FYP proposal: \"test\". Please review it in the Proposal Management system.', 0, '2025-12-04 19:29:57'),
(208, 5, NULL, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Sim Yi Xiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.', 0, '2025-12-05 04:26:34'),
(210, 5, 10, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Ethan Hunt.\n\nStudent Email: ethan@student.com\n\nPlease log in to review this application.', 0, '2025-12-05 04:32:26'),
(212, 10, 5, 'supervisor_application_approved', NULL, NULL, NULL, 'Your supervisor application has been approved by Dr. Lee Wei.', 0, '2025-12-05 04:34:02'),
(213, 10, 7, 'supervisor_application_approved', NULL, NULL, NULL, 'Your supervisor application has been approved by Dr. Kumar.', 0, '2025-12-05 04:34:34'),
(219, 7, 10, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Ethan Hunt.\n\nStudent Email: ethan@student.com\n\nPlease log in to review this application.', 0, '2025-12-05 09:53:32'),
(220, 5, 10, 'supervisor_application_submitted', NULL, NULL, NULL, 'New supervisor application from Ethan Hunt.\n\nStudent Email: ethan@student.com\n\nPlease log in to review this application.', 0, '2025-12-05 09:53:38'),
(221, 10, 5, 'supervisor_application_approved', NULL, NULL, NULL, 'Your supervisor application has been approved by dr lee.', 0, '2025-12-05 09:54:28'),
(224, 5, NULL, 'proposal_submitted', NULL, NULL, 21, 'Student Sim Yi Xiang has submitted a new FYP proposal: \"Blockchain-based Supply Chain Management\". Please review it in the Proposal Management system.', 0, '2025-12-05 11:00:04');

-- --------------------------------------------------------

--
-- 表的结构 `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `otp_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores password reset tokens (OTPs).';

-- --------------------------------------------------------

--
-- 表的结构 `rubrics`
--

CREATE TABLE `rubrics` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `project_type` enum('project1','project2') NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `submitted_by` int(11) NOT NULL,
  `submitted_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `rubrics`
--

INSERT INTO `rubrics` (`id`, `student_id`, `project_type`, `file_path`, `submitted_by`, `submitted_at`, `created_at`) VALUES
(1, 1, 'project1', '../uploads/rubrics/rubric_project1_student_1_1764264235.pdf', 6, '2025-11-28 01:23:55', '2025-11-27 17:19:20'),
(2, 1, 'project2', '../uploads/rubrics/rubric_project2_student_1_1764264107.pdf', 6, '2025-11-28 01:21:47', '2025-11-27 17:21:47'),
(5, 4, 'project1', '../uploads/rubrics/rubric_project1_student_4_1764265393.pdf', 6, '2025-11-28 01:43:13', '2025-11-27 17:43:13');

-- --------------------------------------------------------

--
-- 表的结构 `students`
--

CREATE TABLE `students` (
  `user_id` int(11) NOT NULL COMMENT 'FK to users.id',
  `batch_year` varchar(20) DEFAULT NULL COMMENT 'e.g., 2024/2025',
  `project_title` varchar(255) DEFAULT NULL COMMENT 'Student project title',
  `supervisor_id` int(11) DEFAULT NULL COMMENT 'FK to users.id (the supervisor)',
  `group_id` int(11) DEFAULT NULL COMMENT 'FK to groups.id (the group this student belongs to)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores student-specific information.';

-- --------------------------------------------------------

--
-- 表的结构 `student_proposals`
--

CREATE TABLE `student_proposals` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `proposed_title` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `proposal_file_path` varchar(500) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `feedback` text DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `submissions`
--

CREATE TABLE `submissions` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL COMMENT 'FK to users.id',
  `deadline_id` int(11) NOT NULL COMMENT 'FK to deadlines.id',
  `file_path` varchar(255) NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('submitted','late') NOT NULL DEFAULT 'submitted',
  `feedback` text DEFAULT NULL,
  `grade` varchar(10) DEFAULT NULL,
  `graded_by` int(11) DEFAULT NULL,
  `approval_status` enum('approved','rejected') DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `comments` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- 表的结构 `supervisor_applications`
--

CREATE TABLE `supervisor_applications` (
  `id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL COMMENT 'FK to users.id (the student)',
  `supervisor_id` int(11) NOT NULL COMMENT 'FK to users.id (the supervisor)',
  `status` enum('pending','confirmed','rejected','cancelled') NOT NULL DEFAULT 'pending' COMMENT 'Status of the application',
  `student_message` text DEFAULT NULL COMMENT 'Optional message from student during application',
  `project_title` varchar(255) NOT NULL COMMENT 'Student''s proposed project title',
  `proposal_file_path` varchar(512) NOT NULL COMMENT 'Path to the uploaded proposal file',
  `supervisor_response` text DEFAULT NULL COMMENT 'Optional feedback from supervisor (e.g., on rejection)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'When the application was submitted',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'When the status was last changed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tracks student applications to supervisors.';

-- --------------------------------------------------------

--
-- 表的结构 `supervisor_availability`
--

CREATE TABLE `supervisor_availability` (
  `id` int(11) NOT NULL,
  `supervisor_id` int(11) NOT NULL,
  `day_of_week` varchar(20) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- 转存表中的数据 `supervisor_availability`
--

INSERT INTO `supervisor_availability` (`id`, `supervisor_id`, `day_of_week`, `start_time`, `end_time`, `created_at`) VALUES
(1, 5, 'Monday', '10:00:00', '12:00:00', '2025-11-22 09:11:31'),
(2, 5, 'Wednesday', '14:00:00', '16:00:00', '2025-11-22 09:11:31'),
(3, 6, 'Tuesday', '09:00:00', '11:00:00', '2025-11-22 09:11:31'),
(4, 6, 'Friday', '15:00:00', '17:00:00', '2025-11-22 09:11:31'),
(7, 5, 'Tuesday', '12:00:00', '14:00:00', '2025-12-03 11:36:39'),
(9, 7, 'Monday', '12:00:00', '14:00:00', '2025-12-05 04:40:10');

-- --------------------------------------------------------

--
-- 表的结构 `supervisor_courses`
--

CREATE TABLE `supervisor_courses` (
  `supervisor_id` int(11) NOT NULL COMMENT 'FK to users.id',
  `course_id` int(11) NOT NULL COMMENT 'FK to courses.id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Links Supervisors to the Courses they can supervise (M:N).';

--
-- 转存表中的数据 `supervisor_courses`
--

INSERT INTO `supervisor_courses` (`supervisor_id`, `course_id`) VALUES
(5, 1),
(5, 2),
(6, 3);

-- --------------------------------------------------------

--
-- 表的结构 `supervisor_details`
--

CREATE TABLE `supervisor_details` (
  `user_id` int(11) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 10 COMMENT 'Max number of STUDENTS'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Details specific to supervisors.';

--
-- 转存表中的数据 `supervisor_details`
--

INSERT INTO `supervisor_details` (`user_id`, `capacity`) VALUES
(5, 10),
(6, 8),
(7, 10);

-- --------------------------------------------------------

--
-- 表的结构 `system_settings`
--

CREATE TABLE `system_settings` (
  `setting_key` varchar(100) NOT NULL COMMENT 'config key/name',
  `setting_value` text DEFAULT NULL COMMENT 'config value'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores all system-level dynamic configurations.';

--
-- 转存表中的数据 `system_settings`
--

INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES
('allowed_file_types', 'pdf,zip,doc,docx'),
('allow_student_applications', 'true'),
('allow_supervisor_capacity_edit', 'false'),
('backup_frequency', 'weekly'),
('backup_last_run', '2025-12-08 20:00:07'),
('current_academic_year', '2024/2025'),
('maintenance_mode', 'false'),
('max_file_size_mb', '1000'),
('max_student_applications', '3');

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','supervisor','committee','admin') NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `batch_year` varchar(20) DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `google_email` varchar(255) DEFAULT NULL,
  `google_integration_enabled` tinyint(1) DEFAULT 0,
  `profile_picture` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Core table for all users.';

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `status`, `batch_year`, `supervisor_id`, `group_id`, `course_id`, `created_at`, `updated_at`, `google_email`, `google_integration_enabled`, `profile_picture`) VALUES
(1, 'Ali bin Abu', 'ali@student.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'student', 'active', '2024/2025', NULL, NULL, 1, '2025-11-08 10:12:04', '2025-12-12 17:00:30', NULL, 0, NULL),
(2, 'Siti binti Aminah', 'siti@student.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'student', 'active', '2024/2025', 5, 1, 2, '2025-11-08 10:12:04', '2025-11-28 07:13:14', NULL, 0, NULL),
(3, 'Charlie Tan', 'charlie@student.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'student', 'active', '2024/2025', NULL, NULL, 1, '2025-11-08 10:12:04', '2025-11-18 17:27:06', NULL, 0, NULL),
(4, 'David Lee', 'david@student.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'student', 'active', '2024/2025', 5, 1, 3, '2025-11-08 10:12:04', '2025-11-28 07:48:47', NULL, 0, NULL),
(5, 'dr lee', 'lee@supervisor.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'supervisor', 'active', NULL, NULL, NULL, 1, '2025-11-08 10:12:04', '2025-12-12 16:51:52', NULL, 0, NULL),
(6, 'Prof. Wong', 'wong@supervisor.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'supervisor', 'active', NULL, NULL, NULL, 1, '2025-11-08 10:12:04', '2025-11-30 10:06:50', NULL, 0, NULL),
(7, 'Dr. Kumar', 'kumar@supervisor.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'supervisor', 'active', NULL, NULL, NULL, 3, '2025-11-08 10:12:04', '2025-12-12 16:40:17', NULL, 0, NULL),
(8, 'Puan Aminah', 'aminah@committee.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'committee', 'active', '2025/2026', NULL, NULL, 2, '2025-11-08 10:12:04', '2025-11-30 14:32:59', NULL, 0, NULL),
(9, 'Admin FYP', 'admin@fyp.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'admin', 'active', NULL, NULL, NULL, NULL, '2025-11-08 10:12:04', '2025-11-18 17:27:06', NULL, 0, NULL),
(10, 'Ethan Hunt', 'ethan@student.com', '$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze', 'student', 'active', '2024/2025', 5, 1, 1, '2025-11-08 10:12:04', '2025-12-12 16:51:49', NULL, 0, NULL),
(34, 'student 2025', '2025@gmail.com', '$2y$10$R7EKAT8ZZXpcl7.fknj1OehN9vCwNARwqivREJLXaPmj.R8CC0SP.', 'student', 'active', '2025/2026', 5, 11, 3, '2025-11-30 06:38:51', '2025-12-04 01:36:49', NULL, 0, NULL),
(35, 'student 2023', '2023@student.com', '$2y$10$RQ3KX78wa8ir4mTyWFx1meS90cu1rCx9Rv7kyQgrNuESwF1LmyA32', 'student', 'active', '2023/2024', NULL, 3, 3, '2025-11-30 08:46:47', '2025-11-30 19:50:48', NULL, 0, NULL);

--
-- 转储表的索引
--

--
-- 表的索引 `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_announcement_creator_idx` (`created_by`);

--
-- 表的索引 `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `google_calendar_event_id` (`google_calendar_event_id`),
  ADD KEY `fk_appt_group_idx` (`group_id`),
  ADD KEY `fk_student_appointment` (`student_id`),
  ADD KEY `fk_supervisor_appointment` (`supervisor_id`),
  ADD KEY `idx_status_supervisor` (`supervisor_id`,`status`),
  ADD KEY `idx_appointment_start_status` (`appointment_start`,`appointment_end`,`status`),
  ADD KEY `idx_reminder_sent` (`reminder_sent`,`appointment_start`);

--
-- 表的索引 `batch_committees`
--
ALTER TABLE `batch_committees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_batch_committee` (`batch_year`,`committee_id`),
  ADD KEY `committee_id` (`committee_id`);

--
-- 表的索引 `chat_contacts`
--
ALTER TABLE `chat_contacts`
  ADD PRIMARY KEY (`user_id`,`contact_user_id`),
  ADD KEY `fk_contact_user_idx` (`contact_user_id`);

--
-- 表的索引 `chat_groups`
--
ALTER TABLE `chat_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `google_calendar_event_id` (`google_calendar_event_id`),
  ADD KEY `created_by` (`created_by`);

--
-- 表的索引 `chat_group_members`
--
ALTER TABLE `chat_group_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_member` (`group_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `chat_meetings`
--
ALTER TABLE `chat_meetings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `google_calendar_event_id` (`google_calendar_event_id`),
  ADD KEY `contact_user_id` (`contact_user_id`),
  ADD KEY `idx_users` (`user_id`,`contact_user_id`),
  ADD KEY `idx_event_id` (`google_calendar_event_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- 表的索引 `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_chat_sender_idx` (`sender_id`),
  ADD KEY `fk_chat_receiver_idx` (`receiver_id`),
  ADD KEY `group_id` (`group_id`);
ALTER TABLE `chat_messages` ADD FULLTEXT KEY `ft_message_search` (`message`);

--
-- 表的索引 `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_course_faculty_idx` (`faculty_id`);

--
-- 表的索引 `deadlines`
--
ALTER TABLE `deadlines`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_deadline_creator_idx` (`created_by`);

--
-- 表的索引 `downloadable_files`
--
ALTER TABLE `downloadable_files`
  ADD PRIMARY KEY (`id`);

--
-- 表的索引 `faculties`
--
ALTER TABLE `faculties`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_unique` (`name`);

--
-- 表的索引 `fyp_titles`
--
ALTER TABLE `fyp_titles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by` (`created_by`);

--
-- 表的索引 `google_meeting_logs`
--
ALTER TABLE `google_meeting_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_event_id` (`event_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- 表的索引 `google_tokens`
--
ALTER TABLE `google_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id` (`user_id`),
  ADD KEY `idx_expires_at` (`expires_at`);

--
-- 表的索引 `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_group_supervisor_idx` (`supervisor_id`),
  ADD KEY `fk_group_moderator_idx` (`moderator_id`),
  ADD KEY `batch_year_group_index` (`batch_year`);

--
-- 表的索引 `group_members`
--
ALTER TABLE `group_members`
  ADD PRIMARY KEY (`group_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_notif_recipient_idx` (`recipient_id`),
  ADD KEY `fk_notif_sender_idx` (`sender_id`),
  ADD KEY `fk_notif_submission_idx` (`submission_id`),
  ADD KEY `fk_notif_appointment_idx` (`appointment_id`);

--
-- 表的索引 `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email_index` (`email`);

--
-- 表的索引 `rubrics`
--
ALTER TABLE `rubrics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_student_project` (`student_id`,`project_type`),
  ADD KEY `submitted_by` (`submitted_by`);

--
-- 表的索引 `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `fk_students_supervisor_idx` (`supervisor_id`),
  ADD KEY `fk_students_group_idx` (`group_id`);

--
-- 表的索引 `student_proposals`
--
ALTER TABLE `student_proposals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `supervisor_id` (`supervisor_id`),
  ADD KEY `reviewed_by` (`reviewed_by`);

--
-- 表的索引 `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_student_deadline` (`student_id`,`deadline_id`),
  ADD KEY `fk_sub_deadline_idx` (`deadline_id`),
  ADD KEY `fk_approved_by` (`approved_by`);

--
-- 表的索引 `supervisor_applications`
--
ALTER TABLE `supervisor_applications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_student_supervisor_unique` (`student_id`,`supervisor_id`),
  ADD KEY `fk_app_student_idx` (`student_id`),
  ADD KEY `fk_app_supervisor_idx` (`supervisor_id`);

--
-- 表的索引 `supervisor_availability`
--
ALTER TABLE `supervisor_availability`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_avail_supervisor_idx` (`supervisor_id`);

--
-- 表的索引 `supervisor_courses`
--
ALTER TABLE `supervisor_courses`
  ADD PRIMARY KEY (`supervisor_id`,`course_id`),
  ADD KEY `fk_sc_course_idx` (`course_id`);

--
-- 表的索引 `supervisor_details`
--
ALTER TABLE `supervisor_details`
  ADD PRIMARY KEY (`user_id`);

--
-- 表的索引 `system_settings`
--
ALTER TABLE `system_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- 表的索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD UNIQUE KEY `google_email` (`google_email`),
  ADD KEY `role_index` (`role`),
  ADD KEY `fk_user_supervisor_idx` (`supervisor_id`),
  ADD KEY `fk_users_group_idx` (`group_id`),
  ADD KEY `fk_user_course_idx` (`course_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- 使用表AUTO_INCREMENT `batch_committees`
--
ALTER TABLE `batch_committees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `chat_groups`
--
ALTER TABLE `chat_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用表AUTO_INCREMENT `chat_group_members`
--
ALTER TABLE `chat_group_members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 使用表AUTO_INCREMENT `chat_meetings`
--
ALTER TABLE `chat_meetings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- 使用表AUTO_INCREMENT `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- 使用表AUTO_INCREMENT `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `deadlines`
--
ALTER TABLE `deadlines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- 使用表AUTO_INCREMENT `downloadable_files`
--
ALTER TABLE `downloadable_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- 使用表AUTO_INCREMENT `faculties`
--
ALTER TABLE `faculties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `fyp_titles`
--
ALTER TABLE `fyp_titles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- 使用表AUTO_INCREMENT `google_meeting_logs`
--
ALTER TABLE `google_meeting_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用表AUTO_INCREMENT `google_tokens`
--
ALTER TABLE `google_tokens`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- 使用表AUTO_INCREMENT `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- 使用表AUTO_INCREMENT `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=248;

--
-- 使用表AUTO_INCREMENT `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- 使用表AUTO_INCREMENT `rubrics`
--
ALTER TABLE `rubrics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 使用表AUTO_INCREMENT `student_proposals`
--
ALTER TABLE `student_proposals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- 使用表AUTO_INCREMENT `submissions`
--
ALTER TABLE `submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- 使用表AUTO_INCREMENT `supervisor_applications`
--
ALTER TABLE `supervisor_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- 使用表AUTO_INCREMENT `supervisor_availability`
--
ALTER TABLE `supervisor_availability`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- 使用表AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- 限制导出的表
--

--
-- 限制表 `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `fk_announcement_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `fk_supervisor_appointment` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- 限制表 `batch_committees`
--
ALTER TABLE `batch_committees`
  ADD CONSTRAINT `batch_committees_ibfk_1` FOREIGN KEY (`committee_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- 限制表 `chat_contacts`
--
ALTER TABLE `chat_contacts`
  ADD CONSTRAINT `fk_contact_owner` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_contact_user` FOREIGN KEY (`contact_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `chat_groups`
--
ALTER TABLE `chat_groups`
  ADD CONSTRAINT `chat_groups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- 限制表 `chat_group_members`
--
ALTER TABLE `chat_group_members`
  ADD CONSTRAINT `chat_group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- 限制表 `chat_meetings`
--
ALTER TABLE `chat_meetings`
  ADD CONSTRAINT `chat_meetings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `chat_meetings_ibfk_2` FOREIGN KEY (`contact_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- 限制表 `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_chat_receiver` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_chat_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `fk_course_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `deadlines`
--
ALTER TABLE `deadlines`
  ADD CONSTRAINT `fk_deadline_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `fyp_titles`
--
ALTER TABLE `fyp_titles`
  ADD CONSTRAINT `fyp_titles_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- 限制表 `google_meeting_logs`
--
ALTER TABLE `google_meeting_logs`
  ADD CONSTRAINT `google_meeting_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- 限制表 `google_tokens`
--
ALTER TABLE `google_tokens`
  ADD CONSTRAINT `google_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- 限制表 `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `fk_group_moderator` FOREIGN KEY (`moderator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_group_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- 限制表 `group_members`
--
ALTER TABLE `group_members`
  ADD CONSTRAINT `group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- 限制表 `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notif_appointment` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_notif_recipient` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_notif_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_notif_submission` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `rubrics`
--
ALTER TABLE `rubrics`
  ADD CONSTRAINT `rubrics_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `rubrics_ibfk_2` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`);

--
-- 限制表 `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_students_group` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_students_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_students_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `student_proposals`
--
ALTER TABLE `student_proposals`
  ADD CONSTRAINT `student_proposals_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `student_proposals_ibfk_2` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `student_proposals_ibfk_3` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`);

--
-- 限制表 `submissions`
--
ALTER TABLE `submissions`
  ADD CONSTRAINT `fk_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_sub_deadline` FOREIGN KEY (`deadline_id`) REFERENCES `deadlines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sub_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `supervisor_applications`
--
ALTER TABLE `supervisor_applications`
  ADD CONSTRAINT `fk_app_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_app_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `supervisor_courses`
--
ALTER TABLE `supervisor_courses`
  ADD CONSTRAINT `fk_sc_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_sc_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `supervisor_details`
--
ALTER TABLE `supervisor_details`
  ADD CONSTRAINT `fk_supervisor_user_details` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_user_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_users_group` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
