<?php
session_start();

if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['student', 'supervisor', 'admin', 'committee'])) {
    header("Location: ../index.php");
    exit();
}
$my_id = $_SESSION['user_id'];
$my_name = $_SESSION['name'];
$my_role = $_SESSION['role'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat - FYPMS</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="chat.css">
</head>

<body>
    <nav class="navbar">
        <h2>FYP Management System</h2>
        <div class="button-group">
            <?php if ($my_role === 'student' || $my_role === 'supervisor' || $my_role === 'admin' || $my_role === 'committee'): ?>
                <a href="<?php echo $my_role; ?>/<?php echo $my_role; ?>_dashboard.php" class="btn secondary">Dashboard</a>
            <?php else: ?>
            <?php endif; ?>
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </nav>

    <div class="main-container">
        <main class="main-content">
            <h3><i class="fas fa-comments"></i> Chat</h3>
            <div class="card">
                <div class="chat-container">

                    <div class="contact-list" id="contact-list">
                        <div style="padding: 10px; border-bottom: 1px solid #e0e0e0; display: flex; gap: 5px;">
                            <button id="create-group-btn" class="btn btn-primary" style="flex: 1;"><i class="fas fa-users"></i> Create New Group</button>
                            <button id="blocked-contacts-btn" class="btn" style="flex: 0.3; background-color: #f44336; color: white;"><i class="fas fa-ban"></i></button>
                        </div>

                        <div class="contact-list-header">
                            <h4>Contacts</h4>
                            <form id="add-contact-form">
                                <input type="email" id="add-contact-email" placeholder="Add by email..." required>
                                <button type="submit" class="btn btn-sm"><i class="fas fa-plus"></i></button>
                            </form>
                            <div id="add-contact-toast"></div>
                        </div>

                        <div id="contact-items">
                        </div>
                    </div>

                    <div class="chat-window" id="chat-window">
                        <div class="chat-header" id="chat-header">
                            <strong style="color: #a8b2c1;">💬 Select a contact to start chatting</strong>
                        </div>

                        <!-- Message Search Bar (integrated into message area) -->
                        <div id="search-messages-container" style="padding: 12px 20px; border-bottom: 1px solid #e8eef5; background: #f9fafb; display: none; gap: 8px;">
                            <input type="text" id="search-messages-input" placeholder="Search messages in this chat..." style="flex: 1; padding: 10px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px;">
                            <button type="button" onclick="toggleSearchMessages()" style="background: #667eea; color: white; border: none; padding: 10px 14px; border-radius: 6px; cursor: pointer; font-size: 12px;">Close</button>
                        </div>

                        <div class="message-display" id="message-display">
                        </div>

                        <form class="message-form" id="message-form" style="display: none;">
                            <div id="filename-display" style="flex-basis: 100%; display: none;"></div>
                            <button type="button" id="attach-file-btn" title="Attach File"><i class="fas fa-paperclip"></i></button>
                            <input type="file" id="file-attachment" name="attachment" style="display: none;">

                            <input type="text" id="message-input" name="message_text" placeholder="Type a message..." autocomplete="off">
                            <button type="submit" class="btn">
                                <i class="fas fa-paper-plane"></i> Send
                            </button>
                        </form>
                    </div>

                </div>
            </div>
        </main>
    </div>

    <div id="create-group-modal" class="modal">
        <div class="modal-content">
            <span class="close-btn">&times;</span>
            <h3>Create New Group</h3>
            <input type="text" id="group-name-input" placeholder="Enter group name" class="form-control" required style="width: 100%; padding: 8px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;">

            <p>Select group members (at least one):</p>
            <div id="available-members-list">
            </div>

            <button id="submit-create-group" class="btn btn-success" style="width: 100%; margin-top: 15px;">Confirm Create</button>
            <div id="group-modal-message" style="color: red; margin-top: 10px; font-size: 0.9em;"></div>
        </div>
    </div>
    <!-- details modal -->
    <div id="detailsModal" class="modal">
    <div class="modal-content" style="width: 400px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
            <h3 id="detailsTitle" style="margin: 0;"></h3>
            <span class="close-button" onclick="closeDetailsModal()" style="cursor: pointer; font-size: 24px; line-height: 1;">&times;</span>
        </div>
        <div id="detailsContent">
            </div>
        <div id="detailsActions" style="margin-top: 20px;">
            </div>
    </div>
</div>

    <!-- Blocked Contacts Modal -->
    <div id="blockedContactsModal" class="modal">
    <div class="modal-content" style="width: 450px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
            <h3 style="margin: 0;">🚫 Blocked Contacts</h3>
            <span class="close-button" onclick="closeBlockedContactsModal()" style="cursor: pointer; font-size: 24px; line-height: 1;">&times;</span>
        </div>
        <div id="blockedContactsList" style="max-height: 400px; overflow-y: auto;">
            <p style="text-align: center; color: #999;">Loading...</p>
        </div>
    </div>
</div>

    <div id="createMeetingModal" class="modal">
    <div class="modal-content" style="width: 450px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
            <h3 style="margin: 0;">📹 Schedule Meeting</h3>
            <span class="close-button" onclick="closeMeetingModal()" style="cursor: pointer; font-size: 24px; line-height: 1;">&times;</span>
        </div>
        
        <form id="meetingForm" style="display: flex; flex-direction: column; gap: 15px;">
            <div>
                <label for="meetingTitle">Meeting Title:</label>
                <input type="text" id="meetingTitle" name="title" 
                       placeholder="e.g., Project Discussion" required
                       style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <div>
                <label for="meetingStart">Start Time:</label>
                <input type="datetime-local" id="meetingStart" name="start_time" required
                       style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <div>
                <label for="meetingEnd">End Time:</label>
                <input type="datetime-local" id="meetingEnd" name="end_time" required
                       style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
            </div>
            
            <div id="googleAuthStatus" style="padding: 10px; border-radius: 4px; margin: 10px 0;"></div>
            
            <div style="display: flex; gap: 10px;">
                <button type="submit" id="submitMeetingBtn" 
                        style="flex: 1; padding: 10px; background-color: #667eea; color: white; border: none; border-radius: 4px; cursor: pointer;">
                    Create Meeting
                </button>
            </div>
            
            <div id="meetingMessage" style="color: red; font-size: 0.9em; text-align: center;"></div>
        </form>
    </div>
</div>

    <!-- Edit Message Modal -->
    <div id="editMessageModal" class="modal">
        <div class="modal-content" style="width: 450px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h3 style="margin: 0;">✏️ Edit Message</h3>
                <span class="close-button" onclick="closeEditMessageModal()" style="cursor: pointer; font-size: 24px; line-height: 1;">&times;</span>
            </div>
            <div class="modal-body">
                <textarea id="editMessageText" placeholder="Edit your message..." style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; min-height: 100px; resize: vertical; font-family: inherit;"></textarea>
                <div id="editMessageError" style="color: red; margin-top: 10px; font-size: 0.9em;"></div>
            </div>
            <div class="modal-footer" style="display: flex; gap: 10px; margin-top: 15px;">
                <button onclick="submitEditMessage()" style="flex: 1; padding: 10px; background-color: #667eea; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">Save Changes</button>
                <button onclick="closeEditMessageModal()" style="flex: 1; padding: 10px; background-color: #ccc; color: #333; border: none; border-radius: 4px; cursor: pointer;">Cancel</button>
            </div>
        </div>
    </div>

    <!-- Delete Message Modal -->
    <div id="deleteMessageModal" class="modal">
        <div class="modal-content" style="width: 400px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h3 style="margin: 0;">🗑️ Delete Message</h3>
                <span class="close-button" onclick="closeDeleteMessageModal()" style="cursor: pointer; font-size: 24px; line-height: 1;">&times;</span>
            </div>
            <div class="modal-body">
                <p style="margin-bottom: 15px;">Delete this message?</p>
                <div id="deleteMessageError" style="color: red; margin-bottom: 10px; font-size: 0.9em;"></div>
            </div>
            <div class="modal-footer" style="display: flex; gap: 10px; margin-top: 15px;">
                <button onclick="deleteMessageForAll()" style="flex: 1; padding: 10px; background-color: #f44336; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">Delete (10 min)</button>
                <button onclick="closeDeleteMessageModal()" style="flex: 1; padding: 10px; background-color: #ccc; color: #333; border: none; border-radius: 4px; cursor: pointer;">Cancel</button>
            </div>
        </div>
    </div>
<script>
    const MY_ID = <?php echo $my_id; ?>;
    let currentContactId = null;
    let chatPoller = null;
    let allContacts = []; 
    let availableMembers = []; 
    let statuses = {}; 

    const contactItemsDiv = document.getElementById('contact-items');
    const chatHeader = document.getElementById('chat-header');
    const messageDisplay = document.getElementById('message-display');
    const messageForm = document.getElementById('message-form');
    const messageInput = document.getElementById('message-input');
    const addContactForm = document.getElementById('add-contact-form');
    const addContactEmail = document.getElementById('add-contact-email');
    const addContactToast = document.getElementById('add-contact-toast');

    
    const attachFileBtn = document.getElementById('attach-file-btn');
    const fileAttachment = document.getElementById('file-attachment');
    const filenameDisplay = document.getElementById('filename-display');

    
    const createGroupBtn = document.getElementById('create-group-btn');
    const createGroupModal = document.getElementById('create-group-modal');
    const closeModalBtn = createGroupModal.querySelector('.close-btn');
    const groupNameInput = document.getElementById('group-name-input');
    const availableMembersList = document.getElementById('available-members-list');
    const submitCreateGroup = document.getElementById('submit-create-group');
    const groupModalMessage = document.getElementById('group-modal-message');

    const blockedContactsBtn = document.getElementById('blocked-contacts-btn');
    const blockedContactsModal = document.getElementById('blockedContactsModal');
    const blockedContactsList = document.getElementById('blockedContactsList');


const detailsModal = document.getElementById('detailsModal');
const detailsTitle = document.getElementById('detailsTitle');
const detailsContent = document.getElementById('detailsContent');
const detailsActions = document.getElementById('detailsActions');


let currentTargetIdForAction = null; 
let currentIsGroupForAction = false;
let currentIsCreator = false;
let currentTargetName = ''; // Store the group/contact name 

    document.addEventListener('DOMContentLoaded', initChat);

    function initChat() {
        loadContacts();
        
        addContactForm.addEventListener('submit', handleAddContact);
        messageForm.addEventListener('submit', handleSendMessage);
        attachFileBtn.addEventListener('click', () => fileAttachment.click());
        fileAttachment.addEventListener('change', displayFileName);

        
        createGroupBtn.addEventListener('click', openCreateGroupModal);
        closeModalBtn.addEventListener('click', closeCreateGroupModal);
        submitCreateGroup.addEventListener('click', handleCreateGroup);
        window.addEventListener('click', (event) => {
            if (event.target == createGroupModal) {
                closeCreateGroupModal();
            }
            if (event.target == blockedContactsModal) {
                closeBlockedContactsModal();
            }
        });

        // Blocked contacts button
        blockedContactsBtn.addEventListener('click', openBlockedContactsModal);
        
        setInterval(loadContactStatuses, 2000);
    }



    function loadContacts() {
        fetch('chat_action.php?action=fetch_contacts')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    
                    allContacts = [...data.contacts, ...data.groups];
                    
                    availableMembers = data.contacts.filter(c => c.role !== 'N/A' && c.id != MY_ID); 
                    renderContacts();
                    loadContactStatuses();
                } else {
                    contactItemsDiv.innerHTML = `<div class="contact-item">Error loading contacts: ${data.message || 'Unknown error'}</div>`;
                }
            })
            .catch(error => console.error('Error fetching contacts:', error));
    }
    function loadContactStatuses() {
        fetch('chat_action.php?action=fetch_unread_counts')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    statuses = data.unread_counts || {};
                    renderContacts(); 
                } else {
                    console.error('Failed to load contact statuses:', data.message);
                }
            })
            .catch(error => console.error('Error fetching contact statuses:', error));
    }

    function renderContacts() {
        contactItemsDiv.innerHTML = ''; 
        if (allContacts.length === 0) {
            contactItemsDiv.innerHTML = `<div class="contact-item">没有联系人或群组。</div>`;
            return;
        }

        allContacts.forEach(contact => {
            const isGroup = contact.type === 'group';
            const contactId = isGroup ? contact.id : contact.id; 

            const item = document.createElement('div');
            item.className = 'contact-item';
            
            const iconClass = isGroup ? 'fas fa-users' : 'fas fa-user-circle';
            const roleOrType = isGroup ? '<i class="fas fa-users" style="color:#667eea; font-size: 12px;"></i>' : `<span style="font-size: 11px; color: #a8b2c1;">${contact.role}</span>`;
            
            item.innerHTML = `
                <div style="flex-grow: 1; display: flex; align-items: center; gap: 8px; min-width: 0;">
                    <i class="${iconClass}" style="color: ${isGroup ? '#667eea' : '#764ba2'}; font-size: 14px; flex-shrink: 0;"></i>
                    <div style="min-width: 0;">
                        <strong style="display: block; color: #2c3e50; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${escapeHTML(contact.name)}</strong>
                        ${roleOrType}
                    </div>
                </div>
            `;
            item.dataset.contactId = contactId;
            item.dataset.contactName = contact.name;
            item.dataset.isGroup = isGroup;

            
            if (contactId === currentContactId) {
                item.classList.add('active');
            }
            
            
            const unreadCount = statuses[contactId] || 0;
            if (unreadCount > 0) {
                item.innerHTML += ` <span class="unread-badge">${unreadCount}</span>`;
            }

            item.addEventListener('click', () => {
                selectContact(contactId, contact.name);
            });
            contactItemsDiv.appendChild(item);
        });
    }




function selectContact(contactId, contactName) {
    const targetIdStr = String(contactId); 

    document.querySelectorAll('.contact-item').forEach(item => {
        
        item.classList.toggle('active', item.dataset.contactId === targetIdStr); 
    });

 currentContactId = targetIdStr; 
    const isGroup = targetIdStr.startsWith('group_');

    let headerHTML = `<div style="display: flex; gap: 10px; align-items: center; justify-content: space-between; width: 100%;">
                        <strong>${escapeHTML(contactName)}</strong>
                        <div style="display: flex; gap: 5px;">
                            <button class="btn btn-sm btn-info" 
                                    onclick="toggleSearchMessages()" 
                                    title="Search messages">
                                <i class="fas fa-search"></i>
                            </button>
                            <button class="btn btn-sm btn-info" 
                                    onclick="openDetailsModal('${targetIdStr}', '${escapeHTML(contactName)}', ${isGroup})">
                                <i class="fas fa-info-circle"></i>
                            </button>
                        </div>
                    </div>`;

    chatHeader.innerHTML = headerHTML;
    
    chatHeader.classList.remove('group-chat', 'individual-chat');
    if (isGroup) {
        chatHeader.classList.add('group-chat');
    } else {
        chatHeader.classList.add('individual-chat');
    }
    messageForm.style.display = 'flex';
    messageInput.value = '';
    messageDisplay.innerHTML = 'Loading messages...';

    
    if (chatPoller) {
        clearInterval(chatPoller);
    }
    
    loadMessages();
    
    chatPoller = setInterval(loadMessages, 3000);

    
    fileAttachment.value = null;
    filenameDisplay.style.display = 'none';
    filenameDisplay.innerHTML = '';
    
    // Hide search container
    document.getElementById('search-messages-container').style.display = 'none';
}


    function loadMessages() {
        if (!currentContactId) return;

        
        fetch(`chat_action.php?action=fetch_messages`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ target_id: currentContactId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                renderMessages(data.messages);
                
                
            } else {
                messageDisplay.innerHTML = `<div style="text-align: center; color: red;">Error: ${data.message || 'Failed to load messages'}</div>`;
            }
        })
        .catch(error => {
            console.error('Error fetching messages:', error);
            messageDisplay.innerHTML = `<div style="text-align: center; color: red;">Network Error loading messages.</div>`;
        });
    }

    function renderMessages(messages) {
        const isInitialLoad = messageDisplay.innerHTML === 'Loading messages...';
        const shouldScroll = messageDisplay.scrollTop + messageDisplay.clientHeight >= messageDisplay.scrollHeight - 30;
        
        
        const currentMessageCount = messageDisplay.querySelectorAll('.message').length;
        if (messages.length === currentMessageCount && !isInitialLoad) {
            
            return;
        }

        messageDisplay.innerHTML = '';
        if (messages.length === 0) {
            messageDisplay.innerHTML = '<div style="text-align: center; color: #888; padding-top: 20px;">No messages yet. Say hi!</div>';
            return;
        }

        messages.forEach(msg => {
            const msgDiv = document.createElement('div');
            
            const time = msg.sent_at ? new Date(msg.sent_at).toLocaleString() : 'just now';
            const msgClass = (msg.sender_id == MY_ID) ? 'sent' : 'received';
            const senderName = msg.sender_id != MY_ID && currentContactId.startsWith('group_') ? `<strong>${escapeHTML(msg.sender_name)}:</strong><br>` : '';

            let content = '';
            
            // File attachment
            if (msg.file_path) {
                const filePath = `../${msg.file_path}`; 
                const fileName = msg.file_path.substring(msg.file_path.lastIndexOf('/') + 1);
                content += `<a href="${filePath}" target="_blank" class="file-link" title="Download File">
                    <i class="fas fa-file-download"></i> ${escapeHTML(fileName)}
                </a>`;
            }
            
            // Message text
            if (msg.message) {
                content += `<p style="margin: 0; line-height: 1.4;">${escapeHTML(msg.message)}</p>`;
            }

            // Read receipt indicator
            let readReceipt = '';
            if (msg.sender_id == MY_ID && msg.is_read) {
                readReceipt = `<small style="color: #21f33dff; display: block; font-size: 0.8em; margin-top: 3px; font-weight: 600;">✓✓ Read</small>`;
            } else if (msg.sender_id == MY_ID) {
                readReceipt = `<small style="color: #d5dcdaff; display: block; font-size: 0.8em; margin-top: 3px;">✓ Sent</small>`;
            }

            // Edited indicator
            let editedIndicator = '';
            if (msg.is_edited) {
                editedIndicator = `<small style="color: #999; display: block; font-size: 0.8em; margin-top: 3px;">(edited ${new Date(msg.edit_timestamp).toLocaleTimeString()})</small>`;
            }

            // Action buttons (only for own messages)
            let actionButtons = '';
            if (msg.sender_id == MY_ID) {
                const sentTime = new Date(msg.sent_at);
                const currentTime = new Date();
                const diffMinutes = (currentTime - sentTime) / (1000 * 60);
                
                actionButtons = `<div class="msg-action-buttons">`;
                
                // Edit button (within 10 minutes)
                if (diffMinutes <= 10) {
                    actionButtons += `<button class="msg-action-btn" onclick="openEditMessageModal(${msg.id})" title="Edit message"><i class="fas fa-edit"></i></button>`;
                }
                
                // Delete button (also within 10 minutes)
                if (diffMinutes <= 10) {
                    actionButtons += `<button class="msg-action-btn" onclick="openDeleteMessageModal(${msg.id})" title="Delete message"><i class="fas fa-trash"></i></button>`;
                }
                
                actionButtons += `</div>`;
            }

            msgDiv.className = `message ${msgClass}`;
            
            msgDiv.innerHTML = `
                <div class="msg-content">
                    ${senderName}
                    ${content}
                    ${editedIndicator}
                    ${readReceipt}
                    <span class="message-time">${time}</span>
                </div>
            `;
            
            // Create wrapper for message and buttons
            const messageWrapper = document.createElement('div');
            messageWrapper.className = `message-wrapper ${msgClass}`;
            
            if (msg.sender_id == MY_ID) {
                // Add buttons before the message for sent messages
                messageWrapper.innerHTML = `${actionButtons}`;
            }
            
            messageWrapper.appendChild(msgDiv);
            messageDisplay.appendChild(messageWrapper);
        });

        // Auto-scroll if needed
        if (shouldScroll || isInitialLoad) {
            messageDisplay.scrollTop = messageDisplay.scrollHeight;
        }
    }



    function displayFileName() {
        if (fileAttachment.files.length > 0) {
            filenameDisplay.innerHTML = `Attachment: <strong>${escapeHTML(fileAttachment.files[0].name)}</strong> <i class="fas fa-times-circle" style="color: red; cursor: pointer;" onclick="clearFileAttachment()"></i>`;
            filenameDisplay.style.display = 'block';
        } else {
            clearFileAttachment();
        }
    }

    function clearFileAttachment() {
        fileAttachment.value = null;
        filenameDisplay.style.display = 'none';
        filenameDisplay.innerHTML = '';
    }

    function handleSendMessage(e) {
        e.preventDefault();
        const messageText = messageInput.value.trim();
        const file = fileAttachment.files[0];

        if ((messageText === '' && !file) || !currentContactId) return;

        const formData = new FormData();
        formData.append('target_id', currentContactId);
        formData.append('message_text', messageText);
        if (file) {
            formData.append('attachment', file);
        }

        
        messageInput.disabled = true;
        messageForm.querySelector('button').disabled = true;

        fetch('chat_action.php?action=send_message', {
            method: 'POST',
            body: formData 
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                messageInput.value = '';
                clearFileAttachment();
                loadMessages(); 
            } else {
                alert('Error sending message: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error sending message:', error);
            alert('Network error or server failed to process the message.');
        })
        .finally(() => {
            
            messageInput.disabled = false;
            messageForm.querySelector('button').disabled = false;
        });
    }


    function handleAddContact(e) {
        e.preventDefault();
        const email = addContactEmail.value.trim();
        if (email === '') return;

        this.querySelector('button').disabled = true;
        showToast('Adding...', 'info');

        fetch('chat_action.php?action=add_contact', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Contact added!', 'success');
                addContactEmail.value = '';
                loadContacts(); 
            } else {
                showToast(data.message, 'error');
            }
        })
        .catch(error => {
            console.error('Add contact error:', error);
            showToast('An unexpected error occurred.', 'error');
        })
        .finally(() => {
            this.querySelector('button').disabled = false;
        });
    }


    function openCreateGroupModal() {
        groupNameInput.value = '';
        groupModalMessage.textContent = '';
        availableMembersList.innerHTML = '';
        
        
        availableMembers.forEach(member => {
            
            if (member.id != MY_ID) {
                const label = document.createElement('label');
                label.innerHTML = `<input type="checkbox" data-member-id="${member.id}"> ${escapeHTML(member.name)} (${member.role})`;
                availableMembersList.appendChild(label);
            }
        });

        
        availableMembersList.innerHTML += `<input type="hidden" data-member-id="${MY_ID}" checked>`;
        
        createGroupModal.style.display = 'block';
    }

    function closeCreateGroupModal() {
        createGroupModal.style.display = 'none';
    }

    function handleCreateGroup() {
        const groupName = groupNameInput.value.trim();
        const selectedCheckboxes = availableMembersList.querySelectorAll('input[type="checkbox"]:checked');
        let memberIds = [];

        
        selectedCheckboxes.forEach(checkbox => memberIds.push(checkbox.dataset.memberId));
        availableMembersList.querySelectorAll('input[type="hidden"]').forEach(input => memberIds.push(input.dataset.memberId));
        
        
        memberIds = Array.from(new Set(memberIds.map(id => parseInt(id)))); 

        if (groupName === '') {
            groupModalMessage.textContent = 'Group name cannot be empty.';
            return;
        }
        
        if (memberIds.length < 2) { 
            groupModalMessage.textContent = 'Group must have at least one other member.';
            return;
        }

        groupModalMessage.textContent = 'Creating group...';
        submitCreateGroup.disabled = true;

        fetch('chat_action.php?action=create_group', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                group_name: groupName, 
                member_ids: memberIds 
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Group created successfully!');
                closeCreateGroupModal();
                loadContacts(); 
            } else {
                groupModalMessage.textContent = 'Error: ' + (data.message || 'Unknown error');
            }
        })
        .catch(error => {
            console.error('Create group error:', error);
            groupModalMessage.textContent = 'Network error during group creation.';
        })
        .finally(() => {
            submitCreateGroup.disabled = false;
        });
    }

    function closeDetailsModal() {
    detailsModal.style.display = 'none';
}

function openDetailsModal(targetIdRaw, targetName, isGroup) {
    currentTargetIdForAction = targetIdRaw;
    currentIsGroupForAction = isGroup;
    currentIsCreator = false;
    currentTargetName = targetName; // Save the name
    
    detailsTitle.textContent = isGroup ? `Group Details: ${targetName}` : `Contact Details: ${targetName}`;
    detailsContent.innerHTML = 'Loading...';
    detailsActions.innerHTML = '';
    detailsModal.style.display = 'block';

    if (isGroup) {
        fetchGroupDetails(targetIdRaw);
    } else {
        renderContactDetails(targetIdRaw);
    }
}

function fetchGroupDetails(group_id_raw) {
    fetch('chat_action.php?action=fetch_group_details', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ group_id_raw: group_id_raw })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const info = data.info;
            const members = data.members;
            const myId = MY_ID; 

            
            currentIsCreator = (info.created_by == myId); 

            let html = `
                <p><strong>Created By:</strong> ${escapeHTML(info.created_by_name)} ${currentIsCreator ? '(You)' : ''}</p>
                <h4>Members (${members.length}):</h4>
                <ul>
            `;
            members.forEach(member => {
                html += `<li>${escapeHTML(member.name)} (${escapeHTML(member.role)}) ${member.id == myId ? ' (You)' : ''}</li>`;
            });
            html += `</ul>`;
            detailsContent.innerHTML = html;

            
            let actionsHTML = '';
            actionsHTML += `<button class="google-meet-btn" onclick="openMeetingModal(true)">
                <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54h3.54v4.17H8.5v-4.17H5.04L7.79 9.29M9.5 6.5h5v2h-5z"/>
                </svg>
                <span>Create Meeting</span>
            </button>`;
            if (currentIsCreator) {
                actionsHTML += `<button class="btn btn-success" onclick="addGroupMember()" style="background-color: #4CAF50;">➕ Add Member</button>`;
                actionsHTML += `<button class="btn btn-danger" onclick="deleteGroup()">Delete Group</button>`;
            } else {
                actionsHTML += `<button class="btn btn-warning" onclick="leaveGroup()">Leave Group</button>`;
            }
            detailsActions.innerHTML = actionsHTML;

        } else {
            detailsContent.innerHTML = `<p style="color:red;">Error loading details: ${data.message}</p>`;
        }
    })
    .catch(error => {
        detailsContent.innerHTML = `<p style="color:red;">Network Error: ${error}</p>`;
    });
}

function renderContactDetails(contact_id_raw) {
    detailsContent.innerHTML = `<p>This is an individual contact.</p>`;
    
    let actionsHTML = `<button class="google-meet-btn" onclick="openMeetingModal(false)">
        <svg viewBox="0 0 24 24" fill="currentColor">
            <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zm-5.04-6.71l-2.75 3.54h3.54v4.17H8.5v-4.17H5.04L7.79 9.29M9.5 6.5h5v2h-5z"/>
        </svg>
        <span>Create Meeting</span>
    </button>`;
    actionsHTML += `<button class="btn btn-danger" onclick="blockContact('${contact_id_raw}')" style="background-color: #f44336;">Block Contact</button>`;
    actionsHTML += `<button class="btn btn-danger" onclick="deleteContact('${contact_id_raw}')">Remove Contact</button>`;
    detailsActions.innerHTML = actionsHTML;
}


function leaveGroup() {
    if (!confirm('Are you sure you want to leave this group?')) return;
    performAction('leave_group', currentTargetIdForAction, 'Leaving group...', 'Successfully left the group.').then(success => {
        if (success) {
            closeDetailsModal();
            loadContacts();
            chatHeader.classList.remove('group-chat', 'individual-chat');
            chatHeader.innerHTML = '<strong style="color: #a8b2c1;">💬 Select a contact to start chatting</strong>';
            messageForm.style.display = 'none';
        }
    });
}

function deleteGroup() {
    if (!confirm('WARNING: Are you sure you want to delete this group? This action is irreversible.')) return;
    performAction('delete_group', currentTargetIdForAction, 'Deleting group...', 'Group deleted successfully.').then(success => {
        if (success) {
            closeDetailsModal();
            loadContacts();
            chatHeader.classList.remove('group-chat', 'individual-chat');
            chatHeader.innerHTML = '<strong style="color: #a8b2c1;">💬 Select a contact to start chatting</strong>';
            messageForm.style.display = 'none';
        }
    });
}

function deleteContact(contact_id_raw) {
    if (!confirm('⚠️ WARNING: Delete this contact?\n\nThis will permanently delete:\n• Contact from your list\n• All chat messages with this person\n\nThis action cannot be undone!')) return;
     performAction('delete_contact', contact_id_raw, 'Removing contact...', 'Contact and chat history removed successfully.').then(success => {
        if (success) {
            closeDetailsModal();
            loadContacts();
            chatHeader.classList.remove('group-chat', 'individual-chat');
            chatHeader.innerHTML = '<strong style="color: #a8b2c1;">💬 Select a contact to start chatting</strong>';
            messageForm.style.display = 'none';
        }
    });
}



function performAction(action, targetIdRaw, loadingMsg, successMsg) {
    detailsActions.innerHTML = `<p>${loadingMsg}</p>`;
    return fetch(`chat_action.php?action=${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target_id_raw: targetIdRaw })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast(successMsg, 'success');
            return true;
        } else {
            showToast('Error: ' + (data.message || 'Unknown error'), 'error');
            return false;
        }
    })
    .catch(error => {
        showToast('Network error: ' + error, 'error');
        return false;
    })
    .finally(() => {
        
        if(detailsModal.style.display === 'block') {
             
             if (currentIsGroupForAction) {
                // Simplified: Re-open the modal to reload state, or rely on the function logic
                openDetailsModal(currentTargetIdForAction, detailsTitle.textContent.replace(/Group Details: |Contact Details: /, ''), currentIsGroupForAction);
            } else {
                 renderContactDetails(currentTargetIdForAction);
            }
        }
    });
}
    
    
    const createMeetingModal = document.getElementById('createMeetingModal');
    const meetingForm = document.getElementById('meetingForm');
    const meetingMessage = document.getElementById('meetingMessage');
    const googleAuthStatus = document.getElementById('googleAuthStatus');
    
    function openMeetingModal(isGroup = false) {
        currentMeetingIsGroup = isGroup;
        meetingForm.reset();
        meetingMessage.textContent = '';
        
        
        const now = new Date();
        const startTime = new Date(now.getTime() + 60 * 60 * 1000);
        document.getElementById('meetingStart').value = formatDateTimeLocal(startTime);
        document.getElementById('meetingEnd').value = formatDateTimeLocal(new Date(startTime.getTime() + 60 * 60 * 1000));
        
        
        checkGoogleAuthStatus();
        
        createMeetingModal.style.display = 'block';
    }
    
    function closeMeetingModal() {
        createMeetingModal.style.display = 'none';
    }
    
    function formatDateTimeLocal(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    }
    
    function checkGoogleAuthStatus() {
        fetch('google_auth.php?action=check_status')
            .then(res => res.json())
            .then(data => {
                const statusDiv = document.getElementById('googleAuthStatus');
                if (data.authorized) {
                    statusDiv.innerHTML = `<div style="color: #155724; background: #d4edda; padding: 12px; border-radius: 4px; border-left: 4px solid #28a745;">
                        ✓ <strong>Google Calendar Connected</strong><br>
                        <small style="color: #0c5460;">Email: ${escapeHTML(data.google_email || 'Unknown')}</small>
                        <button onclick="signOutGoogle()" style="background: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 3px; cursor: pointer; font-size: 0.85em; margin-top: 8px; width: 100%;">
                            🔓 Sign Out
                        </button>
                    </div>`;
                    document.getElementById('submitMeetingBtn').disabled = false;
                } else {
                    statusDiv.innerHTML = `<div style="color: #856404; background: #fff3cd; padding: 12px; border-radius: 4px; border-left: 4px solid #ffc107;">
                        ⚠ <strong>Google Calendar Not Connected</strong><br>
                        <a href="google_auth.php" target="_blank" style="color: #0056b3; text-decoration: underline; font-weight: bold;">Click here to authorize →</a><br>
                        <small style="color: #666; margin-top: 5px; display: block;">This is required to create Google Meet meetings.</small>
                    </div>`;
                    document.getElementById('submitMeetingBtn').disabled = true;
                }
            })
            .catch(error => {
                console.error('Error checking auth status:', error);
                const statusDiv = document.getElementById('googleAuthStatus');
                statusDiv.innerHTML = `<div style="color: #721c24; background: #f8d7da; padding: 12px; border-radius: 4px; border-left: 4px solid #f5c6cb;">
                    ❌ Error checking authorization status
                </div>`;
            });
    }
    
    function signOutGoogle() {
        if (!confirm('Are you sure you want to disconnect Google Calendar? You will need to re-authorize to create meetings.')) {
            return;
        }
        
        fetch('google_auth.php?action=logout')
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert('✓ Google Calendar disconnected successfully.');
                    
                    checkGoogleAuthStatus();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Sign out error:', error);
                alert('Network error during sign out');
            });
    }
    
    meetingForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const title = document.getElementById('meetingTitle').value;
        const startTime = document.getElementById('meetingStart').value;
        const endTime = document.getElementById('meetingEnd').value;
        
        if (!title || !startTime || !endTime) {
            meetingMessage.textContent = 'Please fill in all fields.';
            return;
        }
        
        const action = currentMeetingIsGroup ? 'create_meeting_group' : 'create_meeting_1to1';
        const endpoint = 'chat_action.php?action=' + action;
        
        
        const formData = new FormData();
        formData.append('title', title);
        formData.append('start_time', convertLocalToUTC(startTime));
        formData.append('end_time', convertLocalToUTC(endTime));
        
        if (currentMeetingIsGroup) {
            
            const groupId = String(currentTargetIdForAction).replace('group_', '');
            formData.append('group_id', groupId);
            console.log('Creating group meeting:', { groupId, title, startTime, endTime });
        } else {
            formData.append('receiver_id', currentTargetIdForAction);
            console.log('Creating 1:1 meeting:', { receiverId: currentTargetIdForAction, title, startTime, endTime });
        }
        
        const submitBtn = meetingForm.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        meetingMessage.style.color = '#666';
        meetingMessage.textContent = 'Creating meeting...';
        
        console.log('Fetching:', endpoint);
        
        fetch(endpoint, {
            method: 'POST',
            body: formData
        })
        .then(res => {
            console.log('Response status:', res.status);
            return res.text();  
        })
        .then(text => {
            console.log('Response text:', text.substring(0, 200));  
            
            
            if (text.trim().startsWith('<')) {
                throw new Error('Server returned HTML instead of JSON. Server error:\n' + text.substring(0, 500));
            }
            
            
            try {
                return JSON.parse(text);
            } catch (e) {
                throw new Error('Invalid JSON response: ' + e.message + '\nResponse: ' + text.substring(0, 500));
            }
        })
        .then(data => {
            if (data.success) {
                meetingMessage.innerHTML = `
                    <div style="color: #2e7d32; text-align: center; padding: 20px; background: #e8f5e9; border-radius: 4px; margin: 10px 0; border: 2px solid #4caf50;">
                        <strong style="font-size: 1.2em; display: block; margin-bottom: 15px;">✓ Meeting Created Successfully!</strong>
                        
                        <p style="margin: 10px 0; font-size: 0.95em; color: #555;"><strong>Meeting Link:</strong></p>
                        <div style="display: flex; gap: 10px; align-items: center; justify-content: center; margin: 10px 0; flex-wrap: wrap;">
                            <a href="${escapeHTML(data.meeting_link)}" 
                               target="_blank" 
                               style="flex: 1; min-width: 250px; color: #1976d2; text-decoration: underline; word-break: break-all; padding: 10px; background: white; border-radius: 3px; font-weight: bold; border: 1px solid #90caf9;">
                                ${escapeHTML(data.meeting_link)}
                            </a>
                            <button onclick="copyToClipboard('${escapeHTML(data.meeting_link)}')" 
                                    style="background: #4caf50; color: white; border: none; padding: 10px 15px; border-radius: 3px; cursor: pointer; font-weight: bold; white-space: nowrap;">
                                📋 Copy Link
                            </button>
                        </div>
                        
                        <p style="margin: 15px 0 8px 0; font-size: 0.85em; color: #666;">
                            <i class="fas fa-clock"></i> <strong>Scheduled:</strong> ${startTime.replace('T', ' ')} → ${endTime.replace('T', ' ')}<br>
                            <strong>Event ID:</strong> <code style="background: #f5f5f5; padding: 3px 6px; border-radius: 2px; font-family: monospace; font-size: 0.8em;">${escapeHTML(data.event_id)}</code>
                        </p>
                        <div style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #c8e6c9; font-size: 0.85em; color: #555;">
                            <strong>💡 Next Steps:</strong><br>
                            ✓ Refresh your <a href="https://calendar.google.com" target="_blank" style="color: #1976d2; text-decoration: underline;">Google Calendar</a> to see the event<br>
                            ✓ Share the meeting link with attendees<br>
                            ✓ Attendees will receive calendar invitations
                        </div>
                        <button onclick="closeMeetingModal()" style="background: #1976d2; color: white; border: none; padding: 10px 20px; border-radius: 3px; cursor: pointer; margin-top: 15px; font-weight: bold; width: 100%;">
                            ✓ Close
                        </button>
                    </div>
                `;
                meetingMessage.style.color = '#2e7d32';
            } else {
                meetingMessage.style.color = 'red';
                
                let errorMsg = data.message || 'Failed to create meeting';
                if (data.debug) {
                    try {
                        const debugData = typeof data.debug === 'string' ? JSON.parse(data.debug) : data.debug;
                        if (debugData.error && debugData.error.message) {
                            errorMsg += ' - ' + debugData.error.message;
                        }
                    } catch (e) {
                        
                    }
                }
                meetingMessage.textContent = 'Error: ' + errorMsg;
                console.error('Meeting creation error:', data);
            }
        })
        .catch(error => {
            meetingMessage.style.color = 'red';
            meetingMessage.textContent = 'Network error: ' + error;
            console.error('Fetch error:', error);
        })
        .finally(() => {
            submitBtn.disabled = false;
        });
    });
    
    function convertLocalToUTC(localDateTime) {
        
        
        
        const date = new Date(localDateTime);
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        const seconds = String(date.getSeconds()).padStart(2, '0');
        
        
        return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
    }
    
    // Copy meeting link to clipboard
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text).then(() => {
            alert('✓ Meeting link copied to clipboard!');
        }).catch(err => {
            console.error('Failed to copy:', err);
            // Fallback for older browsers
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            try {
                document.execCommand('copy');
                alert('✓ Meeting link copied to clipboard!');
            } catch (err) {
                alert('Failed to copy link');
            }
            document.body.removeChild(textArea);
        });
    }
    
    
    let currentMeetingIsGroup = false;

    function escapeHTML(str) {
        if (str === null || str === undefined) return '';
        return String(str).replace(/[&<>\"']/g, m => ({
            '&': '&amp;', '<': '&lt;', '>': '&gt;', '\"': '&quot;', "'": '&#39;'
        }[m]));
    }

    function showToast(message, type = 'info') {
        addContactToast.textContent = message;
        if (type === 'success') {
            addContactToast.style.color = 'green';
        } else if (type === 'error') {
            addContactToast.style.color = 'red';
        } else {
            addContactToast.style.color = 'black';
        }
        setTimeout(() => {
            if (addContactToast.textContent === message) {
                addContactToast.textContent = '';
            }
        }, 60000);
    }

    // Blocked contacts management
    function openBlockedContactsModal() {
        blockedContactsModal.style.display = 'block';
        loadBlockedContacts();
    }

    function closeBlockedContactsModal() {
        blockedContactsModal.style.display = 'none';
    }

    function loadBlockedContacts() {
        fetch('chat_action.php?action=fetch_blocked_contacts')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    renderBlockedContactsList(data.blocked_contacts);
                } else {
                    blockedContactsList.innerHTML = '<p style="padding: 10px; text-align: center; color: #999;">Failed to load blocked contacts</p>';
                }
            })
            .catch(error => {
                console.error('Error loading blocked contacts:', error);
                blockedContactsList.innerHTML = '<p style="padding: 10px; text-align: center; color: #999;">Error loading blocked contacts</p>';
            });
    }

    function renderBlockedContactsList(blockedContacts) {
        blockedContactsList.innerHTML = '';
        if (!blockedContacts || blockedContacts.length === 0) {
            blockedContactsList.innerHTML = '<p style="padding: 10px; text-align: center; color: #999;">No blocked contacts</p>';
            return;
        }
        
        blockedContacts.forEach(contact => {
            const item = document.createElement('div');
            item.style.cssText = 'display: flex; justify-content: space-between; align-items: center; padding: 10px; border-bottom: 1px solid #eee; gap: 10px;';
            item.innerHTML = `
                <div style="flex: 1;">
                    <div style="font-weight: 600;">${escapeHTML(contact.name)}</div>
                    <div style="font-size: 0.85em; color: #666;">${escapeHTML(contact.role)}</div>
                </div>
                <button class="btn btn-sm" onclick="unblockContact(${contact.id})" style="background-color: #4CAF50; color: white; padding: 5px 10px; border: none; border-radius: 4px; cursor: pointer;">Unblock</button>
            `;
            blockedContactsList.appendChild(item);
        });
    }

    function blockContact(contactId) {
        if (!confirm('Block this contact? You will not receive their messages.\n\nNote: The contact list will need to be refreshed to see changes.')) return;
        
        fetch('chat_action.php?action=block_contact', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contact_id: contactId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Contact blocked. Refreshing...', 'success');
                closeDetailsModal();
                setTimeout(() => {
                    loadContacts();
                }, 500);
            } else {
                showToast('Error: ' + (data.message || 'Failed to block contact'), 'error');
            }
        })
        .catch(error => {
            console.error('Error blocking contact:', error);
            showToast('Error blocking contact', 'error');
        });
    }

    function unblockContact(contactId) {
        fetch('chat_action.php?action=unblock_contact', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contact_id: contactId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('Contact unblocked', 'success');
                loadBlockedContacts();
            } else {
                showToast('Error: ' + (data.message || 'Failed to unblock contact'), 'error');
            }
        })
        .catch(error => {
            console.error('Error unblocking contact:', error);
            showToast('Error unblocking contact', 'error');
        });
    }

    // ==================== MESSAGE SEARCH ====================
    function toggleSearchMessages() {
        const searchContainer = document.getElementById('search-messages-container');
        const searchInput = document.getElementById('search-messages-input');
        const isVisible = searchContainer.classList.contains('active');
        
        if (isVisible) {
            // Hide search
            searchContainer.classList.remove('active');
            loadMessages(); // Reload normal messages
        } else {
            // Show search
            searchContainer.classList.add('active');
            searchInput.focus();
            searchInput.value = '';
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('search-messages-input');
        if (searchInput) {
            searchInput.addEventListener('input', debounce(function() {
                searchMessagesHandler();
            }, 300));
        }
    });

    function searchMessagesHandler() {
        const query = document.getElementById('search-messages-input').value.trim();
        if (!query) {
            loadMessages(); // Show all messages if search is empty
            return;
        }

        const formData = new FormData();
        formData.append('target_id', currentContactId);
        formData.append('search_query', query);

        fetch('chat_action.php?action=search_messages', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                renderSearchResults(data.messages);
            } else {
                messageDisplay.innerHTML = '<p style="text-align: center; color: red; padding: 20px;">Error: ' + data.message + '</p>';
            }
        })
        .catch(error => {
            console.error('Search error:', error);
            messageDisplay.innerHTML = '<p style="text-align: center; color: red; padding: 20px;">Search failed</p>';
        });
    }

    function renderSearchResults(messages) {
        messageDisplay.innerHTML = '';
        if (!messages || messages.length === 0) {
            messageDisplay.innerHTML = '<div style="text-align: center; padding-top: 20px; color: #999;">No messages found matching your search</div>';
            return;
        }

        // Show search result count
        const resultCount = `<div style="padding: 12px 16px; background: #f0f2f5; border-bottom: 1px solid #e0e0e0; text-align: center; color: #667eea; font-size: 13px; font-weight: 600;">Found ${messages.length} message(s)</div>`;
        messageDisplay.innerHTML = resultCount;

        // Display search results as messages
        messages.forEach(msg => {
            const msgDiv = document.createElement('div');
            const time = msg.sent_at ? new Date(msg.sent_at).toLocaleString() : 'just now';
            const msgClass = (msg.sender_id == MY_ID) ? 'sent' : 'received';
            const senderName = msg.sender_id != MY_ID && currentContactId.startsWith('group_') ? `<strong>${escapeHTML(msg.sender_name)}:</strong><br>` : '';
            
            let content = '';
            if (msg.message) {
                // Highlight search term in message
                const query = document.getElementById('search-messages-input').value.trim();
                const regex = new RegExp(`(${query})`, 'gi');
                const highlightedMsg = escapeHTML(msg.message).replace(regex, '<mark style="background-color: #ffeb3b; padding: 2px;">$1</mark>');
                content = `<p style="margin: 0; line-height: 1.4;">${highlightedMsg}</p>`;
            }
            
            msgDiv.className = `message ${msgClass}`;
            msgDiv.innerHTML = `
                ${senderName}
                ${content}
                <span class="message-time">${time}</span>
            `;
            messageDisplay.appendChild(msgDiv);
        });
    }

    function scrollToMessage(messageId) {
        loadMessages(); // Reload to ensure message is visible
        setTimeout(() => {
            messageDisplay.scrollTop = messageDisplay.scrollHeight;
        }, 100);
    }

    function debounce(func, delay) {
        let timeoutId;
        return function(...args) {
            clearTimeout(timeoutId);
            timeoutId = setTimeout(() => func.apply(this, args), delay);
        };
    }

    // ==================== MESSAGE EDITING ====================
    let currentEditingMessageId = null;

    function openEditMessageModal(messageId) {
        currentEditingMessageId = messageId;
        const editModal = document.getElementById('editMessageModal');
        const textArea = document.getElementById('editMessageText');
        const errorDiv = document.getElementById('editMessageError');
        
        // Clear previous state
        textArea.value = '';
        errorDiv.textContent = '';
        
        // Get message text from DOM
        const messageElement = document.querySelector(`.message:has(.msg-action-btn[onclick*="openEditMessageModal(${messageId})"])`);
        if (messageElement) {
            const messageText = messageElement.querySelector('p');
            if (messageText) {
                textArea.value = messageText.textContent;
            }
        }
        
        editModal.style.display = 'flex';
        textArea.focus();
    }

    function closeEditMessageModal() {
        document.getElementById('editMessageModal').style.display = 'none';
        currentEditingMessageId = null;
    }

    function submitEditMessage() {
        const newText = document.getElementById('editMessageText').value.trim();
        const errorDiv = document.getElementById('editMessageError');
        
        if (!newText) {
            errorDiv.textContent = 'Message cannot be empty';
            return;
        }

        if (!currentEditingMessageId) {
            errorDiv.textContent = 'Error: No message selected';
            return;
        }

        fetch('chat_action.php?action=edit_message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message_id: currentEditingMessageId,
                new_text: newText
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('✓ Message edited', 'success');
                closeEditMessageModal();
                loadMessages();
            } else {
                errorDiv.textContent = '❌ ' + data.message;
            }
        })
        .catch(error => {
            console.error('Edit error:', error);
            errorDiv.textContent = 'Error editing message: ' + error;
        });
    }

    // ==================== MESSAGE DELETION ====================
    let currentDeletingMessageId = null;

    function openDeleteMessageModal(messageId) {
        currentDeletingMessageId = messageId;
        document.getElementById('deleteMessageModal').style.display = 'flex';
        document.getElementById('deleteMessageError').textContent = '';
    }

    function closeDeleteMessageModal() {
        document.getElementById('deleteMessageModal').style.display = 'none';
        currentDeletingMessageId = null;
    }


    function deleteMessageForAll() {
        if (!currentDeletingMessageId) return;

        fetch('chat_action.php?action=delete_message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                message_id: currentDeletingMessageId,
                permanent: true
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                showToast('✓ ' + data.message, 'success');
                closeDeleteMessageModal();
                loadMessages();
            } else {
                document.getElementById('deleteMessageError').textContent = '❌ ' + data.message;
            }
        })
        .catch(error => {
            console.error('Delete error:', error);
            document.getElementById('deleteMessageError').textContent = 'Error: ' + error;
        });
    }

    // Close modals when clicking outside
    window.onclick = function(event) {
        const editModal = document.getElementById('editMessageModal');
        const deleteModal = document.getElementById('deleteMessageModal');
        
        if (event.target === editModal) {
            closeEditMessageModal();
        }
        if (event.target === deleteModal) {
            closeDeleteMessageModal();
        }
    }

    // ==================== ADD MEMBER TO GROUP ====================
    let addMemberModal = null;

    function createAddMemberModal() {
        if (addMemberModal) return addMemberModal;
        
        const modal = document.createElement('div');
        modal.id = 'addMemberModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content" style="width: 450px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="margin: 0;">➕ Add Member to Group</h3>
                    <span class="close-button" onclick="closeAddMemberModal()" style="cursor: pointer; font-size: 24px; line-height: 1;">&times;</span>
                </div>
                <div id="memberSelectionContainer" style="max-height: 300px; overflow-y: auto; margin-bottom: 15px; border: 1px solid #e0e0e0; border-radius: 4px; padding: 10px;">
                    <p style="text-align: center; color: #999;">Loading members...</p>
                </div>
                <div id="addMemberMessage" style="color: red; margin-bottom: 10px; font-size: 0.9em;"></div>
                <div style="display: flex; gap: 10px;">
                    <button onclick="submitAddMember()" class="btn" style="flex: 1; background-color: #4CAF50;">Add Selected</button>
                    <button onclick="closeAddMemberModal()" class="btn" style="flex: 1; background-color: #ccc;">Cancel</button>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
        addMemberModal = modal;
        return modal;
    }

    function openAddMemberModal() {
        const modal = createAddMemberModal();
        modal.style.display = 'flex';
        loadAvailableMembersForGroup();
    }

    function closeAddMemberModal() {
        if (addMemberModal) {
            addMemberModal.style.display = 'none';
        }
    }

    function loadAvailableMembersForGroup() {
        const groupId = String(currentTargetIdForAction).replace('group_', '');
        if (!groupId) return;

        fetch('chat_action.php?action=get_group_members', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ group_id: parseInt(groupId) })
        })
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('memberSelectionContainer');
            
            // Get current group member IDs
            const groupMemberIds = data.success && data.current_members ? 
                data.current_members.map(m => m.id) : [];
            
            console.log('Group members:', groupMemberIds);
            console.log('Available members:', availableMembers);
            
            // Filter availableMembers to exclude those already in group
            const availableToAdd = availableMembers.filter(member => {
                const isNotInGroup = !groupMemberIds.includes(member.id);
                console.log(`Member ${member.id} (${member.name}): in group = ${!isNotInGroup}`);
                return isNotInGroup;
            });
            
            console.log('Available to add:', availableToAdd);
            
            if (availableToAdd && availableToAdd.length > 0) {
                container.innerHTML = '';
                availableToAdd.forEach(member => {
                    const label = document.createElement('label');
                    label.style.cssText = 'display: block; padding: 8px; cursor: pointer; border-radius: 4px; transition: background 0.2s;';
                    label.innerHTML = `
                        <input type="checkbox" data-member-id="${member.id}" style="margin-right: 8px;">
                        <strong>${escapeHTML(member.name)}</strong> (${escapeHTML(member.role)})
                    `;
                    label.addEventListener('mouseenter', () => label.style.background = '#f5f5f5');
                    label.addEventListener('mouseleave', () => label.style.background = 'transparent');
                    container.appendChild(label);
                });
            } else {
                container.innerHTML = '<p style="text-align: center; color: #999;">所有联系人都已在群组中</p>';
            }
        })
        .catch(error => {
            console.error('Error loading members:', error);
            document.getElementById('memberSelectionContainer').innerHTML = '<p style="text-align: center; color: red;">加载成员出错</p>';
        });
    }

    function submitAddMember() {
        // Check if user is group creator
        if (!currentIsCreator) {
            document.getElementById('addMemberMessage').textContent = '❌ 只有群组创建者才能添加成员';
            document.getElementById('addMemberMessage').style.color = 'red';
            return;
        }

        const groupId = String(currentTargetIdForAction).replace('group_', '');
        const selectedCheckboxes = document.querySelectorAll('#addMemberModal input[type="checkbox"]:checked');
        const selectedIds = Array.from(selectedCheckboxes).map(cb => parseInt(cb.dataset.memberId));

        if (selectedIds.length === 0) {
            document.getElementById('addMemberMessage').textContent = '请选择至少一个成员';
            return;
        }

        const msgDiv = document.getElementById('addMemberMessage');
        msgDiv.textContent = '添加成员中...';
        msgDiv.style.color = '#666';

        // Add members one by one
        let completed = 0;
        let failed = 0;
        selectedIds.forEach(memberId => {
            fetch('chat_action.php?action=add_group_member', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    group_id: parseInt(groupId),
                    member_id: memberId
                })
            })
            .then(response => response.json())
            .then(data => {
                completed++;
                console.log(`Add member ${memberId}:`, data);
                if (!data.success) {
                    failed++;
                    msgDiv.textContent = data.message || 'Error adding member';
                    msgDiv.style.color = 'red';
                }
                if (completed === selectedIds.length) {
                    if (failed === 0) {
                        showToast('✓ 成员添加成功', 'success');
                        closeAddMemberModal();
                        openDetailsModal(currentTargetIdForAction, currentTargetName, true);
                    } else {
                        msgDiv.textContent = `❌ 添加 ${failed} 个成员失败`;
                        msgDiv.style.color = 'red';
                    }
                }
            })
            .catch(error => {
                completed++;
                failed++;
                console.error('Add member error:', error);
                msgDiv.textContent = '❌ 网络错误: ' + error.message;
                msgDiv.style.color = 'red';
                if (completed === selectedIds.length) {
                    msgDiv.textContent = `❌ 添加 ${failed} 个成员失败`;
                }
            });
        });
    }

    function addGroupMember() {
        openAddMemberModal();
    }

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (addMemberModal && event.target === addMemberModal) {
            closeAddMemberModal();
        }
    });
</script>
</body>

</html>