<?php
/**
 */

session_start();


if (!isset($_SESSION['loggedin']) || !isset($_SESSION['user_id'])) {
    header('Location: login_process.php');
    exit();
}

require_once 'google_meeting.php';


$message = '';
$error = '';
$authorized = false;

if (isset($_GET['authorized'])) {
    $authorized = true;
    $message = 'Google Calendar successfully connected! You can now create meetings.';
}

if (isset($_GET['error'])) {
    $error = 'Authorization failed: ' . htmlspecialchars($_GET['error']);
}


$auth_url = getGoogleAuthUrl('google_calendar_auth.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Google Calendar Authorization</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            padding: 40px;
            max-width: 500px;
            width: 100%;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #333;
            margin-bottom: 10px;
            font-size: 28px;
        }
        
        .header p {
            color: #666;
            font-size: 14px;
        }
        
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-color: #28a745;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        
        .description {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 20px;
            margin-bottom: 30px;
            color: #555;
            line-height: 1.6;
        }
        
        .description h2 {
            color: #333;
            font-size: 16px;
            margin-bottom: 10px;
        }
        
        .description ul {
            list-style: none;
            padding-left: 0;
        }
        
        .description li {
            padding-bottom: 8px;
        }
        
        .description li:before {
            content: "✓ ";
            color: #28a745;
            font-weight: bold;
            margin-right: 8px;
        }
        
        .button-group {
            display: flex;
            gap: 10px;
            flex-direction: column;
        }
        
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background-color: #667eea;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        
        .google-icon {
            margin-right: 8px;
        }
        
        .loading {
            text-align: center;
            color: #999;
            font-size: 14px;
            margin-top: 20px;
        }
        
        .spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #667eea;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            margin: 10px auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🗓️ Google Calendar Integration</h1>
            <p>Connect your Google Calendar to manage meetings</p>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-success">
                ✓ <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-error">
                ✗ <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <div class="description">
            <h2>Why connect Google Calendar?</h2>
            <ul>
                <li>Automatically create Google Meet links</li>
                <li>Schedule events in your Google Calendar</li>
                <li>Send invitations to all participants</li>
                <li>Automatic email reminders</li>
                <li>Sync with your calendar across devices</li>
            </ul>
        </div>
        
        <div class="button-group">
            <a href="<?php echo htmlspecialchars($auth_url); ?>" class="btn btn-primary">
                <span class="google-icon">🔑</span> Authorize with Google
            </a>
            <a href="javascript:history.back()" class="btn btn-secondary">
                Back
            </a>
        </div>
        
        <div class="loading" id="loading" style="display: none;">
            <p>Redirecting to Google...</p>
            <div class="spinner"></div>
        </div>
    </div>
    
    <script>
        
        document.querySelectorAll('a[href*="accounts.google.com"]').forEach(link => {
            link.addEventListener('click', () => {
                document.getElementById('loading').style.display = 'block';
            });
        });
    </script>
</body>
</html>
