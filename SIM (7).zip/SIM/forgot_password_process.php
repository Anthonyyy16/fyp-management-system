<?php

session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// require PHPMailer files
require 'PHPMailer-7.0.0/src/Exception.php';
require 'PHPMailer-7.0.0/src/PHPMailer.php';
require 'PHPMailer-7.0.0/src/SMTP.php';


require_once 'db_connect.php';
require_once 'email_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);

    // check email in database
    $sql_check = "SELECT id FROM users WHERE email = ?";
    if ($stmt_check = $conn->prepare($sql_check)) {
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows == 1) {
            // randomly generate  OTP
            $otp = rand(100000, 999999);
            $otp_hash = password_hash($otp, PASSWORD_DEFAULT);

            // store OTP in database (password_resets table)
            $sql_insert = "INSERT INTO password_resets (email, otp_hash) VALUES (?, ?)";
            if ($stmt_insert = $conn->prepare($sql_insert)) {
                $stmt_insert->bind_param("ss", $email, $otp_hash);
                $stmt_insert->execute();

                // send OTP to user's email
                $mail = new PHPMailer(true);
                try {
                    //  after =  get email settings from email_config.php
                    $mail->isSMTP();
                    $mail->Host       = SMTP_HOST;
                    $mail->SMTPAuth   = true;
                    $mail->Username   = SMTP_USERNAME;
                    $mail->Password   = SMTP_PASSWORD;
                    $mail->SMTPSecure = SMTP_SECURE;
                    $mail->Port       = SMTP_PORT;
                 
                    $mail->setFrom(SENDER_EMAIL, SENDER_NAME);
                    $mail->addAddress($email); 
                
                    $mail->isHTML(true);
                    $mail->Subject = 'Your Password Reset Code';
                    $mail->Body    = "Hello,<br><br>Your verification code for password reset is: <b>$otp</b><br><br>This code will expire in 10 minutes.<br><br>Thank you,<br>FYP Management System";
                    $mail->AltBody = "Your verification code for password reset is: $otp";

                    $mail->send();
                    
                    $_SESSION['reset_email'] = $email;
                    header("location: otp.php?status=sent");
                    exit();

                } catch (Exception $e) {
    
                    header("location: forgot_password.php?error=mail_failed");
                    exit();
                }
            }
        } else {
        
            header("location: forgot_password.php?error=email_not_found");
            exit();
        }
        $stmt_check->close();
    }
    $conn->close();
}
?>

