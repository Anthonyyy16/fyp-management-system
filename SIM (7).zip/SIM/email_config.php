<?php

// Load PHPMailer autoloader
require_once 'PHPMailer-7.0.0/src/PHPMailer.php';
require_once 'PHPMailer-7.0.0/src/SMTP.php';
require_once 'PHPMailer-7.0.0/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// SMTP
define('SMTP_HOST', 'smtp.gmail.com');

// ----  you need put your email address here ----
//------------------------------------------------
define('SMTP_USERNAME', 'myfypsystem@gmail.com');

// ----  you need put your app password here -----
//------------------------------------------------
// Note: If you use Gmail, you'll need to generate an "app password" instead of using your login password.
define('SMTP_PASSWORD', 'vaom jwcz jnnn yyvw');

// SMTP server port (usually 587 for TLS, 465 for SSL)
define('SMTP_PORT', 587);

define('SMTP_SECURE', 'tls');

// ----  you need put your email address here ----
//------------------------------------------------
// Sender's email 
define('SENDER_EMAIL', 'myfypsystem@gmail.com');


//----  you need put your name here ----
//---------------------------------------
define('SENDER_NAME', 'FYP Management System');

// Initialize PHPMailer
global $mail;
$mail = new PHPMailer(true);

try {
    // Configure SMTP
    $mail->isSMTP();
    $mail->Host = SMTP_HOST;
    $mail->SMTPAuth = true;
    $mail->Username = SMTP_USERNAME;
    $mail->Password = SMTP_PASSWORD;
    $mail->SMTPSecure = SMTP_SECURE;
    $mail->Port = SMTP_PORT;
    
    // Sender info
    $mail->setFrom(SENDER_EMAIL, SENDER_NAME);
    
    // Set charset to UTF-8 for better support
    $mail->CharSet = 'UTF-8';
    
} catch (Exception $e) {
    error_log("PHPMailer initialization error: " . $e->getMessage());
    $mail = null;
}

?>
