<?php
session_start();
header('Content-Type: application/json');
ini_set('display_errors', 0);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);


set_error_handler(function($errno, $errstr, $errfile, $errline) {
    error_log("PHP Error [$errno]: $errstr in $errfile on line $errline");
    if (headers_sent() === false) {
        header('Content-Type: application/json');
        echo json_encode([
            'success' => false,
            'message' => 'Server Error: ' . $errstr,
            'error_detail' => "$errstr in $errfile:$errline"
        ]);
    }
    exit(1);
});

// Register shutdown function to catch fatal errors (including parse errors and fatal runtime errors)
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE])) {
        error_log("FATAL ERROR [{$error['type']}]: {$error['message']} in {$error['file']} on line {$error['line']}");
        if (headers_sent() === false) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => false,
                'message' => 'Fatal Server Error: ' . $error['message'],
                'error_detail' => $error['message'] . ' in ' . $error['file'] . ':' . $error['line']
            ]);
        }
    }
});

if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['student', 'supervisor', 'admin', 'committee'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db_connect.php'; 
define('UPLOAD_DIR_CHATS', 'uploads/chat_files');
if (!is_dir(UPLOAD_DIR_CHATS)) {
    mkdir(UPLOAD_DIR_CHATS, 0777, true);
}

// Ensure chat_messages table has is_edited and edit_timestamp columns
$check_columns = $conn->query("SHOW COLUMNS FROM chat_messages LIKE 'is_edited'");
if ($check_columns && $check_columns->num_rows === 0) {
    $conn->query("ALTER TABLE chat_messages ADD COLUMN is_edited TINYINT(1) DEFAULT 0");
    $conn->query("ALTER TABLE chat_messages ADD COLUMN edit_timestamp TIMESTAMP NULL");
}

// Ensure chat_group_members table exists
$check_table = $conn->query("SHOW TABLES LIKE 'chat_group_members'");
if (!$check_table || $check_table->num_rows === 0) {
    $create_table_sql = "
        CREATE TABLE `chat_group_members` (
            `id` INT AUTO_INCREMENT PRIMARY KEY,
            `group_id` INT NOT NULL,
            `user_id` INT NOT NULL,
            `joined_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY `unique_member` (group_id, user_id),
            FOREIGN KEY (group_id) REFERENCES chat_groups(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
    ";
    $conn->query($create_table_sql);
}

$my_id = (int)$_SESSION['user_id'];
$my_email = $_SESSION['email'] ?? ''; 
$my_role = $_SESSION['role'];
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        
        
        case 'fetch_contacts':
            
            $contacts_map = []; 

            // Get blocked contacts list
            $blocked_query = "SELECT contact_user_id FROM chat_contacts WHERE user_id = ? AND is_blocked = 1";
            $blocked_stmt = $conn->prepare($blocked_query);
            $blocked_stmt->bind_param('i', $my_id);
            $blocked_stmt->execute();
            $blocked_result = $blocked_stmt->get_result();
            $blocked_ids = [];
            while ($row = $blocked_result->fetch_assoc()) {
                $blocked_ids[] = $row['contact_user_id'];
            }
            $blocked_stmt->close();

            $sql_auto = "";
            if ($my_role === 'student') {
                $sql_auto = "SELECT id, name, role 
                             FROM users 
                             WHERE id = (SELECT supervisor_id FROM users WHERE id = ?)";
            } else { 
                $sql_auto = "SELECT id, name, role 
                             FROM users 
                             WHERE supervisor_id = ? AND role = 'student'";
            }
            
            $stmt_auto = $conn->prepare($sql_auto);
            $stmt_auto->bind_param('i', $my_id);
            $stmt_auto->execute();
            $result_auto = $stmt_auto->get_result();
            while ($user = $result_auto->fetch_assoc()) {
                if (!in_array($user['id'], $blocked_ids)) {
                    $contacts_map[$user['id']] = $user;
                }
            }
            $stmt_auto->close();


            $sql_manual = "SELECT u.id, u.name, u.role
                           FROM users u
                           JOIN chat_contacts c ON u.id = c.contact_user_id
                           WHERE c.user_id = ? AND c.is_blocked = 0";
            $stmt_manual = $conn->prepare($sql_manual);
            $stmt_manual->bind_param('i', $my_id);
            $stmt_manual->execute();
            $result_manual = $stmt_manual->get_result();
            while ($user = $result_manual->fetch_assoc()) {
                $contacts_map[$user['id']] = $user; 
            }
            $stmt_manual->close();

            
            $sql_messaged = "SELECT u.id, u.name, u.role
                             FROM users u
                             JOIN chat_messages m ON u.id = m.sender_id
                             WHERE m.receiver_id = ? AND m.is_group_message = 0
                             GROUP BY u.id, u.name, u.role"; 
            $stmt_messaged = $conn->prepare($sql_messaged);
            $stmt_messaged->bind_param('i', $my_id);
            $stmt_messaged->execute();
            $result_messaged = $stmt_messaged->get_result();
            while ($user = $result_messaged->fetch_assoc()) {
                if (!in_array($user['id'], $blocked_ids)) {
                    $contacts_map[$user['id']] = $user;
                }
            }
            $stmt_messaged->close();

            unset($contacts_map[$my_id]);

            
            
            $group_query = "
                SELECT 
                    g.id, 
                    g.group_name
                FROM chat_groups g
                JOIN chat_group_members gm ON g.id = gm.group_id
                WHERE gm.user_id = ?
            ";
            $stmt_group = $conn->prepare($group_query);
            $stmt_group->bind_param('i', $my_id);
            $stmt_group->execute();
            $result_group = $stmt_group->get_result();
            
            $groups = [];
            while ($row = $result_group->fetch_assoc()) {
                $groups[] = [
                    'id' => 'group_' . $row['id'], 
                    'name' => $row['group_name'] . ' (Group)',
                    'type' => 'group',
                    'role' => 'N/A'
                ];
            }
            $stmt_group->close();
            
            echo json_encode(['success' => true, 'contacts' => array_values($contacts_map), 'groups' => $groups]);
            break;

        case 'fetch_blocked_contacts':
            // Get all blocked contacts
            $stmt_blocked = $conn->prepare("
                SELECT u.id, u.name, u.email, u.role
                FROM users u
                JOIN chat_contacts c ON u.id = c.contact_user_id
                WHERE c.user_id = ? AND c.is_blocked = 1
                ORDER BY u.name ASC
            ");
            $stmt_blocked->bind_param('i', $my_id);
            $stmt_blocked->execute();
            $blocked_result = $stmt_blocked->get_result();
            
            $blocked_contacts = [];
            while ($row = $blocked_result->fetch_assoc()) {
                $blocked_contacts[] = $row;
            }
            $stmt_blocked->close();
            
            echo json_encode(['success' => true, 'blocked_contacts' => $blocked_contacts]);
            break;
            
        
        case 'fetch_messages':
            $data = json_decode(file_get_contents('php://input'), true);
            $target_id_raw = $data['target_id'] ?? '';
            
            $is_group = strpos($target_id_raw, 'group_') === 0;
            $target_id = $is_group ? (int)substr($target_id_raw, 6) : (int)$target_id_raw;

            if ($is_group) {
                
                $query = "
                    SELECT 
                        cm.id,
                        cm.sender_id, 
                        u.name AS sender_name, 
                        cm.message,             
                        cm.sent_at, 
                        cm.file_path,  
                        cm.is_group_message,
                        cm.is_edited,
                        cm.edit_timestamp,
                        cm.is_read
                    FROM chat_messages cm
                    JOIN users u ON cm.sender_id = u.id
                    WHERE cm.is_group_message = 1 AND cm.group_id = ?
                    ORDER BY cm.sent_at ASC";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('i', $target_id);

            } else {
                
                $query = "
                    SELECT 
                        cm.id,
                        cm.sender_id, 
                        u.name AS sender_name, 
                        cm.message,             
                        cm.sent_at, 
                        cm.file_path,  
                        cm.is_group_message,
                        cm.is_edited,
                        cm.edit_timestamp,
                        cm.is_read
                    FROM chat_messages cm
                    JOIN users u ON cm.sender_id = u.id
                    WHERE cm.is_group_message = 0 AND 
                          ((cm.sender_id = ? AND cm.receiver_id = ?) OR (cm.sender_id = ? AND cm.receiver_id = ?))
                    ORDER BY cm.sent_at ASC";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('iiii', $my_id, $target_id, $target_id, $my_id);
            }

            $stmt->execute();
            $result = $stmt->get_result();
            $messages = [];
            while ($row = $result->fetch_assoc()) {
                $messages[] = [
                    'id' => $row['id'],
                    'sender_id' => $row['sender_id'],
                    'sender_name' => $row['sender_name'],
                    'message' => $row['message'], 
                    'sent_at' => $row['sent_at'],
                    'file_path' => $row['file_path'],
                    'is_edited' => isset($row['is_edited']) ? $row['is_edited'] : 0,
                    'edit_timestamp' => isset($row['edit_timestamp']) ? $row['edit_timestamp'] : null,
                    'is_read' => isset($row['is_read']) ? $row['is_read'] : 0
                ];
            }
            $stmt->close();
            
            
            if (!$is_group) {
                $update_read_query = "UPDATE chat_messages SET is_read = 1 WHERE is_group_message = 0 AND sender_id = ? AND receiver_id = ? AND is_read = 0";
                $update_stmt = $conn->prepare($update_read_query);
                $update_stmt->bind_param('ii', $target_id, $my_id);
                $update_stmt->execute();
                $update_stmt->close();
            }
            
            echo json_encode(['success' => true, 'messages' => $messages]);
            break;

        
        case 'send_message':
            $target_id_raw = $_POST['target_id'] ?? '';
            $message_text = trim($_POST['message_text'] ?? '');
            
            $is_group = strpos($target_id_raw, 'group_') === 0;
            $target_id = $is_group ? (int)substr($target_id_raw, 6) : (int)$target_id_raw;

            $file_path = null; 

            if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                $file = $_FILES['attachment'];
                
                if ($file['size'] > 10 * 1024 * 1024) { 
                    throw new Exception('File size exceeds 10MB limit.');
                }
                
                if (!is_dir(UPLOAD_DIR_CHATS) && !mkdir(UPLOAD_DIR_CHATS, 0777, true)) {
                    throw new Exception('Failed to create upload directory.');
                }

                $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
                $unique_filename = 'chat_' . $my_id . '_' . time() . '.' . $extension;
                $destination_path = UPLOAD_DIR_CHATS . $unique_filename;

                if (!move_uploaded_file($file['tmp_name'], $destination_path)) {
                    throw new Exception('Failed to save uploaded file.');
                }

                $file_path = str_replace('../', '', $destination_path);
            }


            if (empty($message_text) && empty($file_path)) {
                throw new Exception('Message or file must be provided.');
            }

            
            if ($is_group) {
                $stmt_check = $conn->prepare("SELECT 1 FROM chat_group_members WHERE group_id = ? AND user_id = ?");
                $stmt_check->bind_param('ii', $target_id, $my_id);
                $stmt_check->execute();
                if ($stmt_check->get_result()->num_rows === 0) {
                    throw new Exception('You are not a member of this group.');
                }
                $stmt_check->close();

                $query = "INSERT INTO chat_messages (sender_id, group_id, message, file_path, is_group_message, sent_at) VALUES (?, ?, ?, ?, 1, NOW())";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('iiss', $my_id, $target_id, $message_text, $file_path);
            } else {
                
                $query = "INSERT INTO chat_messages (sender_id, receiver_id, message, file_path, is_group_message, sent_at) VALUES (?, ?, ?, ?, 0, NOW())";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('iiss', $my_id, $target_id, $message_text, $file_path);
            }

            $stmt->execute();
            $stmt->close();

            echo json_encode(['success' => true]);
            break;

        
        case 'add_contact':
            $data = json_decode(file_get_contents('php://input'), true);
            $email = trim($data['email'] ?? '');

            if (empty($email)) throw new Exception('Email cannot be empty.');
            if (strtolower($email) === strtolower($my_email)) throw new Exception("You cannot add yourself.");

            $stmt_find = $conn->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
            $stmt_find->bind_param('s', $email);
            $stmt_find->execute();
            $result_find = $stmt_find->get_result();
            
            if ($result_find->num_rows === 0) throw new Exception("User with this email not found.");
            
            $contact_to_add = $result_find->fetch_assoc();
            $contact_to_add_id = (int)$contact_to_add['id'];
            $stmt_find->close();

            // Try to insert or update the contact
            $stmt_add = $conn->prepare("INSERT INTO chat_contacts (user_id, contact_user_id, is_blocked) VALUES (?, ?, 0) ON DUPLICATE KEY UPDATE is_blocked = 0");
            $stmt_add->bind_param('ii', $my_id, $contact_to_add_id);
            $stmt_add->execute();
            $stmt_add->close();

            echo json_encode(['success' => true, 'message' => 'Contact added successfully.']);
            break;

        
        case 'create_group':
            $data = json_decode(file_get_contents('php://input'), true);
            $group_name = trim($data['group_name'] ?? '');
            $member_ids = $data['member_ids'] ?? []; 

            if (empty($group_name)) throw new Exception('Group name cannot be empty.');
            if (count($member_ids) < 1) throw new Exception('Group must have at least one other member.');
            
            if (!in_array($my_id, $member_ids)) {
                $member_ids[] = $my_id;
            }

            $conn->begin_transaction();
            try {
                $stmt_group = $conn->prepare("INSERT INTO chat_groups (group_name, created_by) VALUES (?, ?)");
                $stmt_group->bind_param('si', $group_name, $my_id);
                $stmt_group->execute();
                $group_id = $conn->insert_id;
                $stmt_group->close();
                
                $stmt_member = $conn->prepare("INSERT INTO chat_group_members (group_id, user_id) VALUES (?, ?)");
                foreach ($member_ids as $member_id) {
                    $member_id = (int)$member_id;
                    $stmt_member->bind_param('ii', $group_id, $member_id);
                    $stmt_member->execute();
                }
                $stmt_member->close();

                $conn->commit();
                echo json_encode(['success' => true, 'message' => 'Group created successfully.', 'group_id' => 'group_' . $group_id]);
            } catch (Exception $e) {
                $conn->rollback();
                throw $e;
            }
            break;

case 'fetch_group_details':
    $data = json_decode(file_get_contents('php://input'), true);
    $group_id = (int)substr($data['group_id_raw'] ?? '', 6); 

    if (!$group_id) throw new Exception('Invalid Group ID.');

    $stmt_info = $conn->prepare("SELECT g.group_name, u.name AS created_by_name, g.created_by
                                 FROM chat_groups g
                                 JOIN users u ON g.created_by = u.id
                                 WHERE g.id = ?");
    $stmt_info->bind_param('i', $group_id);
    $stmt_info->execute();
    $result_info = $stmt_info->get_result();
    $group_info = $result_info->fetch_assoc();
    $stmt_info->close();

    if (!$group_info) throw new Exception('Group not found.');

    $stmt_members = $conn->prepare("SELECT u.id, u.name, u.role
                                    FROM users u
                                    JOIN chat_group_members cgm ON u.id = cgm.user_id
                                    WHERE cgm.group_id = ?");
    $stmt_members->bind_param('i', $group_id);
    $stmt_members->execute();
    $result_members = $stmt_members->get_result();
    $members = $result_members->fetch_all(MYSQLI_ASSOC);
    $stmt_members->close();

    $response = [
        'success' => true,
        'info' => $group_info,
        'members' => $members
    ];
    echo json_encode($response);
    break;

case 'leave_group':
    $data = json_decode(file_get_contents('php://input'), true);
    $group_id = (int)substr($data['target_id_raw'] ?? '', 6);
    
    if (!$group_id) throw new Exception('Invalid Group ID.');

    
    $stmt_creator = $conn->prepare("SELECT created_by FROM chat_groups WHERE id = ?");
    $stmt_creator->bind_param('i', $group_id);
    $stmt_creator->execute();
    $created_by = $stmt_creator->get_result()->fetch_assoc()['created_by'] ?? 0;
    $stmt_creator->close();

    $stmt_delete = $conn->prepare("DELETE FROM chat_group_members WHERE group_id = ? AND user_id = ?");
    $stmt_delete->bind_param('ii', $group_id, $my_id);
    $stmt_delete->execute();
    
    
    
    if ($my_id == $created_by) {
         
        $stmt_count = $conn->prepare("SELECT COUNT(*) FROM chat_group_members WHERE group_id = ?");
        $stmt_count->bind_param('i', $group_id);
        $stmt_count->execute();
        $member_count = $stmt_count->get_result()->fetch_row()[0];
        $stmt_count->close();
        
        
        if ($member_count > 0) {
            
            echo json_encode(['success' => false, 'message' => 'Group creator must transfer ownership or delete the group first.']);
            
            // (Note: Since DELETE has executed, for simplicity, we rely on the JS front-end check for creator role)
            // A transaction block would be better here, but let's keep it simple for now and rely on front-end action/message.
            exit(); 
        } else {
             
            $stmt_del_group = $conn->prepare("DELETE FROM chat_groups WHERE id = ?");
            $stmt_del_group->bind_param('i', $group_id);
            $stmt_del_group->execute();
            echo json_encode(['success' => true, 'message' => 'Group deleted as it was empty.', 'deleted' => true]);
            exit();
        }
    }


    if ($stmt_delete->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Successfully left the group.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'You are not a member of this group or operation failed.']);
    }
    break;

case 'delete_group':
    $data = json_decode(file_get_contents('php://input'), true);
    $group_id = (int)substr($data['target_id_raw'] ?? '', 6);
    
    if (!$group_id) throw new Exception('Invalid Group ID.');

    
    $stmt_check = $conn->prepare("SELECT 1 FROM chat_groups WHERE id = ? AND created_by = ?");
    $stmt_check->bind_param('ii', $group_id, $my_id);
    $stmt_check->execute();
    
    if ($stmt_check->get_result()->num_rows === 0) {
        $stmt_check->close();
        echo json_encode(['success' => false, 'message' => 'You are not the creator and cannot delete this group.']);
        exit();
    }
    $stmt_check->close();

    
    $stmt_delete = $conn->prepare("DELETE FROM chat_groups WHERE id = ?");
    $stmt_delete->bind_param('i', $group_id);
    $stmt_delete->execute();

    if ($stmt_delete->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Group deleted successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to delete group.']);
    }
    break;

case 'delete_contact':
    $data = json_decode(file_get_contents('php://input'), true);
    $contact_id = (int)$data['target_id_raw'];
    
    if (!$contact_id) throw new Exception('Invalid Contact ID.');

    // Start transaction to ensure all deletions complete
    $conn->begin_transaction();
    try {
        // 1. Delete all chat messages with this contact
        $stmt_delete_msgs = $conn->prepare("DELETE FROM chat_messages WHERE (sender_id = ? AND receiver_id = ? AND is_group_message = 0) OR (sender_id = ? AND receiver_id = ? AND is_group_message = 0)");
        $stmt_delete_msgs->bind_param('iiii', $my_id, $contact_id, $contact_id, $my_id);
        $stmt_delete_msgs->execute();
        $stmt_delete_msgs->close();

        // 2. Delete from manually added contacts
        $stmt_delete_manual = $conn->prepare("DELETE FROM chat_contacts WHERE user_id = ? AND contact_user_id = ?");
        $stmt_delete_manual->bind_param('ii', $my_id, $contact_id);
        $stmt_delete_manual->execute();
        $stmt_delete_manual->close();

        // 3. Also ensure they can't be added back from auto-relationships by marking as deleted
        // Insert a blocked record to permanently hide this contact from fetch_contacts
        $stmt_block = $conn->prepare("INSERT INTO chat_contacts (user_id, contact_user_id, is_blocked) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE is_blocked = 1");
        $stmt_block->bind_param('ii', $my_id, $contact_id);
        $stmt_block->execute();
        $stmt_block->close();

        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Contact and chat history removed permanently.']);
    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }
    break;

case 'block_contact':
    $data = json_decode(file_get_contents('php://input'), true);
    $contact_id = (int)$data['contact_id'] ?? 0;
    
    if (!$contact_id) throw new Exception('Invalid Contact ID.');

    // Block the contact by setting is_blocked = 1 (blacklist - blocks receiving messages but keeps history)
    $stmt_block = $conn->prepare("INSERT INTO chat_contacts (user_id, contact_user_id, is_blocked) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE is_blocked = 1");
    $stmt_block->bind_param('ii', $my_id, $contact_id);
    $stmt_block->execute();
    
    echo json_encode(['success' => true, 'message' => 'Contact blocked. Please refresh to see changes.']);
    $stmt_block->close();
    break;

case 'unblock_contact':
    $data = json_decode(file_get_contents('php://input'), true);
    $contact_id = (int)$data['contact_id'] ?? 0;
    
    if (!$contact_id) throw new Exception('Invalid Contact ID.');

    // Unblock the contact by setting is_blocked = 0
    $stmt_unblock = $conn->prepare("UPDATE chat_contacts SET is_blocked = 0 WHERE user_id = ? AND contact_user_id = ?");
    $stmt_unblock->bind_param('ii', $my_id, $contact_id);
    $stmt_unblock->execute();
    
    if ($stmt_unblock->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Contact unblocked successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Contact not found in blocked list.']);
    }
    $stmt_unblock->close();
    break;

        
        case 'fetch_unread_counts':
            
            $unread_query = "SELECT sender_id, COUNT(*) as unread_count 
                            FROM chat_messages 
                            WHERE receiver_id = ? AND is_read = 0 AND is_group_message = 0 
                            GROUP BY sender_id";
            $unread_stmt = $conn->prepare($unread_query);
            $unread_stmt->bind_param('i', $my_id);
            $unread_stmt->execute();
            $unread_result = $unread_stmt->get_result();
            
            $unread_counts = [];
            while ($row = $unread_result->fetch_assoc()) {
                $unread_counts[$row['sender_id']] = (int)$row['unread_count'];
            }
            $unread_stmt->close();
            
            echo json_encode(['success' => true, 'unread_counts' => $unread_counts]);
            break;
    
        
        case 'get_total_unread':
            $unread_sql = "SELECT COUNT(*) as total_unread FROM chat_messages WHERE receiver_id = ? AND is_read = 0";
            $unread_stmt = $conn->prepare($unread_sql);
            $unread_stmt->bind_param('i', $my_id);
            $unread_stmt->execute();
            $unread_result = $unread_stmt->get_result();
            $unread_data = $unread_result->fetch_assoc();
            $unread_stmt->close();
            
            echo json_encode([
                'success' => true,
                'total_unread' => (int)$unread_data['total_unread']
            ]);
            break;
    
        
        case 'create_meeting_1to1':
            
            require_once 'google_config.php';
            require_once 'google_meeting.php';
            
            $receiver_id = (int)($_POST['receiver_id'] ?? 0);
            $title = $_POST['title'] ?? 'Chat Meeting';
            
            
            $check_sql = "SELECT u1.name as name1, u1.email as email1, u2.name as name2, u2.email as email2 
                         FROM users u1, users u2 
                         WHERE u1.id = ? AND u2.id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param('ii', $my_id, $receiver_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $users = $check_result->fetch_assoc();
            $check_stmt->close();
            
            if (!$users) {
                echo json_encode(['success' => false, 'message' => 'User not found']);
                break;
            }
            
            
            if (empty($users['email1']) || empty($users['email2'])) {
                error_log('Invalid attendee emails: email1=' . var_export($users['email1'], true) . ', email2=' . var_export($users['email2'], true));
                echo json_encode(['success' => false, 'message' => 'Error: User email addresses are not configured']);
                break;
            }
            
            
            $start_time = $_POST['start_time'] ?? date('Y-m-d\TH:i:s', strtotime('+1 hour'));
            $end_time = $_POST['end_time'] ?? date('Y-m-d\TH:i:s', strtotime('+2 hours'));
            
            
            
            $start_iso = $start_time;
            $end_iso = $end_time;
            
            
            error_log('Creating 1:1 meeting: title=' . $title . ', start=' . $start_iso . ', end=' . $end_iso);
            error_log('Attendees: ' . json_encode([$users['email1'], $users['email2']]));
            
            $attendees = [$users['email1'], $users['email2']];
            
            
            $result = createGoogleMeetEvent(
                $my_id,
                $title,
                "Meeting between {$users['name1']} and {$users['name2']}",
                $start_iso,
                $end_iso,
                $attendees
            );
            
            if ($result['success']) {
                $description = "Meeting between {$users['name1']} and {$users['name2']}";
                $save_sql = "INSERT INTO chat_meetings 
                             (user_id, contact_user_id, title, description, google_meeting_link, google_calendar_event_id, start_time, end_time) 
                             VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                $save_stmt = $conn->prepare($save_sql);
                if ($save_stmt) {
                    $save_stmt->bind_param(
                        'iissssss',
                        $my_id,
                        $receiver_id,
                        $title,
                        $description,
                        $result['meeting_link'],
                        $result['event_id'],
                        $start_iso,
                        $end_iso
                    );
                    
                    if ($save_stmt->execute()) {
                        error_log('1:1 meeting saved to database: event_id=' . $result['event_id']);
                    } else {
                        error_log('Failed to save 1:1 meeting to database: ' . $save_stmt->error);
                    }
                    $save_stmt->close();
                } else {
                    error_log('Failed to prepare 1:1 meeting save statement: ' . $conn->error);
                }
            }
            
            echo json_encode($result);
            break;
    
        
        case 'create_meeting_group':
            
            require_once 'google_config.php';
            require_once 'google_meeting.php';
            
            $group_id = (int)($_POST['group_id'] ?? 0);
            $title = $_POST['title'] ?? 'Group Meeting';
            
            
            $group_sql = "SELECT * FROM chat_groups WHERE id = ? AND (created_by = ? OR id IN (SELECT group_id FROM chat_group_members WHERE user_id = ?))";
            $group_stmt = $conn->prepare($group_sql);
            $group_stmt->bind_param('iii', $group_id, $my_id, $my_id);
            $group_stmt->execute();
            $group_result = $group_stmt->get_result();
            $group = $group_result->fetch_assoc();
            $group_stmt->close();
            
            if (!$group) {
                echo json_encode(['success' => false, 'message' => 'Group not found']);
                break;
            }
            
            
            $members_sql = "SELECT DISTINCT u.email FROM users u 
                           WHERE u.id = (SELECT created_by FROM chat_groups WHERE id = ?)
                           OR u.id IN (SELECT user_id FROM chat_group_members WHERE group_id = ?)";
            $members_stmt = $conn->prepare($members_sql);
            $members_stmt->bind_param('ii', $group_id, $group_id);
            $members_stmt->execute();
            $members_result = $members_stmt->get_result();
            
            $attendees = [];
            while ($member = $members_result->fetch_assoc()) {
                if (!empty($member['email'])) {  
                    $attendees[] = $member['email'];
                }
            }
            $members_stmt->close();
            
            
            if (empty($attendees)) {
                error_log('No valid attendees for group meeting. Group ID: ' . $group_id);
                echo json_encode(['success' => false, 'message' => 'Error: No group members have valid email addresses']);
                break;
            }
            
            
            $start_time = $_POST['start_time'] ?? date('Y-m-d\TH:i:s', strtotime('+1 hour'));
            $end_time = $_POST['end_time'] ?? date('Y-m-d\TH:i:s', strtotime('+2 hours'));
            
            
            
            $start_iso = $start_time;
            $end_iso = $end_time;
            
            
            error_log('Creating group meeting: group=' . $group['group_name'] . ', start=' . $start_iso . ', end=' . $end_iso);
            error_log('Attendees: ' . json_encode($attendees));
            
            
            $result = createGoogleMeetEvent(
                $my_id,
                $title,
                "Group meeting: {$group['group_name']}",
                $start_iso,
                $end_iso,
                $attendees
            );
            
            if ($result['success']) {
                $update_sql = "UPDATE chat_groups 
                               SET google_meeting_link = ?, 
                                   google_calendar_event_id = ?, 
                                   meeting_scheduled_at = ? 
                               WHERE id = ?";
                $update_stmt = $conn->prepare($update_sql);
                if ($update_stmt) {
                    
                    $mysql_start_time = str_replace('T', ' ', $start_iso);
                    $update_stmt->bind_param('sssi', $result['meeting_link'], $result['event_id'], $mysql_start_time, $group_id);
                    
                    if ($update_stmt->execute()) {
                        error_log('Group meeting saved to database: event_id=' . $result['event_id'] . ', group_id=' . $group_id);
                    } else {
                        error_log('Failed to save group meeting to database: ' . $update_stmt->error);
                    }
                    $update_stmt->close();
                } else {
                    error_log('Failed to prepare group meeting update statement: ' . $conn->error);
                }
                
                $log_sql = "INSERT INTO google_meeting_logs (user_id, event_id, meeting_link, title, start_time, end_time, attendees) 
                           VALUES (?, ?, ?, ?, ?, ?, ?)";
                $log_stmt = $conn->prepare($log_sql);
                if ($log_stmt) {
                    $attendees_json = json_encode($attendees);
                    $log_stmt->bind_param('issssss', $my_id, $result['event_id'], $result['meeting_link'], $title, $start_iso, $end_iso, $attendees_json);
                    if ($log_stmt->execute()) {
                        error_log('Meeting logged to google_meeting_logs');
                    }
                    $log_stmt->close();
                }
            }
            
            echo json_encode($result);
            break;

        // ==================== MESSAGE SEARCH ====================
        case 'search_messages':
            $target_id = $_POST['target_id'] ?? '';
            $search_query = trim($_POST['search_query'] ?? '');
            
            if (empty($target_id) || empty($search_query)) {
                echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
                exit();
            }
            
            $is_group = strpos($target_id, 'group_') === 0;
            
            if ($is_group) {
                $group_id = (int)str_replace('group_', '', $target_id);
                $sql = "SELECT m.*, u.name as sender_name 
                       FROM chat_messages m
                       JOIN users u ON m.sender_id = u.id
                       WHERE m.group_id = ? 
                       AND m.is_group_message = 1
                       AND (m.deleted_by_sender = 0 OR m.sender_id != ?)
                       AND (m.deleted_by_receiver = 0 OR m.receiver_id != ?)
                       AND (MATCH(m.message) AGAINST(? IN BOOLEAN MODE) OR m.message LIKE ?)
                       ORDER BY m.sent_at DESC";
                
                $search_term = '%' . $search_query . '%';
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('iiss', $group_id, $my_id, $my_id, $search_query, $search_term);
            } else {
                $target_id = (int)$target_id;
                $sql = "SELECT m.*, u.name as sender_name 
                       FROM chat_messages m
                       JOIN users u ON m.sender_id = u.id
                       WHERE ((m.sender_id = ? AND m.receiver_id = ? AND m.deleted_by_sender = 0) 
                              OR (m.sender_id = ? AND m.receiver_id = ? AND m.deleted_by_receiver = 0))
                       AND m.is_group_message = 0
                       AND (MATCH(m.message) AGAINST(? IN BOOLEAN MODE) OR m.message LIKE ?)
                       ORDER BY m.sent_at DESC";
                
                $search_term = '%' . $search_query . '%';
                $stmt = $conn->prepare($sql);
                $stmt->bind_param('iiiiss', $my_id, $target_id, $target_id, $my_id, $search_query, $search_term);
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            $messages = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            echo json_encode(['success' => true, 'messages' => $messages]);
            break;

        // ==================== MESSAGE DELETION ====================
        case 'delete_message':
            $data = json_decode(file_get_contents('php://input'), true);
            $message_id = (int)($data['message_id'] ?? 0);
            $is_permanent = isset($data['permanent']) && $data['permanent'] === true;
            
            if (!$message_id) {
                echo json_encode(['success' => false, 'message' => 'Invalid message ID']);
                exit();
            }
            
            // Get message details
            $get_sql = "SELECT * FROM chat_messages WHERE id = ?";
            $get_stmt = $conn->prepare($get_sql);
            $get_stmt->bind_param('i', $message_id);
            $get_stmt->execute();
            $msg_result = $get_stmt->get_result();
            
            if ($msg_result->num_rows === 0) {
                echo json_encode(['success' => false, 'message' => 'Message not found']);
                exit();
            }
            
            $message = $msg_result->fetch_assoc();
            $get_stmt->close();
            
            // Check if user is sender or receiver
            $is_sender = ($message['sender_id'] == $my_id);
            $is_receiver = ($message['receiver_id'] == $my_id && !$message['is_group_message']) || 
                          ($message['is_group_message']);
            
            if (!$is_sender && !$is_receiver) {
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                exit();
            }
            
            if ($is_permanent && $is_sender && $message['sender_id'] == $my_id) {
                // Permanent deletion - delete for both parties
                $del_sql = "DELETE FROM chat_messages WHERE id = ?";
                $del_stmt = $conn->prepare($del_sql);
                $del_stmt->bind_param('i', $message_id);
                $del_stmt->execute();
                $del_stmt->close();
                echo json_encode(['success' => true, 'message' => 'Message deleted permanently']);
            } else {
                // Soft delete - mark as deleted for this user
                if ($is_sender) {
                    $upd_sql = "UPDATE chat_messages SET deleted_by_sender = 1 WHERE id = ?";
                } else {
                    $upd_sql = "UPDATE chat_messages SET deleted_by_receiver = 1 WHERE id = ?";
                }
                
                $upd_stmt = $conn->prepare($upd_sql);
                $upd_stmt->bind_param('i', $message_id);
                $upd_stmt->execute();
                $upd_stmt->close();
                
                echo json_encode(['success' => true, 'message' => 'Message deleted']);
            }
            break;

        // ==================== MESSAGE EDITING ====================
        case 'edit_message':
            $message_id = (int)($_POST['message_id'] ?? 0);
            $new_text = $_POST['new_text'] ?? '';
            
            if (!$message_id || empty($new_text)) {
                echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
                exit();
            }
            
            // Get message details
            $get_sql = "SELECT * FROM chat_messages WHERE id = ?";
            $get_stmt = $conn->prepare($get_sql);
            $get_stmt->bind_param('i', $message_id);
            $get_stmt->execute();
            $msg_result = $get_stmt->get_result();
            
            if ($msg_result->num_rows === 0) {
                echo json_encode(['success' => false, 'message' => 'Message not found']);
                exit();
            }
            
            $message = $msg_result->fetch_assoc();
            $get_stmt->close();
            
            // Only sender can edit
            if ($message['sender_id'] != $my_id) {
                echo json_encode(['success' => false, 'message' => 'Unauthorized']);
                exit();
            }
            
            // Check if within 10 minutes
            $sent_time = strtotime($message['sent_at']);
            $current_time = time();
            $diff_minutes = ($current_time - $sent_time) / 60;
            
            if ($diff_minutes > 10) {
                echo json_encode(['success' => false, 'message' => 'Cannot edit message older than 10 minutes']);
                exit();
            }
            
            // Update message
            $upd_sql = "UPDATE chat_messages 
                       SET message = ?, text = ?, is_edited = 1, edit_timestamp = NOW() 
                       WHERE id = ?";
            $upd_stmt = $conn->prepare($upd_sql);
            $upd_stmt->bind_param('ssi', $new_text, $new_text, $message_id);
            
            if ($upd_stmt->execute()) {
                $upd_stmt->close();
                echo json_encode(['success' => true, 'message' => 'Message edited']);
            } else {
                echo json_encode(['success' => false, 'message' => $upd_stmt->error]);
                $upd_stmt->close();
            }
            break;

        // ==================== MARK MESSAGE AS READ ====================
        case 'mark_as_read':
            $message_id = (int)($_POST['message_id'] ?? 0);
            
            if (!$message_id) {
                echo json_encode(['success' => false, 'message' => 'Invalid message ID']);
                exit();
            }
            
            // Update message
            $upd_sql = "UPDATE chat_messages SET is_read = 1 WHERE id = ? AND receiver_id = ?";
            $upd_stmt = $conn->prepare($upd_sql);
            $upd_stmt->bind_param('ii', $message_id, $my_id);
            
            if ($upd_stmt->execute()) {
                $upd_stmt->close();
                echo json_encode(['success' => true, 'message' => 'Message marked as read']);
            } else {
                echo json_encode(['success' => false, 'message' => $upd_stmt->error]);
                $upd_stmt->close();
            }
            break;

        // ==================== GET AVAILABLE MEMBERS FOR GROUP ====================
        case 'get_available_members':
            $data = json_decode(file_get_contents('php://input'), true);
            $group_id = (int)($data['group_id'] ?? 0);
            
            if (!$group_id) {
                echo json_encode(['success' => false, 'message' => 'Invalid group ID']);
                exit();
            }
            
            // Get all available users (except self and already in group)
            $query = "
                SELECT DISTINCT u.id, u.name, u.role
                FROM users u
                WHERE u.id != ?
                AND u.id NOT IN (
                    SELECT user_id FROM chat_group_members WHERE group_id = ?
                )
                ORDER BY u.name ASC
            ";
            
            $stmt = $conn->prepare($query);
            $stmt->bind_param('ii', $my_id, $group_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $members = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            echo json_encode(['success' => true, 'members' => $members]);
            break;

        // ==================== GET GROUP MEMBERS ====================
        case 'get_group_members':
            $data = json_decode(file_get_contents('php://input'), true);
            $group_id = (int)($data['group_id'] ?? 0);
            
            if (!$group_id) {
                echo json_encode(['success' => false, 'message' => 'Invalid group ID']);
                exit();
            }
            
            // Get current group members
            $query = "
                SELECT u.id, u.name, u.role
                FROM chat_group_members cgm
                JOIN users u ON cgm.user_id = u.id
                WHERE cgm.group_id = ?
                ORDER BY u.name ASC
            ";
            
            $stmt = $conn->prepare($query);
            $stmt->bind_param('i', $group_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $members = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            
            echo json_encode(['success' => true, 'current_members' => $members]);
            break;

        // ==================== ADD MEMBER TO GROUP ====================
        case 'add_group_member':
            $data = json_decode(file_get_contents('php://input'), true);
            $group_id = (int)($data['group_id'] ?? ($_POST['group_id'] ?? 0));
            $member_id = (int)($data['member_id'] ?? ($_POST['member_id'] ?? 0));
            
            if (!$group_id || !$member_id) {
                echo json_encode(['success' => false, 'message' => 'Invalid parameters']);
                exit();
            }
            
            // Check if user is group creator
            $check_sql = "SELECT created_by FROM chat_groups WHERE id = ?";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->bind_param('i', $group_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows === 0) {
                echo json_encode(['success' => false, 'message' => 'Group not found']);
                exit();
            }
            
            $group = $check_result->fetch_assoc();
            $check_stmt->close();
            
            if ($group['created_by'] != $my_id) {
                echo json_encode(['success' => false, 'message' => 'Only group creator can add members']);
                exit();
            }
            
            // Check if member already in group
            $member_check_sql = "SELECT id FROM chat_group_members WHERE group_id = ? AND user_id = ?";
            $member_check_stmt = $conn->prepare($member_check_sql);
            $member_check_stmt->bind_param('ii', $group_id, $member_id);
            $member_check_stmt->execute();
            
            if ($member_check_stmt->get_result()->num_rows > 0) {
                $member_check_stmt->close();
                echo json_encode(['success' => false, 'message' => 'Member already in group']);
                exit();
            }
            $member_check_stmt->close();
            
            // Add member
            $add_sql = "INSERT INTO chat_group_members (group_id, user_id) VALUES (?, ?)";
            $add_stmt = $conn->prepare($add_sql);
            $add_stmt->bind_param('ii', $group_id, $member_id);
            
            if ($add_stmt->execute()) {
                $add_stmt->close();
                echo json_encode(['success' => true, 'message' => 'Member added to group']);
            } else {
                echo json_encode(['success' => false, 'message' => $add_stmt->error]);
                $add_stmt->close();
            }
            break;
    
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action.']);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Server Error: ' . $e->getMessage()
    ]);
}
?>