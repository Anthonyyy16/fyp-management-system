<?php
/**
 * Google API Configuration
 */


define('GOOGLE_CLIENT_ID', '1039164119124-57stljak8mtq9oqrrcctaav4ln6j278m.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');


// define('GOOGLE_REDIRECT_URI', 'http://localhost:8000/RealCoding/google_auth.php');


define('GOOGLE_REDIRECT_URI', 'http://localhost:8000/google_auth.php');


// define('GOOGLE_REDIRECT_URI', 'http://localhost/RealCoding/google_auth.php');


define('GOOGLE_SCOPES', [
    'https://www.googleapis.com/auth/calendar', 
    'https://www.googleapis.com/auth/userinfo.email', 
]);

define('TOKENS_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'tokens');
if (!is_dir(TOKENS_DIR)) {
    mkdir(TOKENS_DIR, 0755, true);
}

define('GOOGLE_MEET_DURATION_MINUTES', 60); 
define('GOOGLE_CALENDAR_TIMEZONE', 'Asia/Shanghai'); 

/**
 * 
 * 
 * composer require google/apiclient google/auth
 */
function getGoogleClient() {
    
    
    throw new Exception('Google Client Library not installed. Use cURL methods instead.');
}

/**
 * 
 */
function getAccessToken($user_id) {
    $token_file = TOKENS_DIR . DIRECTORY_SEPARATOR . 'user_' . intval($user_id) . '_token.json';
    
    if (!file_exists($token_file)) {
        return null;
    }
    
    $token_data = json_decode(file_get_contents($token_file), true);
    
    
    if (isset($token_data['expires_at']) && time() > $token_data['expires_at']) {
        
        if (isset($token_data['refresh_token'])) {
            $new_token = refreshAccessToken($token_data['refresh_token']);
            if ($new_token) {
                saveTokenData($user_id, $new_token);
                return $new_token['access_token'];
            }
        }
        return null;
    }
    
    return $token_data['access_token'] ?? null;
}

/**
 * 
 */
function refreshAccessToken($refresh_token) {
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'client_id' => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'refresh_token' => $refresh_token,
            'grant_type' => 'refresh_token',
        ]),
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    if ($response === false) {
        return null;
    }
    
    $data = json_decode($response, true);
    
    if (isset($data['access_token'])) {
        $data['expires_at'] = time() + ($data['expires_in'] ?? 3600);
        return $data;
    }
    
    return null;
}

/**
 * 
 */
function saveTokenData($user_id, $token_data) {
    $token_file = TOKENS_DIR . DIRECTORY_SEPARATOR . 'user_' . intval($user_id) . '_token.json';
    file_put_contents($token_file, json_encode($token_data));
    chmod($token_file, 0600); 
}

/**
 * 
 */
function deleteTokenData($user_id) {
    $token_file = TOKENS_DIR . DIRECTORY_SEPARATOR . 'user_' . intval($user_id) . '_token.json';
    if (file_exists($token_file)) {
        unlink($token_file);
    }
}

/**
 * 
 */
function getGoogleAuthUrl($redirect_uri = null) {
    if ($redirect_uri === null) {
        $redirect_uri = GOOGLE_REDIRECT_URI;
    }
    
    
    if (!isset($_SESSION['oauth_state'])) {
        $_SESSION['oauth_state'] = bin2hex(random_bytes(32));
    }
    $state = $_SESSION['oauth_state'];
    
    
    if (!filter_var($redirect_uri, FILTER_VALIDATE_URL)) {
        
        if (!preg_match('~^https?://~', $redirect_uri)) {
            $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $host = $_SERVER['HTTP_HOST'] ?? 'localhost:8000';
            $redirect_uri = $protocol . '://' . $host . '/' . ltrim($redirect_uri, '/');
        }
    }
    
    $params = [
        'client_id' => GOOGLE_CLIENT_ID,
        'redirect_uri' => $redirect_uri,
        'response_type' => 'code',
        'scope' => implode(' ', GOOGLE_SCOPES),
        'access_type' => 'offline',
        'prompt' => 'consent',
        'state' => $state,  
        'include_granted_scopes' => 'true',  
    ];
    
    
    return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
}

/**
 * 
 */
function ensureValidToken($user_id) {
    $token = getAccessToken($user_id);
    
    if ($token === null) {
        error_log('No valid token found for user ' . $user_id);
        return null;
    }
    
    return $token;
}
?>
