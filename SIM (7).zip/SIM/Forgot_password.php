<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FYP Management System - Forgot Password</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div class="navbar">
        <h2>Final Year Project System</h2>
    </div>
    <div class="login-container">
        <h2>Forgot Password</h2>
        <p style="text-align: center; margin-bottom: 20px; color: #666;">Enter your email to receive a verification code.</p>
        
        <?php
        if (isset($_GET['error']) && $_GET['error'] == 'email_not_found') {
            echo '<div style="color: red; text-align: center; margin-bottom: 15px;">Email address not found.</div>';
        }
        ?>

        <form action="forgot_password_process.php" method="POST">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" placeholder="Enter your registered email" required>
            </div>
            <button type="submit" class="btn">Send OTP</button>
        </form>
        <div class="links">
            <a href="index.php">Back to Login</a>
        </div>
    </div>
</body>
</html>
