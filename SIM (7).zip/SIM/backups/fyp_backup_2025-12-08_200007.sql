-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: fypms
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `batch_year` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_announcement_creator_idx` (`created_by`),
  CONSTRAINT `fk_announcement_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='System-wide announcements.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (1,'Welcome FYP 2024/2025!','Welcome! Please check deadlines.',9,'2025-11-08 10:12:04','2023/2024'),(2,'Proposal Briefing','Briefing this Friday 3 PM, main hall. Compulsory.',8,'2025-11-08 10:12:04','2024/2025'),(3,'test 1','test passed?',9,'2025-11-28 07:09:37','2025/2026');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appointments`
--

DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `appointment_start` timestamp NULL DEFAULT NULL,
  `appointment_end` timestamp NULL DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` enum('pending','confirmed','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `comment` text DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `google_meeting_link` varchar(500) DEFAULT NULL,
  `google_calendar_event_id` varchar(255) DEFAULT NULL,
  `google_sync_status` enum('pending','synced','failed','deleted') DEFAULT 'pending',
  `google_sync_error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `google_calendar_event_id` (`google_calendar_event_id`),
  KEY `fk_appt_group_idx` (`group_id`),
  KEY `fk_student_appointment` (`student_id`),
  KEY `fk_supervisor_appointment` (`supervisor_id`),
  CONSTRAINT `fk_supervisor_appointment` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointments`
--

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
INSERT INTO `appointments` VALUES (24,1,16,'2025-12-01 02:00:00','2025-12-01 03:00:00','FYP Consultation','','confirmed','2025-11-29 09:23:45','ok',5,NULL,NULL,'pending',NULL),(26,11,36,'2025-12-03 06:00:00','2025-12-03 07:00:00','FYP Consultation','','rejected','2025-11-30 16:29:54','',5,NULL,NULL,'pending',NULL),(27,11,36,'2025-12-03 06:00:00','2025-12-03 07:00:00','FYP Consultation','','confirmed','2025-11-30 16:30:52','',5,NULL,NULL,'pending',NULL),(29,1,40,'2025-12-09 05:00:00','2025-12-09 06:00:00','FYP Consultation 2','','confirmed','2025-12-03 17:14:16','can, at A188',5,NULL,NULL,'pending',NULL),(30,1,40,'2025-12-10 07:00:00','2025-12-10 08:00:00','FYP Consultation','','rejected','2025-12-04 13:42:04','',5,NULL,NULL,'pending',NULL),(31,1,10,'2025-12-10 06:00:00','2025-12-10 07:00:00','FYP Consultation','','rejected','2025-12-05 05:20:42','',5,NULL,NULL,'pending',NULL);
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `batch_committees`
--

DROP TABLE IF EXISTS `batch_committees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batch_committees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batch_year` varchar(20) NOT NULL,
  `committee_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_batch_committee` (`batch_year`,`committee_id`),
  KEY `committee_id` (`committee_id`),
  CONSTRAINT `batch_committees_ibfk_1` FOREIGN KEY (`committee_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batch_committees`
--

LOCK TABLES `batch_committees` WRITE;
/*!40000 ALTER TABLE `batch_committees` DISABLE KEYS */;
INSERT INTO `batch_committees` VALUES (1,'2025/2026',5,'2025-11-30 09:46:30'),(2,'2024/2025',7,'2025-11-30 10:21:47'),(3,'2025/2026',8,'2025-11-30 14:40:07');
/*!40000 ALTER TABLE `batch_committees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_contacts`
--

DROP TABLE IF EXISTS `chat_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_contacts` (
  `user_id` int(11) NOT NULL COMMENT 'FK to users.id (The person adding)',
  `contact_user_id` int(11) NOT NULL COMMENT 'FK to users.id (The person being added)',
  `is_blocked` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`user_id`,`contact_user_id`),
  KEY `fk_contact_user_idx` (`contact_user_id`),
  CONSTRAINT `fk_contact_owner` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_contact_user` FOREIGN KEY (`contact_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores manually added chat contacts.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_contacts`
--

LOCK TABLES `chat_contacts` WRITE;
/*!40000 ALTER TABLE `chat_contacts` DISABLE KEYS */;
INSERT INTO `chat_contacts` VALUES (1,4,0),(1,6,0),(5,1,0),(5,40,0),(7,60,0);
/*!40000 ALTER TABLE `chat_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_groups`
--

DROP TABLE IF EXISTS `chat_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `google_meeting_link` varchar(500) DEFAULT NULL,
  `google_calendar_event_id` varchar(255) DEFAULT NULL,
  `meeting_scheduled_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `google_calendar_event_id` (`google_calendar_event_id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `chat_groups_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_groups`
--

LOCK TABLES `chat_groups` WRITE;
/*!40000 ALTER TABLE `chat_groups` DISABLE KEYS */;
INSERT INTO `chat_groups` VALUES (6,'Group 2024/2025',7,'2025-12-05 04:46:15','https://meet.google.com/jtx-jqjd-kbk','4h31kuu65a9qtfhusiv7l91sag','2025-12-05 05:47:00');
/*!40000 ALTER TABLE `chat_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_meetings`
--

DROP TABLE IF EXISTS `chat_meetings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_meetings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contact_user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `google_meeting_link` varchar(500) DEFAULT NULL,
  `google_calendar_event_id` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `google_calendar_event_id` (`google_calendar_event_id`),
  KEY `contact_user_id` (`contact_user_id`),
  KEY `idx_users` (`user_id`,`contact_user_id`),
  KEY `idx_event_id` (`google_calendar_event_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `chat_meetings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chat_meetings_ibfk_2` FOREIGN KEY (`contact_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_meetings`
--

LOCK TABLES `chat_meetings` WRITE;
/*!40000 ALTER TABLE `chat_meetings` DISABLE KEYS */;
INSERT INTO `chat_meetings` VALUES (11,5,40,'Fyp discuss','Meeting between Dr. Lee Wei and Sim Yi Xiang','https://meet.google.com/bet-tghf-jww','6c95jfcs7krtn6eoanhrp1m8no','2025-12-03 20:43:00','2025-12-03 21:43:00','2025-12-03 11:43:30'),(12,5,40,'Fyp discuss','Meeting between Dr. Lee Wei and Sim Yi Xiang','https://meet.google.com/kow-ydro-gjp','1epe1306695t7r7mcg6ejea814','2025-12-03 20:43:00','2025-12-03 21:43:00','2025-12-03 11:43:35'),(13,5,40,'FYP title','Meeting between Dr. Lee Wei and Sim Yi Xiang','https://meet.google.com/rps-nyhh-kic','thnq9aoc960rcaffjk7979qbqc','2025-12-04 02:27:00','2025-12-04 03:27:00','2025-12-03 17:27:17'),(14,5,40,'FYP title','Meeting between Dr. Lee Wei and Sim Yi Xiang','https://meet.google.com/bcm-cjiw-gwc','03gg12o8mfrgv98kmpf4gha2ao','2025-12-04 02:27:00','2025-12-04 03:27:00','2025-12-03 17:27:22'),(15,5,40,'FYP discuss','Meeting between Dr. Lee Wei and Sim Yi Xiang','https://meet.google.com/bjn-ykjx-tnc','m99tpjsncqjhatinr6a84ilqc4','2025-12-04 02:51:00','2025-12-04 03:51:00','2025-12-03 17:52:02'),(16,5,40,'FYP discuss','Meeting between Dr. Lee Wei and Sim Yi Xiang','https://meet.google.com/vhx-wqza-nkd','mdi0ilvukn4mpbslkjcsqq537c','2025-12-04 02:51:00','2025-12-04 03:51:00','2025-12-03 17:52:06');
/*!40000 ALTER TABLE `chat_meetings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) DEFAULT NULL,
  `message` text NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `sent_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `is_group_message` tinyint(1) NOT NULL DEFAULT 0,
  `group_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chat_sender_idx` (`sender_id`),
  KEY `fk_chat_receiver_idx` (`receiver_id`),
  KEY `group_id` (`group_id`),
  CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_chat_receiver` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_chat_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores chat messages between users.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
INSERT INTO `chat_messages` VALUES (5,1,4,'hi',NULL,'2025-11-10 15:04:26',1,0,NULL),(6,1,4,'hi',NULL,'2025-11-10 15:17:15',1,0,NULL),(7,4,1,'123',NULL,'2025-11-10 15:34:16',1,0,NULL),(25,7,60,'hi','uploads/chat_fileschat_7_1764909919.jpg','2025-12-05 04:45:19',0,0,NULL),(26,10,7,'hi',NULL,'2025-12-05 04:45:54',1,0,NULL);
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courses`
--

DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT 'e.g., Software Engineering',
  `course_code` varchar(20) DEFAULT NULL COMMENT 'e.g., SE',
  `faculty_id` int(11) NOT NULL COMMENT 'FK to faculties.id',
  PRIMARY KEY (`id`),
  KEY `fk_course_faculty_idx` (`faculty_id`),
  CONSTRAINT `fk_course_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courses`
--

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (1,'Software Engineering','SE',1),(2,'Cybersecurity','CS',1),(3,'Enterprise Information System','EIS',1),(4,'Mechanical Engineering','ME',2);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deadlines`
--

DROP TABLE IF EXISTS `deadlines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deadlines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `due_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `batch_year` varchar(20) DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_deadline_creator_idx` (`created_by`),
  CONSTRAINT `fk_deadline_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores project submission deadlines.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deadlines`
--

LOCK TABLES `deadlines` WRITE;
/*!40000 ALTER TABLE `deadlines` DISABLE KEYS */;
INSERT INTO `deadlines` VALUES (1,'Proposal Submission','Submit final proposal PDF.','2025-11-15 15:59:59','2024/2025',9,'2025-11-08 10:12:04'),(2,'Interim Report','Submit interim report.','2026-01-30 15:59:59','2024/2025',9,'2025-11-08 10:12:04'),(3,'Final Report','Final report and code.','2026-04-10 15:59:59','2024/2025',7,'2025-11-08 10:12:04'),(5,'Demo: Project Proposal - 2025-11-23 15:08:23','This is a demo deadline for testing the deadline_trigger script.','2025-11-28 07:08:23','2024/2025',1,'2025-11-23 14:08:23'),(6,'Demo: Project Proposal - 2025-11-23 15:09:09','This is a demo deadline for testing the deadline_trigger script.','2025-11-28 07:09:09','2024/2025',1,'2025-11-23 14:09:09'),(7,'Demo: Project Proposal - 2025-11-23 15:10:00','This is a demo deadline for testing the deadline_trigger script.','2025-11-28 07:10:00','2024/2025',1,'2025-11-23 14:10:00'),(8,'Demo: Project Proposal - 2025-11-23 15:10:59','This is a demo deadline for testing the deadline_trigger script.','2025-11-28 07:10:59','2024/2025',1,'2025-11-23 14:10:59'),(9,'Demo: Project Proposal - 2025-11-23 15:15:22','This is a demo deadline for testing the deadline_trigger script.','2025-11-28 07:15:22','2024/2025',1,'2025-11-23 14:15:22'),(10,'proposal test','','2025-12-02 10:25:00','2023/2024',9,'2025-11-28 17:32:55');
/*!40000 ALTER TABLE `deadlines` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `downloadable_files`
--

DROP TABLE IF EXISTS `downloadable_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `downloadable_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `category` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `file_size` int(11) DEFAULT 0,
  `download_count` int(11) DEFAULT 0,
  `upload_date` datetime NOT NULL,
  `batch_year` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `downloadable_files`
--

LOCK TABLES `downloadable_files` WRITE;
/*!40000 ALTER TABLE `downloadable_files` DISABLE KEYS */;
INSERT INTO `downloadable_files` VALUES (5,'Form 1_Student Details (v031223)','uploads/documents/69255891d1d4b_1764055185.docx','Forms','',95272,0,'2025-11-25 15:19:45','2024/2025'),(6,'Form 2_Proposal (v031223)','uploads/documents/692558a668c0d_1764055206.docx','Forms','',99200,0,'2025-11-25 15:20:06','2024/2025'),(7,'Form 3 FYP 1','uploads/documents/692558b63b568_1764055222.pdf','Forms','',524948,0,'2025-11-25 15:20:22','2024/2025'),(8,'Form 4(i) BACS3403 Project I Project Appointment Record','uploads/documents/692558c5c3a9c_1764055237.docx','Forms','',96830,0,'2025-11-25 15:20:37','2024/2025'),(9,'BACS3403 Project I 2023.06.22 (July2023)','uploads/documents/692558e1a12c0_1764055265.pdf','Guidelines','',308404,0,'2025-11-25 15:21:05','2024/2025'),(10,'BACS3413 Project II (July2023)','uploads/documents/6925591c51d7e_1764055324.pdf','Guidelines','',289007,0,'2025-11-25 15:22:04','2024/2025'),(11,'BMCS3043 Project 1 Rubric - Student Reference','uploads/documents/6925592f70258_1764055343.pdf','Rubrics','',364796,0,'2025-11-25 15:22:23','2024/2025'),(12,'Project II Rubric-student reference','uploads/documents/6925593d4be26_1764055357.pdf','Rubrics','',19838,0,'2025-11-25 15:22:37','2024/2025'),(13,'AbstractTemplate (Project 2)','uploads/documents/692559543d5b6_1764055380.docx','Report Template','',16044,0,'2025-11-25 15:23:00','2024/2025'),(14,'Chapter Contents - Example','uploads/documents/6925596546344_1764055397.xlsx','Report Template','',12684,0,'2025-11-25 15:23:17','2024/2025'),(15,'FYP Report Template (updated 2.7.25)','uploads/documents/6925597057606_1764055408.docx','Report Template','',3114314,0,'2025-11-25 15:23:28','2024/2025'),(16,'KeywordsTemplate(Project 2)','uploads/documents/6925598a048ae_1764055434.docx','Report Template','',15141,1,'2025-11-25 15:23:54','2024/2025'),(17,'Poster Template A1 size (Project 2)','uploads/documents/6925599bb3bd9_1764055451.pptx','Report Template','',314530,2,'2025-11-25 15:24:11','2024/2025'),(23,'test','uploads/documents/69284e5e9ae8f_1764249182.pdf','Documentation','test',232391,1,'2025-11-27 21:13:02','2023/2024'),(25,' test','uploads/documents/69298a4ec25b7_1764330062.pdf','Documentation',' test',84494,0,'2025-11-28 19:41:02','2023/2024'),(26,'test1','uploads/documents/692c9de59be53_1764531685.pdf','Documentation','test',232391,1,'2025-12-01 03:41:25','2023/2024');
/*!40000 ALTER TABLE `downloadable_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculties`
--

DROP TABLE IF EXISTS `faculties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `faculties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL COMMENT 'e.g., Faculty of Computer Science and IT',
  `faculty_code` varchar(20) DEFAULT NULL COMMENT 'e.g., FCSIT',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculties`
--

LOCK TABLES `faculties` WRITE;
/*!40000 ALTER TABLE `faculties` DISABLE KEYS */;
INSERT INTO `faculties` VALUES (1,'Faculty of Computer Science and IT','FCSIT'),(2,'Faculty of Engineering','FOE');
/*!40000 ALTER TABLE `faculties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fyp_titles`
--

DROP TABLE IF EXISTS `fyp_titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fyp_titles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `description` text DEFAULT NULL,
  `batch_year` varchar(50) NOT NULL,
  `created_by` int(11) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `fyp_titles_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fyp_titles`
--

LOCK TABLES `fyp_titles` WRITE;
/*!40000 ALTER TABLE `fyp_titles` DISABLE KEYS */;
INSERT INTO `fyp_titles` VALUES (1,'test','test','2023/2024',6,0,'2025-11-29 18:49:53'),(3,'AI-Powered Healthcare Diagnosis System','Develop an AI system that can assist in medical diagnosis using machine learning algorithms.','2025/2026',5,1,'2025-11-29 19:04:35'),(4,'Blockchain-based Supply Chain Management','Create a transparent and secure supply chain management system using blockchain technology.','2024/2025',5,1,'2025-11-29 19:04:35'),(5,'IoT Smart Home Automation System','Design and implement a comprehensive smart home system using Internet of Things devices.','2023/2024',5,1,'2025-11-29 19:04:35'),(6,'E-commerce Recommendation Engine','Build a personalized product recommendation system for online shopping platforms.','2024/2025',6,1,'2025-11-29 19:04:35'),(7,'Cybersecurity Threat Detection System','Develop an intelligent system to detect and prevent cybersecurity threats in real-time.','2023/2024',7,1,'2025-11-29 19:04:35'),(8,'Mobile Learning Application for Programming','Create an interactive mobile app for learning programming languages with hands-on exercises.','2023/2024',7,1,'2025-11-29 19:04:35'),(9,'Social Media Analytics Dashboard','Build a comprehensive analytics dashboard for social media performance tracking.','2023/2024',5,1,'2025-11-29 19:04:35'),(10,'Automated Attendance System using Face Recognition','Develop a contactless attendance system using facial recognition technology.','2023/2024',5,1,'2025-11-29 19:04:35'),(12,'test1','test1','2024/2025',6,0,'2025-11-30 05:02:56'),(13,'test','test123','2024/2025',5,0,'2025-11-30 07:43:02'),(14,'tet1234','124','2023/2024',5,0,'2025-11-30 07:43:09'),(15,'1','1','2024/2025',5,0,'2025-11-30 07:43:21'),(16,'12','12','2024/2025',5,0,'2025-11-30 07:43:26'),(17,'123','123','2024/2025',5,0,'2025-11-30 07:43:31'),(18,'Yolo Modal Detect','hCapchart modal','2024/2025',5,1,'2025-11-30 07:43:38'),(19,'12455','123','2024/2025',5,0,'2025-11-30 07:43:46'),(21,'test1','test11111abc','2024/2025',6,0,'2025-11-30 16:35:03'),(22,'\"An Intelligent, Multi-Platform Language Learning Application with Gamification and Real-Time Speech Recognition\"','Multiple platform learning and recognized speech','2024/2025',6,1,'2025-11-30 16:41:42'),(23,'AI Chatbot Services: An Advanced Mental Health Management Tool','AI Chat with manage the mental health tool','2024/2025',6,1,'2025-11-30 17:00:52');
/*!40000 ALTER TABLE `fyp_titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `google_meeting_logs`
--

DROP TABLE IF EXISTS `google_meeting_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `google_meeting_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `event_id` varchar(255) DEFAULT NULL,
  `meeting_link` varchar(500) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `end_time` datetime DEFAULT NULL,
  `attendees` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`attendees`)),
  `action` enum('created','updated','deleted','joined') DEFAULT 'created',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_event_id` (`event_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_created_at` (`created_at`),
  CONSTRAINT `google_meeting_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `google_meeting_logs`
--

LOCK TABLES `google_meeting_logs` WRITE;
/*!40000 ALTER TABLE `google_meeting_logs` DISABLE KEYS */;
INSERT INTO `google_meeting_logs` VALUES (1,5,'i5tg4542f1l0jebvvplen70rdc','https://meet.google.com/zzf-txvv-isk','test','2025-11-30 02:19:00','2025-11-30 03:19:00','[\"ali@student.com\",\"david@student.com\",\"yixiangshop@gmail.com\"]','created','2025-11-29 17:20:10'),(2,5,'78l11ggp55odb3gr5k6mf2279k','https://meet.google.com/yjh-ygrr-quo','test','2025-11-30 02:19:00','2025-11-30 03:19:00','[\"ali@student.com\",\"david@student.com\",\"yixiangshop@gmail.com\"]','created','2025-11-29 17:20:14'),(3,5,'62kmpbbq84dc60udncrp0sjhh4','https://meet.google.com/vcv-qvmt-ojo','test','2025-11-30 02:19:00','2025-11-30 03:19:00','[\"ali@student.com\",\"david@student.com\",\"yixiangshop@gmail.com\"]','created','2025-11-29 17:21:19'),(4,5,'qothq11dcpbdpd5m2sojp8bagk','https://meet.google.com/hqa-ynqb-bwg','test123','2025-11-30 02:21:00','2025-11-30 03:21:00','[\"ali@student.com\",\"david@student.com\",\"yixiangshop@gmail.com\"]','created','2025-11-29 17:21:39'),(5,5,'no3e9l16ku8kvdle3a07d2okjo','https://meet.google.com/yhu-wrhe-snj','test123','2025-11-30 02:21:00','2025-11-30 03:21:00','[\"ali@student.com\",\"david@student.com\",\"yixiangshop@gmail.com\"]','created','2025-11-29 17:21:51'),(6,5,'6v4euv7oa17n6u8b1lp7latqfg','https://meet.google.com/uvb-jdqe-rik','fyp','2025-12-01 01:35:00','2025-12-01 02:35:00','[\"2023@student.com\",\"simyx-wm22@student.tarc.edu.my\",\"yixiangshop@gmail.com\",\"yuxiang@student.com\"]','created','2025-11-30 16:35:45'),(7,5,'i0ffgt0p8bpaf690jvla8d096o','https://meet.google.com/ewb-scsw-cqc','fyp','2025-12-01 01:35:00','2025-12-01 02:35:00','[\"2023@student.com\",\"simyx-wm22@student.tarc.edu.my\",\"yixiangshop@gmail.com\",\"yuxiang@student.com\"]','created','2025-11-30 16:35:49'),(8,10,'o6fqklth003fr1mr6p7akjqhh4','https://meet.google.com/zgt-zkip-xef','fyp discussion','2025-12-05 13:47:00','2025-12-05 14:47:00','[\"ethan@student.com\",\"kumar@committee.com\",\"simyx-wm22@student.tarc.edu.my\"]','created','2025-12-05 04:47:55'),(9,10,'4h31kuu65a9qtfhusiv7l91sag','https://meet.google.com/jtx-jqjd-kbk','fyp discussion','2025-12-05 13:47:00','2025-12-05 14:47:00','[\"ethan@student.com\",\"kumar@committee.com\",\"simyx-wm22@student.tarc.edu.my\"]','created','2025-12-05 04:48:02');
/*!40000 ALTER TABLE `google_meeting_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `google_tokens`
--

DROP TABLE IF EXISTS `google_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `google_tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `token_json` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `idx_expires_at` (`expires_at`),
  CONSTRAINT `google_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `google_tokens`
--

LOCK TABLES `google_tokens` WRITE;
/*!40000 ALTER TABLE `google_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `google_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_members`
--

DROP TABLE IF EXISTS `group_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_members` (
  `group_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`group_id`,`user_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `group_members_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `chat_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_members_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_members`
--

LOCK TABLES `group_members` WRITE;
/*!40000 ALTER TABLE `group_members` DISABLE KEYS */;
INSERT INTO `group_members` VALUES (6,7,'2025-12-05 04:46:15'),(6,10,'2025-12-05 04:46:15'),(6,60,'2025-12-05 04:46:15');
/*!40000 ALTER TABLE `group_members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supervisor_id` int(11) DEFAULT NULL,
  `moderator_id` int(11) DEFAULT NULL COMMENT 'FK to users.id (the moderator)',
  `batch_year` varchar(20) DEFAULT NULL COMMENT 'Batch year for the group',
  `status` enum('active','completed') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_group_supervisor_idx` (`supervisor_id`),
  KEY `fk_group_moderator_idx` (`moderator_id`),
  KEY `batch_year_group_index` (`batch_year`),
  CONSTRAINT `fk_group_moderator` FOREIGN KEY (`moderator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_group_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores project group information.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,5,6,'2024/2025','active','2025-11-08 10:12:04'),(2,6,5,'2024/2025','active','2025-11-08 10:12:04'),(3,5,7,'2023/2024','active','2025-11-28 18:28:32'),(5,7,5,'2023/2024','active','2025-11-28 18:28:32'),(7,7,5,'2024/2025','active','2025-11-28 19:09:53'),(11,5,7,'2025/2026','active','2025-11-30 15:51:37'),(12,6,7,'2025/2026','active','2025-11-30 16:56:29'),(19,61,5,'2024/2025','active','2025-12-05 04:21:51');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `recipient_id` int(11) NOT NULL COMMENT 'FK to users.id (who receives the notification)',
  `sender_id` int(11) DEFAULT NULL COMMENT 'FK to users.id (who triggers the notification)',
  `type` enum('submission_approved','submission_rejected','submission_commented','submission_resubmitted','appointment_requested','appointment_approved','appointment_rejected','appointment_commented','deadline_reminder','supervisor_application_submitted','supervisor_application_approved','supervisor_application_rejected','proposal_submitted','proposal_approved','proposal_rejected') DEFAULT NULL,
  `submission_id` int(11) DEFAULT NULL COMMENT 'FK to submissions.id (related submission)',
  `appointment_id` int(11) DEFAULT NULL COMMENT 'FK to appointments.id (related appointment)',
  `proposal_id` int(11) DEFAULT NULL COMMENT 'FK to student_proposals.id (related proposal)',
  `message` text NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_notif_recipient_idx` (`recipient_id`),
  KEY `fk_notif_sender_idx` (`sender_id`),
  KEY `fk_notif_submission_idx` (`submission_id`),
  KEY `fk_notif_appointment_idx` (`appointment_id`),
  CONSTRAINT `fk_notif_appointment` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_notif_recipient` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_notif_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_notif_submission` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=226 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores notifications for users.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (6,5,1,'',NULL,NULL,NULL,'Student resubmitted file for \'Proposal Submission\'.',1,'2025-11-22 19:07:51'),(37,1,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:08:23'),(38,2,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:08:23'),(39,3,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:08:23'),(40,4,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:08:23'),(41,10,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:08:23'),(42,1,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:10:00'),(43,2,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:10:04'),(44,3,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:10:07'),(45,4,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:10:10'),(46,10,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:10:13'),(47,1,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:10:16'),(48,2,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:10:18'),(49,3,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:10:21'),(50,4,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:10:24'),(51,10,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:10:27'),(52,1,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:10:30'),(53,2,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:10:33'),(54,3,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:10:36'),(55,4,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:10:38'),(56,10,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:10:41'),(57,1,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:10:59'),(58,2,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:11:02'),(59,3,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:05'),(60,4,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:08'),(61,10,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:11'),(62,1,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:11:14'),(63,2,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:11:17'),(64,3,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:21'),(65,4,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:24'),(66,10,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:27'),(67,1,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:11:29'),(68,2,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:11:32'),(69,3,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:36'),(70,4,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:39'),(71,10,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:42'),(72,1,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:11:44'),(73,2,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:11:47'),(74,3,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:50'),(75,4,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:53'),(76,10,NULL,'',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:11:56'),(77,1,NULL,'',NULL,NULL,NULL,'Test deadline reminder message',1,'2025-11-23 14:12:38'),(78,1,NULL,'',NULL,NULL,NULL,'Test deadline reminder message',1,'2025-11-23 14:12:54'),(79,1,NULL,'',NULL,NULL,NULL,'Direct test message',1,'2025-11-23 14:13:10'),(80,1,NULL,'',NULL,NULL,NULL,'Test deadline reminder message',1,'2025-11-23 14:14:01'),(81,1,NULL,'',NULL,NULL,NULL,'Method 1 message',1,'2025-11-23 14:14:17'),(82,2,NULL,'',NULL,NULL,NULL,'Method 2 message',1,'2025-11-23 14:14:17'),(83,1,NULL,'deadline_reminder',NULL,NULL,NULL,'Test deadline reminder message',1,'2025-11-23 14:15:13'),(84,1,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:15:22'),(85,2,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:15:25'),(86,3,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:15:28'),(87,4,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:15:31'),(88,10,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:08:23\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:08\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:15:34'),(89,1,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:15:37'),(90,2,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:15:40'),(91,3,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:15:43'),(92,4,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:15:46'),(93,10,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:09:09\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:09\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:15:49'),(94,1,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:15:52'),(95,2,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:15:55'),(96,3,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:15:58'),(97,4,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:16:01'),(98,10,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:00\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:16:04'),(99,1,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:16:07'),(100,2,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:16:11'),(101,3,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:16:14'),(102,4,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:16:17'),(103,10,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:10:59\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:10\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:16:20'),(104,1,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:16:23'),(105,2,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.',1,'2025-11-23 14:16:26'),(106,3,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:16:29'),(107,4,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:16:32'),(108,10,NULL,'deadline_reminder',NULL,NULL,NULL,'Reminder: The deadline for \'Demo: Project Proposal - 2025-11-23 15:15:22\' is approaching in 5 day(s).\n\nDue Date: Nov 28, 2025 15:15\n\nPlease ensure you submit your work before the deadline.',0,'2025-11-23 14:16:35'),(109,5,2,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Siti binti Aminah.\n\nProject Title: test title\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',1,'2025-11-23 15:57:46'),(110,5,2,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Siti binti Aminah.\n\nProject Title: test title\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',1,'2025-11-23 16:16:48'),(111,2,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application for \'test title\' has been approved by Dr. Lee Wei.\n\nComment from supervisor: can.',1,'2025-11-23 16:17:12'),(112,5,2,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Siti binti Aminah.\n\nProject Title: test title\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',1,'2025-11-23 16:22:23'),(113,2,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application for \'test title\' has been approved by Dr. Lee Wei.\n\nComment from supervisor: okok.',1,'2025-11-23 17:09:41'),(114,5,2,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Siti binti Aminah.\n\nProject Title: test title\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',1,'2025-11-23 17:43:43'),(115,2,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application for \'test title\' has been approved by Dr. Lee Wei.\n\nComment from supervisor: can.',1,'2025-11-23 17:44:01'),(123,5,NULL,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from yixiang.\n\nProject Title: test proposal\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',0,'2025-11-28 07:30:17'),(150,5,NULL,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from student A.\n\nProject Title: test proposal\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',0,'2025-11-28 13:21:21'),(152,5,NULL,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from student A.\n\nProject Title: test proposal\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',0,'2025-11-28 13:23:27'),(163,5,NULL,'appointment_requested',NULL,24,NULL,'New appointment request from student A on Dec 01, 2025 10:00 - FYP Consultation',0,'2025-11-29 09:23:45'),(167,5,3,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Charlie Tan.\n\nStudent Email: charlie@student.com\n\nPlease log in to review this application.',0,'2025-11-29 11:14:38'),(168,5,34,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from test.\n\nStudent Email: 123Test@gmail.com\n\nPlease log in to review this application.',0,'2025-11-30 06:41:57'),(169,34,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by Dr. Lee Wei.',0,'2025-11-30 13:07:58'),(170,5,35,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from student 2023.\n\nStudent Email: 2023@student.com\n\nPlease log in to review this application.',0,'2025-11-30 16:16:47'),(171,35,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by Dr. Lee Wei.',0,'2025-11-30 16:17:13'),(172,5,NULL,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from yixiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',0,'2025-11-30 16:23:11'),(174,5,NULL,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from yixiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',0,'2025-11-30 16:26:52'),(176,5,NULL,'appointment_requested',NULL,26,NULL,'New appointment request from yixiang on Dec 03, 2025 14:00 - FYP Consultation',0,'2025-11-30 16:29:54'),(177,5,NULL,'appointment_requested',NULL,27,NULL,'New appointment request from yixiang on Dec 03, 2025 14:00 - FYP Consultation',0,'2025-11-30 16:30:52'),(178,6,NULL,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from jonh.\n\nStudent Email: john@example.com\n\nPlease log in to review this application.',1,'2025-12-01 19:24:15'),(181,40,NULL,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by Mr Xue Zhi Qian .\n\nComment from supervisor: Yes.',0,'2025-12-03 09:58:21'),(182,5,40,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Sim Yi Xiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',0,'2025-12-03 11:24:40'),(183,40,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by Dr. Lee Wei.\n\nComment from supervisor: Yes come.',0,'2025-12-03 11:25:10'),(184,5,40,'submission_resubmitted',26,NULL,NULL,'Student submitted file for \'Proposal Submission\'.',0,'2025-12-03 11:27:12'),(185,40,5,'submission_approved',26,NULL,NULL,'Your submission for \'Proposal Submission\' has been approved by Dr. Lee Wei. Comment: Yes, please list down detail in part A',1,'2025-12-03 11:28:41'),(186,5,40,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Sim Yi Xiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',0,'2025-12-03 11:31:42'),(187,40,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by Dr. Lee Wei.\n\nComment from supervisor: yes  seat availble.',0,'2025-12-03 11:32:17'),(190,5,40,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Sim Yi Xiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',1,'2025-12-03 17:08:10'),(191,40,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by Dr. Lee Wei.\n\nComment from supervisor: Yes, seat still available.',0,'2025-12-03 17:08:48'),(192,5,40,'submission_resubmitted',27,NULL,NULL,'Student submitted file for \'Demo: Project Proposal - 2025-11-23 15:08:23\'.',1,'2025-12-03 17:10:51'),(193,40,5,'submission_approved',27,NULL,NULL,'Your submission for \'Demo: Project Proposal - 2025-11-23 15:08:23\' has been approved by Dr. Lee Wei. Comment: Still need have a little bit change in part A',0,'2025-12-03 17:12:58'),(194,5,40,'appointment_requested',NULL,29,NULL,'New appointment request from Sim Yi Xiang on Dec 09, 2025 13:00 - FYP Consultation 2',1,'2025-12-03 17:14:16'),(195,40,5,'appointment_approved',NULL,29,NULL,'Your appointment request for \'FYP Consultation 2\' on Dec 09, 2025 13:00 has been APPROVED.\r\n                            Supervisor Comments: can, at A188',1,'2025-12-03 17:15:22'),(196,5,40,'appointment_requested',NULL,30,NULL,'New appointment request from Jordan on Dec 10, 2025 15:00 - FYP Consultation',1,'2025-12-04 13:42:04'),(197,40,5,'appointment_rejected',NULL,30,NULL,'Your appointment request for \'FYP Consultation\' on Dec 10, 2025 15:00 has been REJECTED.',0,'2025-12-04 13:42:22'),(198,40,5,'appointment_rejected',NULL,30,NULL,'Your appointment request for \'FYP Consultation\' on Dec 10, 2025 15:00 has been REJECTED.',0,'2025-12-04 13:42:25'),(200,40,5,'proposal_rejected',NULL,NULL,14,'Your FYP proposal \"test\" has been rejected by Dr. Lee Wei. Feedback: no',0,'2025-12-04 14:37:25'),(201,5,40,'proposal_submitted',NULL,NULL,15,'Student Jordan has submitted a new FYP proposal: \"Yolo Modal Detect\". Please review it in the Proposal Management system.',0,'2025-12-04 18:30:56'),(202,40,5,'proposal_rejected',NULL,NULL,15,'Your FYP proposal \"Yolo Modal Detect\" has been rejected by Dr. Lee Wei. Feedback: Here is the feedback for the student\'s proposal:\r\n\r\n---\r\n\r\n1. Initial Assessment\r\nThis submission is exceptionally brief and lacks almost all necessary information for a project proposal. While \"Yolo\" suggests an interest in a relevant field within computer vision, the provided content is insufficient to understand the project\'s scope, objectives, or intent. It appears to be an initial thought rather than a structured proposal.\r\n\r\n2. Recommendation\r\nREJECTED\r\n\r\n3. Key Feedback Points\r\n*   What works well: The mention of \"Yolo\" indicates an interest in a highly relevant and current field within computer vision (object detection), which has significant practical applications. This shows the student is thinking about contemporary technologies.\r\n*   What needs improvement: The proposal is critically lacking in detail. It does not include a project title, a problem statement, objectives, methodology, scope, expected outcomes, or any literature review. The content \"Yolo Modal Detect\" provides only three words, making it impossible to understand the actual project idea.\r\n*   Specific concerns or suggestions:\r\n    *   It is unclear what \"Modal Detect\" specifically refers to. Is \'Modal\' a typo for \'Model\'? Or does it imply multi-modal detection (e.g., using different types of sensory data)? This needs clarification.\r\n       The student needs to define what they intend to detect, why it is important, and how* they plan to achieve it using YOLO or a similar approach.\r\n    *   A proper FYP proposal requires a structured format that outlines the complete project plan.\r\n\r\n4. Suggested Feedback Message\r\nSubject: Feedback on Your FYP Proposal - [Student Name]\r\n\r\nHi [Student Name],\r\n\r\nThank you for submitting your initial idea for your Final Year Project.\r\n\r\nThe mention of \"Yolo Modal Detect\" suggests you are thinking about an area within computer vision, specifically object detection, which is a very relevant and exciting field with many potential applications. This is a great starting point for exploring modern technologies.\r\n\r\nHowever, your current submission is extremely brief and, unfortunately, does not provide enough information for us to properly assess your project idea or give you detailed guidance. A full FYP proposal needs to clearly articulate your project\'s purpose, what you aim to achieve, and how you plan to do it.\r\n\r\nTo move forward, I need you to significantly expand on this idea. Please refer to the FYP proposal template [or specific guidelines/document name] and structure your proposal to include the following key sections:\r\n\r\n*   A Clear Project Title: Something descriptive that encapsulates your project.\r\n*   Introduction/Problem Statement: What specific real-world problem or gap are you trying to address?\r\n*   Project Objectives: What are the measurable goals you aim to achieve?\r\n*   Literature Review (brief): How does your project relate to existing work in the field? What existing techniques (like YOLO) will you build upon?\r\n*   Methodology: How exactly do you plan to implement \"Yolo Modal Detect\"? What data will you use? What specific tools or algorithms?\r\n   Scope: What aspects will your project cover, and what will it not* cover?\r\n*   Expected Outcomes/Deliverables: What will be the final product or result of your project?\r\n*   Timeline (brief): An initial idea of your project phases.\r\n\r\nAlso, please clarify what \"Modal Detect\" means in your context. Is it a specific type of detection, or did you intend a different term?\r\n\r\nOnce you\'ve developed these sections, please resubmit your revised proposal. I\'m happy to meet with you to discuss your ideas further once you have a more detailed draft.\r\n\r\nLooking forward to seeing your revised proposal!\r\n\r\nBest regards,\r\n\r\n[Supervisor\'s Name]\r\n\r\n5. Required Changes\r\n*   Provide a clear and descriptive Proposal Title.\r\n    *   Priority: Critical\r\n*   Elaborate significantly on the project idea, following a standard proposal structure. This must include:\r\n    *   Problem Statement: What specific problem are you addressing?\r\n    *   Project Objectives: What measurable goals do you aim to achieve?\r\n    *   Methodology: How will you achieve your objectives (e.g., dataset, model, specific YOLO variant, evaluation metrics)?\r\n    *   Scope: Define what aspects will be covered and what will be out of scope.\r\n    *   Expected Outcomes: What will be the deliverables of your project?\r\n    *   Brief Literature Review: How does your idea relate to existing work or previous studies?\r\n    *   Priority: Critical\r\n*   Clarify the term \"Modal Detect\". Explain its meaning in the context of your project, or correct it if it was a typo.\r\n    *   Priority: High',0,'2025-12-04 18:32:25'),(203,40,5,'proposal_rejected',NULL,NULL,15,'Your FYP proposal \"Yolo Modal Detect\" has been rejected by Dr. Lee Wei. Feedback: no',0,'2025-12-04 18:43:19'),(204,5,40,'proposal_submitted',NULL,NULL,16,'Student Jordan has submitted a new FYP proposal: \"test\". Please review it in the Proposal Management system.',0,'2025-12-04 19:07:32'),(205,5,40,'proposal_submitted',NULL,NULL,17,'Student Jordan has submitted a new FYP proposal: \"test\". Please review it in the Proposal Management system.',0,'2025-12-04 19:08:27'),(206,5,40,'proposal_submitted',NULL,NULL,18,'Student Jordan has submitted a new FYP proposal: \"test\". Please review it in the Proposal Management system.',0,'2025-12-04 19:29:57'),(207,40,5,'proposal_approved',NULL,NULL,18,'Your FYP proposal \"test\" has been approved by Dr. Lee Wei. Feedback: 11',0,'2025-12-04 19:30:19'),(208,5,60,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Sim Yi Xiang.\n\nStudent Email: simyx-wm22@student.tarc.edu.my\n\nPlease log in to review this application.',0,'2025-12-05 04:26:34'),(209,60,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by Dr. Lee Wei.\n\nComment from supervisor: yes.',0,'2025-12-05 04:27:26'),(210,5,10,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Ethan Hunt.\n\nStudent Email: ethan@student.com\n\nPlease log in to review this application.',0,'2025-12-05 04:32:26'),(211,61,10,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Ethan Hunt.\n\nStudent Email: ethan@student.com\n\nPlease log in to review this application.',0,'2025-12-05 04:32:36'),(212,10,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by Dr. Lee Wei.',0,'2025-12-05 04:34:02'),(213,10,7,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by Dr. Kumar.',0,'2025-12-05 04:34:34'),(214,7,10,'submission_resubmitted',28,NULL,NULL,'Student submitted file for \'Proposal Submission\'.',0,'2025-12-05 04:37:30'),(215,7,10,'submission_resubmitted',28,NULL,NULL,'Student submitted file for \'Proposal Submission\'.',0,'2025-12-05 04:37:34'),(216,10,7,'submission_approved',28,NULL,NULL,'Your submission for \'Proposal Submission\' has been approved by Dr. Kumar. Comment: yes',0,'2025-12-05 04:38:30'),(217,5,10,'appointment_requested',NULL,31,NULL,'New appointment request from Ethan Hunt on Dec 10, 2025 14:00 - FYP Consultation',0,'2025-12-05 05:20:42'),(218,61,10,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Ethan Hunt.\n\nStudent Email: ethan@student.com\n\nPlease log in to review this application.',0,'2025-12-05 09:53:25'),(219,7,10,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Ethan Hunt.\n\nStudent Email: ethan@student.com\n\nPlease log in to review this application.',0,'2025-12-05 09:53:32'),(220,5,10,'supervisor_application_submitted',NULL,NULL,NULL,'New supervisor application from Ethan Hunt.\n\nStudent Email: ethan@student.com\n\nPlease log in to review this application.',0,'2025-12-05 09:53:38'),(221,10,5,'supervisor_application_approved',NULL,NULL,NULL,'Your supervisor application has been approved by dr lee.',0,'2025-12-05 09:54:28'),(222,10,5,'appointment_rejected',NULL,31,NULL,'Your appointment request for \'FYP Consultation\' on Dec 10, 2025 14:00 has been REJECTED.',0,'2025-12-05 10:20:56'),(223,10,5,'appointment_rejected',NULL,31,NULL,'Your appointment request for \'FYP Consultation\' on Dec 10, 2025 14:00 has been REJECTED.',0,'2025-12-05 10:20:59'),(224,5,60,'proposal_submitted',NULL,NULL,21,'Student Sim Yi Xiang has submitted a new FYP proposal: \"Blockchain-based Supply Chain Management\". Please review it in the Proposal Management system.',0,'2025-12-05 11:00:04'),(225,5,60,'submission_resubmitted',30,NULL,NULL,'Student submitted file for \'Proposal Submission\'.',0,'2025-12-08 18:47:42');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `otp_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores password reset tokens (OTPs).';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES (28,'simyx-wm22@student.tarc.edu.my','$2y$10$Uz0iHdsQZx6MmiPxdeHNFumdhyuRC7EINgVPu8UJHhmQhvCmDSTga','2025-12-05 04:13:59'),(29,'test@gmail.com','$2y$10$/SMup9BLbVtOZhIkq9KON.fkqZzZF7nB873DlBz4TN3av3Y0e3s2S','2025-12-05 04:31:26');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rubrics`
--

DROP TABLE IF EXISTS `rubrics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rubrics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `project_type` enum('project1','project2') NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `submitted_by` int(11) NOT NULL,
  `submitted_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_student_project` (`student_id`,`project_type`),
  KEY `submitted_by` (`submitted_by`),
  CONSTRAINT `rubrics_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`),
  CONSTRAINT `rubrics_ibfk_2` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rubrics`
--

LOCK TABLES `rubrics` WRITE;
/*!40000 ALTER TABLE `rubrics` DISABLE KEYS */;
INSERT INTO `rubrics` VALUES (1,1,'project1','../uploads/rubrics/rubric_project1_student_1_1764264235.pdf',6,'2025-11-28 01:23:55','2025-11-27 17:19:20'),(2,1,'project2','../uploads/rubrics/rubric_project2_student_1_1764264107.pdf',6,'2025-11-28 01:21:47','2025-11-27 17:21:47'),(5,4,'project1','../uploads/rubrics/rubric_project1_student_4_1764265393.pdf',6,'2025-11-28 01:43:13','2025-11-27 17:43:13');
/*!40000 ALTER TABLE `rubrics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_proposals`
--

DROP TABLE IF EXISTS `student_proposals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_proposals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `proposed_title` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `proposal_file_path` varchar(500) DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `feedback` text DEFAULT NULL,
  `reviewed_by` int(11) DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `supervisor_id` (`supervisor_id`),
  KEY `reviewed_by` (`reviewed_by`),
  CONSTRAINT `student_proposals_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`),
  CONSTRAINT `student_proposals_ibfk_2` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`),
  CONSTRAINT `student_proposals_ibfk_3` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_proposals`
--

LOCK TABLES `student_proposals` WRITE;
/*!40000 ALTER TABLE `student_proposals` DISABLE KEYS */;
INSERT INTO `student_proposals` VALUES (11,1,NULL,'Direct Test Project',NULL,'','approved',NULL,NULL,NULL,'2025-12-01 18:36:09'),(13,34,NULL,'Direct',NULL,'','approved',NULL,NULL,NULL,'2025-12-04 01:36:49'),(21,60,5,'Blockchain-based Supply Chain Management','Blockchain is a good method','uploads/proposals/proposal_student_60_1764932404.pdf','pending',NULL,NULL,NULL,'2025-12-05 11:00:04');
/*!40000 ALTER TABLE `student_proposals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `user_id` int(11) NOT NULL COMMENT 'FK to users.id',
  `batch_year` varchar(20) DEFAULT NULL COMMENT 'e.g., 2024/2025',
  `project_title` varchar(255) DEFAULT NULL COMMENT 'Student project title',
  `supervisor_id` int(11) DEFAULT NULL COMMENT 'FK to users.id (the supervisor)',
  `group_id` int(11) DEFAULT NULL COMMENT 'FK to groups.id (the group this student belongs to)',
  PRIMARY KEY (`user_id`),
  KEY `fk_students_supervisor_idx` (`supervisor_id`),
  KEY `fk_students_group_idx` (`group_id`),
  CONSTRAINT `fk_students_group` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_students_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_students_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores student-specific information.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,'2024/2025','AI for Healthcare',6,1),(2,'2024/2025',NULL,5,1),(3,'2024/2025',NULL,NULL,NULL),(4,'2024/2025',NULL,5,1),(10,'2024/2025',NULL,5,1),(34,'2025/2026',NULL,5,NULL),(35,'2023/2024',NULL,NULL,3),(40,'2024/2025','test',5,1),(60,'2024/2025',NULL,5,1);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `submissions`
--

DROP TABLE IF EXISTS `submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `submissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL COMMENT 'FK to users.id',
  `deadline_id` int(11) NOT NULL COMMENT 'FK to deadlines.id',
  `file_path` varchar(255) NOT NULL,
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('submitted','late') NOT NULL DEFAULT 'submitted',
  `feedback` text DEFAULT NULL,
  `grade` varchar(10) DEFAULT NULL,
  `graded_by` int(11) DEFAULT NULL,
  `approval_status` enum('approved','rejected') DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `comments` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_student_deadline` (`student_id`,`deadline_id`),
  KEY `fk_sub_deadline_idx` (`deadline_id`),
  KEY `fk_approved_by` (`approved_by`),
  CONSTRAINT `fk_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sub_deadline` FOREIGN KEY (`deadline_id`) REFERENCES `deadlines` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_sub_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `submissions`
--

LOCK TABLES `submissions` WRITE;
/*!40000 ALTER TABLE `submissions` DISABLE KEYS */;
INSERT INTO `submissions` VALUES (26,40,1,'uploads/submissionsS40_D1_1764761232.pdf','2025-12-03 11:27:12','late',NULL,NULL,NULL,'approved',5,'Dr. Lee Wei (Dec 03, 2025 12:28): Yes, please list down detail in part A\n'),(27,40,5,'uploads/submissionsS40_D5_1764781851.pdf','2025-12-03 17:10:51','late',NULL,NULL,NULL,'approved',5,'Dr. Lee Wei (Dec 03, 2025 18:12): Still need have a little bit change in part A\n'),(28,10,1,'uploads/submissionsS10_D1_1764909454.pdf','2025-12-05 04:37:34','late',NULL,NULL,NULL,'approved',7,'Dr. Kumar (Dec 05, 2025 05:38): yes\n'),(30,60,1,'uploads/submissionsS60_D1_1765219662.pdf','2025-12-08 18:47:42','late',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supervisor_applications`
--

DROP TABLE IF EXISTS `supervisor_applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supervisor_applications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL COMMENT 'FK to users.id (the student)',
  `supervisor_id` int(11) NOT NULL COMMENT 'FK to users.id (the supervisor)',
  `status` enum('pending','confirmed','rejected','cancelled') NOT NULL DEFAULT 'pending' COMMENT 'Status of the application',
  `student_message` text DEFAULT NULL COMMENT 'Optional message from student during application',
  `project_title` varchar(255) NOT NULL COMMENT 'Student''s proposed project title',
  `proposal_file_path` varchar(512) NOT NULL COMMENT 'Path to the uploaded proposal file',
  `supervisor_response` text DEFAULT NULL COMMENT 'Optional feedback from supervisor (e.g., on rejection)',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'When the application was submitted',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'When the status was last changed',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_student_supervisor_unique` (`student_id`,`supervisor_id`),
  KEY `fk_app_student_idx` (`student_id`),
  KEY `fk_app_supervisor_idx` (`supervisor_id`),
  CONSTRAINT `fk_app_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_app_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Tracks student applications to supervisors.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supervisor_applications`
--

LOCK TABLES `supervisor_applications` WRITE;
/*!40000 ALTER TABLE `supervisor_applications` DISABLE KEYS */;
INSERT INTO `supervisor_applications` VALUES (2,3,6,'pending','','权威的','uploads/proposals/student3_sup6_1763295236_Ori_report.pdf',NULL,'2025-11-08 10:12:04','2025-11-16 12:13:56'),(3,10,7,'rejected','I would like to apply for the IoT project.','','',NULL,'2025-11-08 10:12:04','2025-12-05 09:54:28'),(4,4,6,'pending',NULL,'','',NULL,'2025-11-08 10:12:04','2025-11-08 10:12:04'),(5,4,5,'confirmed','Please consider my application for the machine learning topic.','','',NULL,'2025-11-08 10:12:04','2025-11-08 10:12:04'),(6,1,5,'rejected',NULL,'','',NULL,'2025-11-08 10:45:10','2025-12-01 18:44:58'),(12,2,5,'confirmed','','test title','uploads/proposals/student2_sup5_1763919823_authorisationslip_20240122WMD00874.pdf',NULL,'2025-11-23 15:57:46','2025-11-23 17:44:01'),(21,3,5,'pending',NULL,'','',NULL,'2025-11-29 11:14:38','2025-11-29 11:14:38'),(22,34,5,'confirmed',NULL,'','',NULL,'2025-11-30 06:41:57','2025-12-04 01:36:49'),(23,35,5,'rejected',NULL,'','',NULL,'2025-11-30 16:16:47','2025-11-30 18:07:08'),(26,1,2,'rejected',NULL,'','',NULL,'2025-12-01 18:36:09','2025-12-01 18:44:58'),(29,1,6,'confirmed',NULL,'Direct Test Project','',NULL,'2025-12-01 18:44:50','2025-12-01 18:45:05'),(34,40,5,'confirmed',NULL,'','',NULL,'2025-12-03 11:24:40','2025-12-03 17:08:48'),(38,60,5,'confirmed',NULL,'','',NULL,'2025-12-05 04:26:34','2025-12-05 09:53:19'),(39,10,5,'confirmed',NULL,'','',NULL,'2025-12-05 04:32:26','2025-12-05 09:54:28'),(40,10,61,'rejected',NULL,'','',NULL,'2025-12-05 04:32:36','2025-12-05 09:54:28');
/*!40000 ALTER TABLE `supervisor_applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supervisor_availability`
--

DROP TABLE IF EXISTS `supervisor_availability`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supervisor_availability` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supervisor_id` int(11) NOT NULL,
  `day_of_week` varchar(20) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_avail_supervisor_idx` (`supervisor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supervisor_availability`
--

LOCK TABLES `supervisor_availability` WRITE;
/*!40000 ALTER TABLE `supervisor_availability` DISABLE KEYS */;
INSERT INTO `supervisor_availability` VALUES (1,5,'Monday','10:00:00','12:00:00','2025-11-22 09:11:31'),(2,5,'Wednesday','14:00:00','16:00:00','2025-11-22 09:11:31'),(3,6,'Tuesday','09:00:00','11:00:00','2025-11-22 09:11:31'),(4,6,'Friday','15:00:00','17:00:00','2025-11-22 09:11:31'),(7,5,'Tuesday','12:00:00','14:00:00','2025-12-03 11:36:39'),(9,7,'Monday','12:00:00','14:00:00','2025-12-05 04:40:10');
/*!40000 ALTER TABLE `supervisor_availability` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supervisor_courses`
--

DROP TABLE IF EXISTS `supervisor_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supervisor_courses` (
  `supervisor_id` int(11) NOT NULL COMMENT 'FK to users.id',
  `course_id` int(11) NOT NULL COMMENT 'FK to courses.id',
  PRIMARY KEY (`supervisor_id`,`course_id`),
  KEY `fk_sc_course_idx` (`course_id`),
  CONSTRAINT `fk_sc_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_sc_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Links Supervisors to the Courses they can supervise (M:N).';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supervisor_courses`
--

LOCK TABLES `supervisor_courses` WRITE;
/*!40000 ALTER TABLE `supervisor_courses` DISABLE KEYS */;
INSERT INTO `supervisor_courses` VALUES (5,1),(5,2),(6,3);
/*!40000 ALTER TABLE `supervisor_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supervisor_details`
--

DROP TABLE IF EXISTS `supervisor_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supervisor_details` (
  `user_id` int(11) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT 10 COMMENT 'Max number of STUDENTS',
  PRIMARY KEY (`user_id`),
  CONSTRAINT `fk_supervisor_user_details` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Details specific to supervisors.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supervisor_details`
--

LOCK TABLES `supervisor_details` WRITE;
/*!40000 ALTER TABLE `supervisor_details` DISABLE KEYS */;
INSERT INTO `supervisor_details` VALUES (5,10),(6,8),(7,10);
/*!40000 ALTER TABLE `supervisor_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_settings` (
  `setting_key` varchar(100) NOT NULL COMMENT 'config key/name',
  `setting_value` text DEFAULT NULL COMMENT 'config value',
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Stores all system-level dynamic configurations.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
INSERT INTO `system_settings` VALUES ('allowed_file_types','pdf,zip,doc,docx'),('allow_student_applications','true'),('allow_supervisor_capacity_edit','false'),('backup_frequency','weekly'),('backup_last_run','Never'),('current_academic_year','2024/2025'),('maintenance_mode','false'),('max_file_size_mb','1000'),('max_student_applications','3');
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','supervisor','committee','admin') NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `batch_year` varchar(20) DEFAULT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `google_email` varchar(255) DEFAULT NULL,
  `google_integration_enabled` tinyint(1) DEFAULT 0,
  `profile_picture` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`),
  UNIQUE KEY `google_email` (`google_email`),
  KEY `role_index` (`role`),
  KEY `fk_user_supervisor_idx` (`supervisor_id`),
  KEY `fk_users_group_idx` (`group_id`),
  KEY `fk_user_course_idx` (`course_id`),
  CONSTRAINT `fk_user_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_user_supervisor` FOREIGN KEY (`supervisor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_users_group` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Core table for all users.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Ali bin Abu','ali@student.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','student','active','2024/2025',6,2,1,'2025-11-08 10:12:04','2025-12-01 18:57:24',NULL,0,NULL),(2,'Siti binti Aminah','siti@student.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','student','active','2024/2025',5,1,2,'2025-11-08 10:12:04','2025-11-28 07:13:14',NULL,0,NULL),(3,'Charlie Tan','charlie@student.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','student','active','2024/2025',NULL,NULL,1,'2025-11-08 10:12:04','2025-11-18 17:27:06',NULL,0,NULL),(4,'David Lee','david@student.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','student','active','2024/2025',5,1,3,'2025-11-08 10:12:04','2025-11-28 07:48:47',NULL,0,NULL),(5,'dr lee','yixiangshop@gmail.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','supervisor','active',NULL,NULL,NULL,1,'2025-11-08 10:12:04','2025-12-05 09:47:23','yixiangshop@gmail.com',1,NULL),(6,'Prof. Wong','wong@supervisor.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','supervisor','active',NULL,NULL,NULL,1,'2025-11-08 10:12:04','2025-11-30 10:06:50',NULL,0,NULL),(7,'Dr. Kumar','kumar@committee.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','supervisor','active',NULL,NULL,NULL,3,'2025-11-08 10:12:04','2025-11-30 10:06:46',NULL,0,NULL),(8,'Puan Aminah','aminah@committee.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','committee','active','2025/2026',NULL,NULL,2,'2025-11-08 10:12:04','2025-11-30 14:32:59',NULL,0,NULL),(9,'Admin FYP','admin@fyp.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','admin','active',NULL,NULL,NULL,NULL,'2025-11-08 10:12:04','2025-11-18 17:27:06',NULL,0,NULL),(10,'Ethan Hunt','ethan@student.com','$2a$12$7xm.9NW30oMOspxYCGLhduFXYEsvFrpjDEQjHFinr6pJDYkWRFMze','student','active','2024/2025',5,1,1,'2025-11-08 10:12:04','2025-12-05 09:54:28','simyx-wm22@student.tarc.edu.my',1,NULL),(34,'student 2025','2025@gmail.com','$2y$10$R7EKAT8ZZXpcl7.fknj1OehN9vCwNARwqivREJLXaPmj.R8CC0SP.','student','active','2025/2026',5,11,3,'2025-11-30 06:38:51','2025-12-04 01:36:49',NULL,0,NULL),(35,'student 2023','2023@student.com','$2y$10$RQ3KX78wa8ir4mTyWFx1meS90cu1rCx9Rv7kyQgrNuESwF1LmyA32','student','active','2023/2024',NULL,3,3,'2025-11-30 08:46:47','2025-11-30 19:50:48',NULL,0,NULL),(40,'Jordan','Jordan@student.com','$2y$10$245rTJU9VZTRn2dH0ObVr.0kRYfmPea5Y2MbMkWZRriwpILfWt7H2','student','active','2024/2025',5,1,3,'2025-12-03 09:29:36','2025-12-04 19:01:12',NULL,0,'uploads/avatars/avatar_40_1764781572.jpg'),(60,'Sim Yi Xiang','simyx-wm22@student.tarc.edu.my','$2y$10$CVFUzMObhO2Kl708Hk6wk.Li/R8OFRyzSQiy6EGVd.du1h0vwLj6C','student','active','2024/2025',5,1,3,'2025-12-05 04:06:13','2025-12-05 09:53:19',NULL,0,NULL),(61,'Mr Dong Youngbae','Youngbae@supervisor.com','$2y$10$Iy7g8tsfxVD0fNDVQZj9AO8wtmozfIWGBZ3dE11zSfD7ryU2OQF.G','supervisor','active',NULL,NULL,NULL,3,'2025-12-05 04:17:59','2025-12-05 04:17:59',NULL,0,NULL),(62,'Mrs Judy Hopps','Judy@supervisor.com','$2y$10$xZVMawU2tbg.xgHihPhicO.P4yMVEYoKLTNNWVqosw5jy7UVF7DqO','supervisor','active',NULL,NULL,NULL,1,'2025-12-05 04:17:59','2025-12-05 04:17:59',NULL,0,NULL),(63,'Mr Nick Wilde','Nick@supervisor.com','$2y$10$VHffzRRdPwaz0ZU7UTerjuilcDaWOUk3IqNt7IsAH0nCYMGJ4lSu2','supervisor','active',NULL,NULL,NULL,1,'2025-12-05 04:17:59','2025-12-05 04:17:59',NULL,0,NULL),(64,'Mr Xue Zhi Qian ','XueZQ@supervisor.com','$2y$10$qlgIvEwD0IIkKz5rxBGJq.7RWs5rBeY22otrYaNW3QD881wLfJR/m','supervisor','active',NULL,NULL,NULL,3,'2025-12-05 04:17:59','2025-12-05 04:17:59',NULL,0,NULL),(65,'Mr Kwon Ji-yong','Ji-yong@supervisor.com','$2y$10$Lt/V8KThqBI7g4q6Lkz5OOvc3rmkbCK3tCaRZe8W0y2SxQ3SL2Bz6','supervisor','active',NULL,NULL,NULL,3,'2025-12-05 04:18:00','2025-12-05 04:18:00',NULL,0,NULL),(66,'student test','test@gmail.com','$2y$10$SY89I9/gVLRiKOrb0gckdey0UuIg/.nZ7OIMSYGn2ihqFpdpsyMjy','student','','2024/2025',NULL,NULL,3,'2025-12-05 04:31:25','2025-12-05 04:31:25',NULL,0,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-09  3:00:07
