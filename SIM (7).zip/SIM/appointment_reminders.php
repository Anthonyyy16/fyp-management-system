<?php
/**
 * Appointment Reminder Cron Task (TC-APPT-014/015)
 * 
 * This script sends appointment reminders 24 hours before the appointment time.
 * 
 * To set up this cron job on Windows:
 * 1. Use Task Scheduler to run: php C:\path\to\appointment_reminders.php
 * 2. Schedule it to run every hour
 * 
 * To set up on Linux/Mac:
 * Add to crontab: 0 * * * * php /path/to/appointment_reminders.php
 * 
 * @author FYP System
 * @version 1.0
 * @date December 9, 2025
 */

// Suppress output buffering for cron execution
ob_start();

require_once 'db_connect.php';
require_once 'notification_functions.php';
require_once 'email_config.php';

try {
    // Get current time in server timezone (UTC+1)
    $now = new DateTime('now', new DateTimeZone('UTC+1'));
    $reminder_time = $now->format('Y-m-d H:i:s');
    
    // Calculate time window: 23:45 to 24:15 hours before appointment
    // This ensures we send reminder once per appointment even with frequent cron runs
    $search_start = (clone $now)->add(new DateInterval('PT23H45M'))->format('Y-m-d H:i:s');
    $search_end = (clone $now)->add(new DateInterval('PT24H15M'))->format('Y-m-d H:i:s');
    
    // Find appointments that need reminders
    $stmt = $conn->prepare("
        SELECT 
            a.id,
            a.student_id,
            a.supervisor_id,
            a.appointment_start,
            a.title,
            s.name as student_name,
            s.email as student_email,
            sv.name as supervisor_name,
            sv.email as supervisor_email
        FROM appointments a
        JOIN users s ON a.student_id = s.id
        JOIN users sv ON a.supervisor_id = sv.id
        WHERE a.status IN ('pending', 'confirmed')
        AND a.reminder_sent = FALSE
        AND a.appointment_start BETWEEN ? AND ?
        ORDER BY a.appointment_start ASC
    ");
    
    $stmt->bind_param('ss', $search_start, $search_end);
    $stmt->execute();
    $result = $stmt->get_result();
    $appointments_to_remind = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    $reminders_sent = 0;
    
    foreach ($appointments_to_remind as $appointment) {
        try {
            // Prepare reminder message for student
            $appointment_time = date('M d, Y \a\t H:i', strtotime($appointment['appointment_start']));
            $student_message = "Reminder: You have an appointment with " . $appointment['supervisor_name'] . 
                               " (" . $appointment['title'] . ") scheduled for " . $appointment_time . ".";
            
            // Prepare reminder message for supervisor
            $supervisor_message = "Reminder: You have an appointment with " . $appointment['student_name'] . 
                                  " (" . $appointment['title'] . ") scheduled for " . $appointment_time . ".";
            
            // Send notification to student
            if (!empty($appointment['student_email'])) {
                createNotificationAndEmail(
                    $conn,
                    $appointment['student_id'],
                    $appointment['supervisor_id'],
                    'appointment_reminder',
                    null,
                    $student_message,
                    $appointment['student_email'],
                    $appointment['id']
                );
            }
            
            // Send notification to supervisor
            if (!empty($appointment['supervisor_email'])) {
                createNotificationAndEmail(
                    $conn,
                    $appointment['supervisor_id'],
                    $appointment['student_id'],
                    'appointment_reminder',
                    null,
                    $supervisor_message,
                    $appointment['supervisor_email'],
                    $appointment['id']
                );
            }
            
            // Mark appointment as reminder sent
            $stmt_update = $conn->prepare("
                UPDATE appointments 
                SET reminder_sent = TRUE, reminder_sent_at = ?
                WHERE id = ?
            ");
            $stmt_update->bind_param('si', $reminder_time, $appointment['id']);
            $stmt_update->execute();
            $stmt_update->close();
            
            $reminders_sent++;
            
        } catch (Exception $e) {
            // Log individual reminder failures but continue processing others
            error_log("Failed to send reminder for appointment {$appointment['id']}: " . $e->getMessage());
            continue;
        }
    }
    
    // Log the cron task execution
    $log_message = "[" . date('Y-m-d H:i:s') . "] Appointment Reminder Cron Task: {$reminders_sent} reminders sent.";
    error_log($log_message);
    
    ob_end_clean();
    echo "Appointment Reminder Cron Task Completed: {$reminders_sent} reminders sent.\n";
    
} catch (Exception $e) {
    ob_end_clean();
    error_log("Appointment Reminder Cron Task Error: " . $e->getMessage());
    echo "Error: " . $e->getMessage() . "\n";
} finally {
    $conn->close();
}

?>
