<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("location: ../index.php");
    exit;
}
require_once '../db_connect.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Batches</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="Admin_Batch.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<body>
    <div class="navbar">
        <h2>FYP System - Batch Management</h2>
        <div class="button-group">
            <a href="Admin_Dashboard.php"><button>Dashboard</button></a>
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>
    <div class="main-container">
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Admin Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="Admin_Dashboard.php"><span class="material-icons">dashboard</span>Dashboard</a></li>
                <li><a href="Admin_UserMngm.php"><span class="material-icons">people</span>User Management</a></li>
                <li><a href="Admin_Announcements.php"><span class="material-icons">campaign</span>Announcements</a></li>
                <li><a href="Admin_Deadline.php"><span class="material-icons">event</span>Global Deadlines</a></li>
                <li><a href="Admin_Allocation.php"><span class="material-icons">assignment_ind</span>Project Allocation</a></li>
                <li><a href="Admin_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <!-- <li><a href="Admin_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li> -->
                <li class="active"><a href="Admin_Batch.php"><span class="material-icons">school</span>Batch Management</a></li>
                <li><a href="Admin_Report.php"><span class="material-icons">bar_chart</span>Reports</a></li>
                <li><a href="Admin_System.php"><span class="material-icons">settings</span>System Settings</a></li>
            </ul>
        </div>

        <div class="main-content">
            <div class="content-header">
                <h1>Manage Academic Batches</h1>
                <p>Create and manage academic year batches. Each batch can have multiple project groups.</p>
            </div>

            <div class="card">
                <!-- Create Batch Section -->
                <div style="margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color);">
                    <h3>Create New Batch</h3>
                    <div style="display: grid; grid-template-columns: 1fr auto; gap: 15px; margin-top: 15px;">
                        <input type="text" id="batchYearInput" class="form-input" placeholder="e.g., 2025/2026" style="padding: 10px;">
                        <button onclick="createBatch()" class="btn primary">Create Batch</button>
                    </div>
                    <p style="font-size: 0.9rem; color: var(--muted); margin-top: 10px;">Format: YYYY/YYYY (e.g., 2024/2025)</p>
                </div>

                <!-- Success/Error Messages -->
                <div id="successMessage" style="display: none; background-color: #d4edda; color: #155724; padding: 12px; border: 1px solid #c3e6cb; border-radius: var(--radius); margin-bottom: 15px;"></div>
                <div id="errorMessage" style="display: none; background-color: #f8d7da; color: #721c24; padding: 12px; border: 1px solid #f5c6cb; border-radius: var(--radius); margin-bottom: 15px;"></div>

                <!-- Batches Table -->
                <div>
                    <h3>Existing Batches</h3>
                    <div class="data-table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Batch Year</th>
                                    <th>Groups</th>
                                    <th>Supervisors</th>
                                    <th>Moderators Assigned</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="batchesTableBody">
                                <tr>
                                    <td colspan="6" style="text-align: center; color: var(--muted);">Loading batches...</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- View Batch Details Modal -->
    <div class="modal" id="batchDetailsModal" style="display: none;">
        <div class="modal-content">
            <h3>
                <span class="material-icons" style="vertical-align: middle; margin-right: 8px;">school</span>
                Batch <span id="modalBatchYear"></span> Management
            </h3>
            
            <!-- Tab Navigation -->
            <div class="modal-tabs">
                <button class="tab-button active" data-tab="groups">
                    <span class="material-icons" style="font-size: 20px;">groups</span>
                    Groups & Supervisors
                </button>
                <button class="tab-button" data-tab="committees">
                    <span class="material-icons" style="font-size: 20px;">verified_user</span>
                    Committee Management
                </button>
            </div>

            <!-- TAB 1: Groups & Supervisors -->
            <div id="groups-tab" class="tab-content active">
                <!-- Add Group Section -->
                <div class="form-section">
                    <h4>
                        <span class="material-icons" style="vertical-align: middle; margin-right: 8px; font-size: 20px;">add_box</span>
                        Add New Group
                    </h4>
                    <div class="form-row">
                        <select id="supervisorSelect" class="form-input" style="padding: 10px;">
                            <option value="">-- Select Supervisor --</option>
                        </select>
                        <button class="btn primary" onclick="addGroupToBatch()" style="white-space: nowrap;">
                            <span class="material-icons" style="font-size: 18px;">add</span>
                            Add Group
                        </button>
                    </div>
                    <div id="addGroupMessage" style="margin-top: 10px; display: none;"></div>
                </div>

                <!-- Groups Table -->
                <div class="data-table-wrapper">
                    <h4 style="padding: 20px 20px 0 20px;">Project Groups</h4>
                    <table class="management-table">
                        <thead>
                            <tr>
                                <th>Supervisor</th>
                                <th>Moderator</th>
                                <th>Change Supervisor</th>
                                <th>Change Moderator</th>
                                <th style="text-align: center;">Actions</th>
                            </tr>
                        </thead>
                        <tbody id="groupsTableBody"></tbody>
                    </table>
                </div>
            </div>

            <!-- TAB 2: Committee Management -->
            <div id="committees-tab" class="tab-content">
                <!-- Add Committee Section -->
                <div class="form-section">
                    <h4>
                        <span class="material-icons" style="vertical-align: middle; margin-right: 8px; font-size: 20px;">person_add</span>
                        Add Committee Member
                    </h4>
                    <div class="form-row">
                        <select id="committeeSelect" class="form-input" style="padding: 10px;">
                            <option value="">-- Select Committee Member --</option>
                        </select>
                        <button class="btn success" onclick="addCommitteeToBatch()" style="white-space: nowrap;">
                            <span class="material-icons" style="font-size: 18px;">add_circle</span>
                            Add Committee
                        </button>
                    </div>
                    <div id="addCommitteeMessage" style="margin-top: 10px; display: none;"></div>
                </div>

                <!-- Committee List -->
                <div>
                    <h4 style="margin-bottom: 15px;">Batch Committee Members</h4>
                    <div id="committeeList" style="min-height: 200px;">
                        <div class="empty-state">
                            <p>No committee members assigned yet.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="modal-footer">
                <button class="btn secondary" data-close-modal>
                    <span class="material-icons" style="font-size: 18px;">close</span>
                    Close
                </button>
            </div>
        </div>
    </div>

    <script>
        let allSupervisors = [];
        let allCommittees = [];
        let currentBatchYear = '';

        document.addEventListener('DOMContentLoaded', function() {
            loadBatches();
            fetchAllSupervisors();
            fetchAllCommittees();
            setupTabNavigation();
            setupModalCloseHandlers();
        });

        // Setup Tab Navigation
        function setupTabNavigation() {
            const tabButtons = document.querySelectorAll('.tab-button');
            const tabContents = document.querySelectorAll('.tab-content');

            tabButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const tabName = this.getAttribute('data-tab');

                    // Hide all tabs
                    tabContents.forEach(content => {
                        content.classList.remove('active');
                    });

                    // Remove active class from all buttons
                    tabButtons.forEach(btn => {
                        btn.classList.remove('active');
                    });

                    // Show selected tab
                    document.getElementById(tabName + '-tab').classList.add('active');
                    this.classList.add('active');
                });
            });
        }

        // Setup Modal Close Handlers
        function setupModalCloseHandlers() {
            document.addEventListener('click', (e) => {
                if (e.target.hasAttribute('data-close-modal')) {
                    const modal = e.target.closest('.modal');
                    if (modal) modal.style.display = 'none';
                } else if (e.target.classList.contains('modal') && !e.target.closest('.modal-content')) {
                    e.target.style.display = 'none';
                }
            });

            // Close on Escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    const modal = document.getElementById('batchDetailsModal');
                    if (modal && modal.style.display !== 'none') {
                        modal.style.display = 'none';
                    }
                }
            });
        }

        // Fetch all supervisors for the dropdown
        async function fetchAllSupervisors() {
            try {
                const response = await fetch('batch_action.php?action=fetch_supervisors');
                allSupervisors = await response.json();
            } catch (error) {
                console.error('Error fetching supervisors:', error);
            }
        }

        // Fetch all committees (supervisors who can be moderators)
        async function fetchAllCommittees() {
            try {
                const response = await fetch('batch_action.php?action=fetch_supervisors');
                allCommittees = await response.json();
            } catch (error) {
                console.error('Error fetching committees:', error);
            }
        }

        // Load batches
        async function loadBatches() {
            const batchesTableBody = document.getElementById('batchesTableBody');

            try {
                const response = await fetch('batch_action.php?action=fetch_batches');
                const batches = await response.json();

                if (!Array.isArray(batches) || batches.length === 0) {
                    batchesTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center;">No batches found. Create one to get started.</td></tr>';
                    return;
                }

                batchesTableBody.innerHTML = '';
                batches.forEach(batch => {
                    const created = new Date(batch.created_at).toLocaleDateString();
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td><strong>${batch.batch_year}</strong></td>
                        <td>${batch.group_count}</td>
                        <td>${batch.supervisor_count}</td>
                        <td>${batch.assigned_moderators}/${batch.group_count}</td>
                        <td>${created}</td>
                        <td>
                            <button class="btn primary small" onclick="viewBatchDetails('${batch.batch_year}')">
                                <span class="material-icons" style="font-size: 16px;">edit</span>
                                Manage
                            </button>
                            <button class="btn danger small" onclick="deleteBatchConfirm('${batch.batch_year}')">
                                <span class="material-icons" style="font-size: 16px;">delete</span>
                                Delete
                            </button>
                        </td>
                    `;
                    batchesTableBody.appendChild(tr);
                });
            } catch (error) {
                console.error('Error loading batches:', error);
                batchesTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: red;">Error loading batches</td></tr>';
            }
        }

        // Create batch
        async function createBatch() {
            const batchYearInput = document.getElementById('batchYearInput');
            const batchYear = batchYearInput.value.trim();
            const successMessage = document.getElementById('successMessage');
            const errorMessage = document.getElementById('errorMessage');

            if (!batchYear) {
                showMessage(errorMessage, 'Please enter a batch year', 'error');
                return;
            }

            // Validate format (YYYY/YYYY)
            if (!/^\d{4}\/\d{4}$/.test(batchYear)) {
                showMessage(errorMessage, 'Invalid format. Use YYYY/YYYY (e.g., 2024/2025)', 'error');
                return;
            }

            try {
                const response = await fetch('batch_action.php?action=create_batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ batch_year: batchYear })
                });

                const result = await response.json();

                if (result.success) {
                    showMessage(successMessage, 'Batch created successfully!', 'success');
                    batchYearInput.value = '';
                    setTimeout(() => successMessage.style.display = 'none', 3000);
                    loadBatches();
                } else {
                    showMessage(errorMessage, result.message || 'Failed to create batch', 'error');
                }
            } catch (error) {
                console.error('Error creating batch:', error);
                showMessage(errorMessage, 'Error creating batch', 'error');
            }
        }

        // Show message helper
        function showMessage(element, text, type) {
            element.textContent = text;
            element.className = 'alert alert-' + type;
            element.style.display = 'block';
        }

        // View batch details with management
        async function viewBatchDetails(batchYear) {
            currentBatchYear = batchYear;
            document.getElementById('modalBatchYear').textContent = batchYear;

            // Reset tabs to first tab
            document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            document.querySelector('.tab-button[data-tab="groups"]').classList.add('active');
            document.getElementById('groups-tab').classList.add('active');

            // Fetch supervisors specific to this batch
            const supervisorSelect = document.getElementById('supervisorSelect');
            supervisorSelect.innerHTML = '<option value="">-- Select Supervisor --</option>';
            try {
                const supResponse = await fetch(`batch_action.php?action=fetch_supervisors&batch_year=${encodeURIComponent(batchYear)}`);
                const batchSupervisors = await supResponse.json();
                batchSupervisors.forEach(sup => {
                    const option = document.createElement('option');
                    option.value = sup.id;
                    option.textContent = sup.name;
                    supervisorSelect.appendChild(option);
                });
            } catch (error) {
                console.error('Error fetching batch supervisors:', error);
            }

            // Populate committee select (all supervisors can be committees)
            const committeeSelect = document.getElementById('committeeSelect');
            committeeSelect.innerHTML = '<option value="">-- Select Committee Member --</option>';
            allCommittees.forEach(committee => {
                const option = document.createElement('option');
                option.value = committee.id;
                option.textContent = committee.name;
                committeeSelect.appendChild(option);
            });

            await loadBatchGroups(batchYear);
            await loadBatchCommittees(batchYear);
            document.getElementById('batchDetailsModal').style.display = 'flex';
        }

        // Load groups for batch
        async function loadBatchGroups(batchYear) {
            const groupsTableBody = document.getElementById('groupsTableBody');

            try {
                // Fetch supervisors for this specific batch
                const supResponse = await fetch(`batch_action.php?action=fetch_supervisors&batch_year=${encodeURIComponent(batchYear)}`);
                const batchSupervisors = await supResponse.json();

                const response = await fetch(`batch_action.php?action=fetch_batch_details&batch_year=${encodeURIComponent(batchYear)}`);
                const result = await response.json();

                if (result.success && result.groups) {
                    groupsTableBody.innerHTML = '';
                    result.groups.forEach(group => {
                        const tr = document.createElement('tr');

                        // Create supervisor select with batch-specific supervisors
                        let supervisorSelectHtml = `<select class="supervisor-select-${group.id} table-select">`;
                        supervisorSelectHtml += '<option value="">-- Select Supervisor --</option>';
                        batchSupervisors.forEach(sup => {
                            const selected = sup.id == group.supervisor_id ? 'selected' : '';
                            supervisorSelectHtml += `<option value="${sup.id}" ${selected}>${sup.name}</option>`;
                        });
                        supervisorSelectHtml += '</select>';

                        // Create moderator select (all supervisors can be moderators, not limited by batch)
                        let moderatorSelectHtml = `<select class="moderator-select-${group.id} table-select">`;
                        moderatorSelectHtml += '<option value="">-- Select Moderator --</option>';
                        allSupervisors.forEach(sup => {
                            const selected = sup.id == group.moderator_id ? 'selected' : '';
                            moderatorSelectHtml += `<option value="${sup.id}" ${selected}>${sup.name}</option>`;
                        });
                        moderatorSelectHtml += '</select>';

                        tr.innerHTML = `
                            <td><span class="badge badge-primary">${group.supervisor_name || '(None)'}</span></td>
                            <td><span class="badge badge-warning">${group.moderator_name || '(Unassigned)'}</span></td>
                            <td>${supervisorSelectHtml}</td>
                            <td>${moderatorSelectHtml}</td>
                            <td style="text-align: center;">
                                <div class="button-group-inline">
                                    <button class="btn primary small" onclick="changeSupervisor(${group.id})" title="Change Supervisor">
                                        <span class="material-icons" style="font-size: 16px;">person_add</span>
                                        Change Sup
                                    </button>
                                    <button class="btn success small" onclick="changeModerator(${group.id})" title="Change Moderator">
                                        <span class="material-icons" style="font-size: 16px;">verified_user</span>
                                        Change Mod
                                    </button>
                                    <button class="btn danger small" onclick="deleteGroupConfirm(${group.id})" title="Delete Group">
                                        <span class="material-icons" style="font-size: 16px;">delete</span>
                                        Delete
                                    </button>
                                </div>
                            </td>
                        `;
                        groupsTableBody.appendChild(tr);
                    });

                    if (result.groups.length === 0) {
                        groupsTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 30px;"><div class="empty-state"><p>No groups in this batch. Add one using the form above.</p></div></td></tr>';
                    }
                } else {
                    groupsTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 30px;"><div class="empty-state"><p>No groups in this batch. Add one using the form above.</p></div></td></tr>';
                }
            } catch (error) {
                console.error('Error fetching groups:', error);
                groupsTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px; color: red;">Error loading groups: ' + error.message + '</td></tr>';
            }
        }

        // Load batch committees
        async function loadBatchCommittees(batchYear) {
            const committeeList = document.getElementById('committeeList');

            try {
                const response = await fetch(`batch_action.php?action=fetch_batch_committees&batch_year=${encodeURIComponent(batchYear)}`);
                const result = await response.json();

                if (result.success && result.committees && result.committees.length > 0) {
                    committeeList.innerHTML = '';
                    result.committees.forEach(committee => {
                        const div = document.createElement('div');
                        div.className = 'committee-item';
                        div.innerHTML = `
                            <div class="committee-info">
                                <div class="committee-name">
                                    <span class="material-icons" style="vertical-align: middle; margin-right: 6px; font-size: 18px;">person</span>
                                    ${committee.name}
                                </div>
                                <div class="committee-role">${committee.email || 'No email provided'}</div>
                            </div>
                            <div class="committee-actions">
                                <button class="btn danger small" onclick="removeCommitteeFromBatch(${committee.id}, '${batchYear}')">
                                    <span class="material-icons" style="font-size: 16px;">remove_circle</span>
                                    Remove
                                </button>
                            </div>
                        `;
                        committeeList.appendChild(div);
                    });
                } else {
                    committeeList.innerHTML = '<div class="empty-state"><p>No committee members assigned to this batch yet.</p></div>';
                }
            } catch (error) {
                console.error('Error loading committees:', error);
                committeeList.innerHTML = '<div class="empty-state"><p>Error loading committee members</p></div>';
            }
        }

        // Add group to batch
        async function addGroupToBatch() {
            const supervisorSelect = document.getElementById('supervisorSelect');
            const supervisorId = supervisorSelect.value;
            const addGroupMessage = document.getElementById('addGroupMessage');

            if (!supervisorId) {
                showMessage(addGroupMessage, 'Please select a supervisor', 'error');
                return;
            }

            try {
                const response = await fetch('batch_action.php?action=add_group_to_batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        batch_year: currentBatchYear,
                        supervisor_id: parseInt(supervisorId)
                    })
                });

                const result = await response.json();

                if (result.success) {
                    showMessage(addGroupMessage, 'Group added successfully!', 'success');
                    supervisorSelect.value = '';
                    setTimeout(() => addGroupMessage.style.display = 'none', 3000);
                    loadBatchGroups(currentBatchYear);
                } else {
                    showMessage(addGroupMessage, result.message || 'Failed to add group', 'error');
                }
            } catch (error) {
                console.error('Error adding group:', error);
                showMessage(addGroupMessage, 'Error adding group', 'error');
            }
        }

        // Add committee to batch
        async function addCommitteeToBatch() {
            const committeeSelect = document.getElementById('committeeSelect');
            const committeeId = committeeSelect.value;
            const addCommitteeMessage = document.getElementById('addCommitteeMessage');

            if (!committeeId) {
                showMessage(addCommitteeMessage, 'Please select a committee member', 'error');
                return;
            }

            try {
                const response = await fetch('batch_action.php?action=add_committee_to_batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        batch_year: currentBatchYear,
                        committee_id: parseInt(committeeId)
                    })
                });

                const result = await response.json();

                if (result.success) {
                    showMessage(addCommitteeMessage, 'Committee member added successfully!', 'success');
                    committeeSelect.value = '';
                    setTimeout(() => addCommitteeMessage.style.display = 'none', 3000);
                    loadBatchCommittees(currentBatchYear);
                } else {
                    showMessage(addCommitteeMessage, result.message || 'Failed to add committee', 'error');
                }
            } catch (error) {
                console.error('Error adding committee:', error);
                showMessage(addCommitteeMessage, 'Error adding committee', 'error');
            }
        }

        // Remove committee from batch
        async function removeCommitteeFromBatch(committeeId, batchYear) {
            if (!confirm('Remove this committee member from the batch?')) {
                return;
            }

            try {
                const response = await fetch('batch_action.php?action=remove_committee_from_batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        batch_year: batchYear,
                        committee_id: committeeId
                    })
                });

                const result = await response.json();

                if (result.success) {
                    loadBatchCommittees(batchYear);
                } else {
                    alert(result.message || 'Failed to remove committee member');
                }
            } catch (error) {
                console.error('Error removing committee:', error);
                alert('Error removing committee member');
            }
        }

        // Change supervisor for group
        async function changeSupervisor(groupId) {
            const selectElement = document.querySelector(`.supervisor-select-${groupId}`);
            const newSupervisorId = selectElement.value;

            if (!newSupervisorId) {
                alert('Please select a supervisor');
                return;
            }

            try {
                const response = await fetch('batch_action.php?action=assign_supervisor_to_group', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        group_id: groupId,
                        supervisor_id: parseInt(newSupervisorId)
                    })
                });

                const result = await response.json();

                if (result.success) {
                    loadBatchGroups(currentBatchYear);
                } else {
                    alert(result.message || 'Failed to change supervisor');
                }
            } catch (error) {
                console.error('Error changing supervisor:', error);
                alert('Error changing supervisor');
            }
        }

        // Change moderator for group
        async function changeModerator(groupId) {
            const selectElement = document.querySelector(`.moderator-select-${groupId}`);
            const newModeratorId = selectElement.value;

            try {
                const response = await fetch('batch_action.php?action=assign_moderator_to_group', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        group_id: groupId,
                        moderator_id: newModeratorId ? parseInt(newModeratorId) : null
                    })
                });

                const result = await response.json();

                if (result.success) {
                    loadBatchGroups(currentBatchYear);
                } else {
                    alert(result.message || 'Failed to change moderator');
                }
            } catch (error) {
                console.error('Error changing moderator:', error);
                alert('Error changing moderator');
            }
        }

        // Delete group with confirmation
        async function deleteGroupConfirm(groupId) {
            if (!confirm('Are you sure you want to delete this group? This cannot be undone.')) {
                return;
            }

            try {
                const response = await fetch('batch_action.php?action=remove_group', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ group_id: groupId })
                });

                const result = await response.json();

                if (result.success) {
                    loadBatchGroups(currentBatchYear);
                } else {
                    alert(result.message || 'Failed to delete group');
                }
            } catch (error) {
                console.error('Error deleting group:', error);
                alert('Error deleting group');
            }
        }

        // Delete batch with confirmation
        async function deleteBatchConfirm(batchYear) {
            if (!confirm(`Are you sure you want to delete batch ${batchYear}? This cannot be undone.`)) {
                return;
            }

            try {
                const response = await fetch('batch_action.php?action=delete_batch', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ batch_year: batchYear })
                });

                const result = await response.json();
                const successMessage = document.getElementById('successMessage');
                const errorMessage = document.getElementById('errorMessage');

                if (result.success) {
                    showMessage(successMessage, 'Batch deleted successfully!', 'success');
                    setTimeout(() => successMessage.style.display = 'none', 3000);
                    loadBatches();
                } else {
                    showMessage(errorMessage, result.message || 'Failed to delete batch', 'error');
                }
            } catch (error) {
                console.error('Error deleting batch:', error);
                showMessage(document.getElementById('errorMessage'), 'Error deleting batch', 'error');
            }
        }
    </script>
</body>

</html>
