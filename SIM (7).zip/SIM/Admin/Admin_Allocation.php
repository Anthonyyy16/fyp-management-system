<?php
session_start();

if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    header("Location: ../index.php");
    exit();
}
require_once '../db_connect.php';


$batch_years = [];
$result = $conn->query("SELECT DISTINCT batch_year FROM groups WHERE batch_year IS NOT NULL AND batch_year != '' ORDER BY batch_year DESC");
while ($row = $result->fetch_assoc()) {
    $batch_years[] = $row['batch_year'];
}


$supervisors = [];
$sup_result = $conn->query("SELECT id, name FROM users WHERE role = 'supervisor' AND status = 'active' ORDER BY name ASC");
while ($row = $sup_result->fetch_assoc()) {
    $supervisors[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Allocation - Admin</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="admin.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        .capacity-list {
            list-style: none;
            padding: 0;
            max-height: 200px;
            overflow-y: auto;
        }

        .capacity-list li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px;
            border-bottom: 1px solid var(--border-color);
        }

        .capacity-list input {
            width: 60px;
            text-align: center;
        }

        .preference-badge {
            padding: 3px 8px;
            border-radius: var(--radius);
            font-size: 0.75em;
            font-weight: 500;
            margin-left: 8px;
            display: inline-block;
            text-transform: capitalize;
        }

        .pref-independent {
            background-color: #E0E7FF;
            color: #4338CA;
        }

        .pref-group {
            background-color: #D1FAE5;
            color: #065F46;
        }

        .pref-undecided {
            background-color: #FEF3C7;
            color: #92400E;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <h2>Admin Panel - Project Allocation</h2>
        <div class="button-group">
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>

    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Admin Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="Admin_Dashboard.php"><span class="material-icons">dashboard</span> Dashboard</a></li>
                <li><a href="Admin_UserMngm.php"><span class="material-icons">people</span> User Management</a></li>
                <li><a href="Admin_announcements.php"><span class="material-icons">campaign</span> Announcements</a></li>
                <li><a href="Admin_deadline.php"><span class="material-icons">event_note</span> Global Deadlines</a></li>
                <li class="active"><a href="Admin_allocation.php"><span class="material-icons">assignment_ind</span> Project Allocation</a></li>
                <li><a href="Admin_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <!-- <li><a href="Admin_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li> -->
                <li><a href="Admin_Batch.php"><span class="material-icons">school</span>Batch Management</a></li>
                <li><a href="Admin_Report.php"><span class="material-icons">bar_chart</span> Reports</a></li>
                <li><a href="Admin_System.php"><span class="material-icons">settings</span> System Settings</a></li>
            </ul>
        </div>
        <!-- Main Content -->
        <div class="main-content">
            <div class="content-header">
                <h1>Manage Project Allocation</h1>
                <p>Assign supervisors to student groups and individuals.</p>
            </div>

            <div class="card actions">
                <div class="filters">
                    <select id="batchFilter" class="filter-select">
                        <option value="all">All Batches</option>
                        <?php foreach ($batch_years as $year): ?>
                            <option value="<?php echo htmlspecialchars($year); ?>"><?php echo htmlspecialchars($year); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select id="supervisorFilter" class="filter-select">
                        <option value="all">All Supervisors</option>
                        <?php foreach ($supervisors as $supervisor): ?>
                            <option value="<?php echo $supervisor['id']; ?>"><?php echo htmlspecialchars($supervisor['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select id="statusFilter" class="filter-select">
                        <option value="all">All Statuses</option>
                        <option value="unassigned">Unassigned</option>
                        <option value="assigned">Assigned</option>
                    </select>
                    <select id="courseFilter" class="filter-select">
                        <option value="all">All Courses</option>
                        <?php $course_result = $conn->query("SELECT id, name FROM courses ORDER BY name ASC");
                        while ($course = $course_result->fetch_assoc()): ?>
                            <option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                    <select id="facultyFilter" class="filter-select">
                        <option value="all">All Faculties</option>
                        <?php $faculty_result = $conn->query("SELECT id, name FROM faculties ORDER BY name ASC");
                        while ($faculty = $faculty_result->fetch_assoc()): ?>
                            <option value="<?php echo $faculty['id']; ?>"><?php echo htmlspecialchars($faculty['name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                    <input type="text" id="search" placeholder="Search by project or student...">
                </div>
                <button id="manageCapacityBtn" class="btn secondary"><span class="material-icons">tune</span> Manage Capacities</button>
            </div>

            <div id="bulkActionsToolbar" class="bulk-actions-toolbar" style="display: none;">
                <div>
                    <span id="selectionCount">0 item(s) selected</span>
                </div>
                <div>
                    <button id="bulkAssignBtn" class="btn primary small">
                        <span class="material-icons" style="font-size: 1.2em; vertical-align: middle; margin-right: 4px;">supervisor_account</span>
                        Bulk Assign Supervisor
                    </button>
                </div>
            </div>

            <div class="card">
                <h3>Student Groups & Individuals</h3>
                <div class="data-table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAllCheckbox"></th>
                                <th>Student Name / Email</th>
                                <th>Course</th>
                                <th>Batch</th>
                                <th>Project Title</th>
                                <th>Supervisor</th>
                                <th>Assignment Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="groupsTableBody">
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modals -->
    <div class="modal" id="assignModal" style="display: none;">
        <div class="modal-content">
            <h3 id="modalTitle">Assign Supervisor</h3>
            <form id="assignForm">
                <input type="hidden" id="assignPayload">
                <div id="assigningText" style="padding: 12px; background-color: #f3f4f6; border-radius: 6px; margin-bottom: 16px; font-size: 0.9rem; color: #333;"></div>
                <div class="form-group">
                    <label for="supervisorSelect">Select a Supervisor for this Batch (Load in Batch)</label>
                    <select id="supervisorSelect" name="supervisor_id" required></select>
                    <p style="font-size: 0.8rem; color: #666; margin-top: 8px;">⚠️ Only supervisors available for this batch are shown below.</p>
                </div>
                <div class="form-buttons">
                    <button type="button" class="btn secondary" data-close-modal>Cancel</button>
                    <button type="submit" class="btn primary">Confirm Assignment</button>
                </div>
            </form>
        </div>
    </div>
    <div class="modal" id="capacityModal" style="display: none;">
        <div class="modal-content">
            <h3>Manage Supervisor Capacities</h3>
            <div class="filters" style="margin-bottom: 20px;">
                <label for="capacityBatchFilter" style="margin-right: 10px; font-weight: 500;">Filter by Batch:</label>
                <select id="capacityBatchFilter" class="filter-select">
                    <option value="all">All Batches</option>
                    <?php foreach ($batch_years as $year): ?>
                        <option value="<?php echo htmlspecialchars($year); ?>"><?php echo htmlspecialchars($year); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <form id="capacityForm">
                <ul id="capacityList" class="capacity-list"></ul>
                <div class="form-buttons">
                    <button type="button" class="btn secondary" data-close-modal>Cancel</button>
                    <button type="submit" class="btn primary">Save Capacities</button>
                </div>
            </form>
        </div>
    </div>
    <!-- Removed Members Modal -->

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            
            let supervisorsWithLoad = [];
            let allStudentsData = []; 

            const courseFilter = document.getElementById('courseFilter');
            const facultyFilter = document.getElementById('facultyFilter');
            const batchFilter = document.getElementById('batchFilter');
            const supervisorFilter = document.getElementById('supervisorFilter');
            const statusFilter = document.getElementById('statusFilter');
            const searchInput = document.getElementById('search');
            const studentsTableBody = document.getElementById('groupsTableBody');

            
            const assignModal = document.getElementById('assignModal');
            const assignForm = document.getElementById('assignForm');
            const supervisorSelect = document.getElementById('supervisorSelect');
            const modalTitle = document.getElementById('modalTitle');
            const assigningText = document.getElementById('assigningText');
            const assignPayload = document.getElementById('assignPayload');

            
            let projectTitleGroup;

            
            const manageCapacityBtn = document.getElementById('manageCapacityBtn');
            const capacityModal = document.getElementById('capacityModal');
            const capacityForm = document.getElementById('capacityForm');
            const capacityList = document.getElementById('capacityList');

            
            const bulkActionsToolbar = document.getElementById('bulkActionsToolbar');
            const selectionCountSpan = document.getElementById('selectionCount');
            const selectAllCheckbox = document.getElementById('selectAllCheckbox');
            const bulkAssignBtn = document.getElementById('bulkAssignBtn');



            const fetchSupervisors = (studentIdOrBatch = null) => {
                let url = 'admin_action.php?action=fetch_supervisors_with_load';
                if (studentIdOrBatch) {
                    // If it looks like a number, treat it as student_id
                    if (!isNaN(studentIdOrBatch)) {
                        url += '&student_id=' + encodeURIComponent(studentIdOrBatch);
                    } else {
                        // Otherwise treat it as batch_year
                        url += '&batch_year=' + encodeURIComponent(studentIdOrBatch);
                    }
                }
                return fetch(url, {
                    credentials: 'same-origin'
                })
                    .then(res => res.json())
                    .then(data => {
                        supervisorsWithLoad = data;
                        populateSupervisorSelect(supervisorSelect);
                    });
            };

            const fetchStudents = () => {
                const batch = batchFilter.value;
                const supervisor = supervisorFilter.value;
                const status = statusFilter.value;
                const course = courseFilter.value;
                const faculty = facultyFilter.value;
                const search = searchInput.value;

                studentsTableBody.innerHTML = '<tr><td colspan="8" style="text-align:center;">Loading...</td></tr>';

                fetch(`admin_action.php?action=fetch_students_list&batch=${batch}&supervisor=${supervisor}&status=${status}&course=${course}&faculty=${faculty}&search=${search}`)
                    .then(response => response.json())
                    .then(data => {
                        allStudentsData = data; 
                        studentsTableBody.innerHTML = '';
                        if (data.length === 0) {
                            studentsTableBody.innerHTML = '<tr><td colspan="8" style="text-align:center;">No students found.</td></tr>';
                            return;
                        }
                        data.forEach(student => {
                            const tr = document.createElement('tr');
                            const statusHtml = student.supervisor_id ?
                                `<span class="status active">Assigned</span>` :
                                `<span class="status pending">Unassigned</span>`;

                            tr.innerHTML = `
                    <td>
                        <input type="checkbox" class="student-checkbox" data-student-id="${student.student_id}">
                    </td>
                    <td>
                        <strong>${student.student_name || 'N/A'}</strong>
                        <div>${student.student_email || 'N/A'}</div>
                    </td>
                    <td>
                        <strong>${student.course_name || 'N/A'}</strong>
                        <div>${student.faculty_name || 'N/A'}</div>
                    </td>
                    <td>${student.batch_year || 'N/A'}</td>
                    <td>${student.project_title || '(No Title)'}</td>
                    <td>${student.supervisor_name || '(Unassigned)'}</td>
                    <td>${statusHtml}</td>
                    <td>
                        <button class="btn small primary" 
                                data-action="edit" 
                                data-student-id="${student.student_id}"
                                title="Edit Assignment">
                            <span class="material-icons">edit</span> Edit
                        </button>
                    </td>
                `;
                            studentsTableBody.appendChild(tr);
                        });
                    })
                    .catch(error => {
                        studentsTableBody.innerHTML = `<tr><td colspan="8" style="text-align:center; color: red;">Error: ${error.message}</td></tr>`;
                        console.error('Fetch error:', error);
                    });
            };

            const renderStudentsTable = (data) => {
                studentsTableBody.innerHTML = '';
                if (data.length === 0) {
                    studentsTableBody.innerHTML = '<tr><td colspan="7" style="text-align:center;">No students found matching criteria.</td></tr>';
                    return;
                }

                data.forEach(student => {
                    const tr = document.createElement('tr');

                    let statusHtml;
                    if (student.supervisor_id) {
                        statusHtml = `<span class="status active">Assigned</span>`;
                    } else {
                        statusHtml = `<span class="status pending">Unassigned</span>`;
                    }

                    const projectTitleText = student.project_title || '(No Title)';
                    const supervisorNameText = student.supervisor_name || '(Unassigned)';

                    tr.innerHTML = `
                <td>
                    <input type="checkbox" class="student-checkbox" data-student-id="${student.student_id}"> 
                </td>
                <td>
                    <strong>${student.student_name || 'N/A'}</strong>
                    <div>${student.student_email || 'N/A'}</div>
                </td>
                <td> 
                    <strong>${student.course_name || 'N/A'}</strong>
                    <div>${student.faculty_name || 'N/A'}</div>
                </td>
                <td>${student.batch_year || 'N/A'}</td>
                <td>${projectTitleText}</td>
                <td>${supervisorNameText}</td>
                <td>${statusHtml}</td>
                <td>
                    <button class="btn small primary" 
                            data-action="edit" 
                            data-student-id="${student.student_id}"
                            title="Edit Assignment">
                        <span class="material-icons">edit</span> Edit
                    </button>
                </td>
            `;
                    studentsTableBody.appendChild(tr);
                });
            };

            const populateSupervisorSelect = (selectElement) => {
                selectElement.innerHTML = '<option value="null">(Remove Supervisor)</option>';
                supervisorsWithLoad.forEach(sup => {
                    const capacity = parseInt(sup.capacity) || 10;
                    const loadInfo = parseInt(sup.load_count) || 0;
                    const isFull = (loadInfo >= capacity);

                    const option = document.createElement('option');
                    option.value = sup.id;
                    option.textContent = `${sup.name} (Load: ${loadInfo} / ${capacity})`;

                    if (isFull) {
                        option.textContent += " [FULL]";
                        option.style.color = "darkred";
                        option.style.fontWeight = "bold";
                    }
                    selectElement.appendChild(option);
                });
            };

            if (!document.getElementById('editProjectTitle')) {
                const titleGroup = document.createElement('div');
                titleGroup.className = 'form-group';
                titleGroup.innerHTML = `
            <label for="editProjectTitle">Project Title</label>
            <input type="text" id="editProjectTitle" name="project_title" placeholder="Enter project title">
        `;
                assignForm.insertBefore(titleGroup, assignForm.firstChild);
            }

            
            projectTitleGroup = document.getElementById('editProjectTitle').closest('.form-group');



            const handleEditClick = (target) => {
                const studentId = target.dataset.studentId;
                if (!studentId) {
                    alert('Error: No Student ID found.');
                    return;
                }

                
                const student = allStudentsData.find(s => s.student_id == studentId);
                if (!student) {
                    alert('Error: Student data not found.');
                    return;
                }

                
                const studentBatch = student.batch_year;

                
                modalTitle.textContent = 'Edit Assignment';
                assigningText.innerHTML = `
                    <div style="margin-bottom: 8px;"><strong>Student:</strong> ${student.student_name}</div>
                    <div style="margin-bottom: 8px;"><strong>Email:</strong> ${student.student_email}</div>
                    <div style="margin-bottom: 8px;"><strong>Batch:</strong> <span style="background-color: #e0e7ff; color: #4338ca; padding: 2px 8px; border-radius: 4px; font-weight: 500;">${studentBatch}</span></div>
                    <div><strong>Course:</strong> ${student.course_name || 'N/A'}</div>
                `;
                assignPayload.value = studentId;

                
                document.getElementById('editProjectTitle').value = student.project_title || '';
                
                
                fetchSupervisors(studentId).then(() => {
                    supervisorSelect.value = student.supervisor_id || 'null';
                    console.log(`Loaded supervisors for student ${studentId} in batch: ${studentBatch}`, supervisorsWithLoad);
                });

                
                assignModal.style.display = 'flex';
            };

            assignForm.addEventListener('submit', (e) => {
                e.preventDefault();

                const payloadValue = assignPayload.value;
                const newTitle = document.getElementById('editProjectTitle').value;
                const newSupervisorId = supervisorSelect.value;

                if (!payloadValue) {
                    alert('Error: No Student ID specified.');
                    return;
                }

                const url = 'admin_action.php?action=update_student_assignment';
                const payload = {
                    student_id: payloadValue,
                    project_title: newTitle,
                    supervisor_id: newSupervisorId
                };

                fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(payload)
                    })
                    .then(res => res.json())
                    .then(response => {
                        if (response.success) {
                            assignModal.style.display = 'none';
                            fetchStudents(); 
                        } else {
                            alert('Failed to update: ' + (response.message || 'Unknown error'));
                        }
                    })
                    .catch(error => {
                        alert('An error occurred: ' + error.message);
                    });
            });

            
            studentsTableBody.addEventListener('click', (e) => {
                const actionButton = e.target.closest('button[data-action]');
                if (actionButton) {
                    const action = actionButton.dataset.action;
                    const studentId = actionButton.dataset.studentId;

                    if (action === 'edit') {
                        handleEditClick(actionButton); 
                    }
                }
            });

            document.querySelectorAll('[data-close-modal]').forEach(btn => {
                btn.addEventListener('click', () => {
                    btn.closest('.modal').style.display = 'none';
                });
            });
            document.querySelectorAll('.modal').forEach(modal => {
                modal.addEventListener('click', (e) => {
                    if (e.target === modal) {
                        modal.style.display = 'none';
                    }
                });
            });

            [courseFilter, facultyFilter, batchFilter, supervisorFilter, statusFilter, searchInput].forEach(el =>
                el.addEventListener('input', fetchStudents)
            );

            function updateSelectionToolbar() {
                if (!bulkActionsToolbar) return;

                const selected = document.querySelectorAll('.student-checkbox:checked');
                if (selected.length > 0) {
                    bulkActionsToolbar.style.display = 'flex';
                    selectionCountSpan.textContent = `${selected.length} student(s) selected`;
                } else {
                    bulkActionsToolbar.style.display = 'none';
                }
                selectAllCheckbox.checked = selected.length > 0 && selected.length === document.querySelectorAll('.student-checkbox').length;
            }

            selectAllCheckbox.addEventListener('change', (e) => {
                document.querySelectorAll('.student-checkbox').forEach(cb => {
                    cb.checked = e.target.checked;
                });
                updateSelectionToolbar();
            });

            studentsTableBody.addEventListener('click', (e) => {
                if (e.target.classList.contains('student-checkbox')) {
                    updateSelectionToolbar();
                }
            });

            bulkAssignBtn.addEventListener('click', () => {
                const selected = document.querySelectorAll('.student-checkbox:checked');
                if (selected.length === 0) {
                    alert('Please select students first.');
                    return;
                }

                const selectedIds = Array.from(selected).map(cb => cb.dataset.studentId);
                const selectedStudents = selectedIds.map(id => allStudentsData.find(s => s.student_id == id));
                
                
                const batches = new Set(selectedStudents.map(s => s.batch_year));
                if (batches.size > 1) {
                    alert('Please select students from the same batch only.');
                    return;
                }

                const studentBatch = selectedStudents[0].batch_year;
                const firstStudentId = selectedStudents[0].student_id;

                projectTitleGroup.style.display = 'none';

                modalTitle.textContent = 'Bulk Assign Supervisor';
                assigningText.innerHTML = `
                    <div style="margin-bottom: 8px;"><strong>Selected Students:</strong> ${selectedIds.length}</div>
                    <div style="margin-bottom: 8px;"><strong>Batch:</strong> <span style="background-color: #e0e7ff; color: #4338ca; padding: 2px 8px; border-radius: 4px; font-weight: 500;">${studentBatch}</span></div>
                    <div style="color: #666; font-size: 0.85rem;">Assigning supervisors to these students from the same batch.</div>
                `;
                assignPayload.value = JSON.stringify(selectedIds);

                
                fetchSupervisors(firstStudentId).then(() => {
                    supervisorSelect.value = 'null';
                    assignModal.style.display = 'flex';
                });
            });


            const capacityBatchFilter = document.getElementById('capacityBatchFilter');
            let supervisorsForCapacity = []; 

            manageCapacityBtn.addEventListener('click', () => {
                capacityBatchFilter.value = 'all'; 
                supervisorsForCapacity = supervisorsWithLoad; 
                renderCapacityList(supervisorsForCapacity);
                capacityModal.style.display = 'flex';
            });

            
            capacityBatchFilter.addEventListener('change', () => {
                const selectedBatch = capacityBatchFilter.value;
                if (selectedBatch === 'all') {
                    renderCapacityList(supervisorsWithLoad);
                } else {
                    
                    fetchSupervisors(selectedBatch).then(() => {
                        renderCapacityList(supervisorsWithLoad);
                    });
                }
            });

            
            const renderCapacityList = (supervisors) => {
                capacityList.innerHTML = '';
                supervisors.forEach(sup => {
                    const li = document.createElement('li');
                    li.innerHTML = `
                <span>${sup.name} (Current Load: ${sup.load_count ?? 0})</span>
                <input type="number" 
                       data-supervisor-id="${sup.id}" 
                       value="${sup.capacity ?? 10}" 
                       min="0" 
                       class="form-input">
            `;
                    capacityList.appendChild(li);
                });
            };

            capacityForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const inputs = capacityList.querySelectorAll('input[data-supervisor-id]');
                const capacities = {};
                inputs.forEach(input => {
                    capacities[input.dataset.supervisorId] = input.value;
                });

                fetch('admin_action.php?action=update_supervisor_capacities', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            capacities: capacities
                        })
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            capacityModal.style.display = 'none';
                            
                            fetchSupervisors().then(fetchStudents);
                        } else {
                            alert('Failed to update capacities: ' + (data.message || 'Unknown error'));
                        }
                    })
                    .catch(error => {
                        alert('An error occurred: ' + error.message);
                    });
            });

            fetchSupervisors().then(fetchStudents);
        });
    </script>
</body>

</html>