<?php
session_start();
if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once '../db_connect.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'fetch_deadlines':
        fetchDeadlines($conn);
        break;
    case 'create_deadline':
        createDeadline($conn);
        break;
    case 'update_deadline':
        updateDeadline($conn);
        break;
    case 'delete_deadline':
        deleteDeadline($conn);
        break;

    case 'fetch_announcements':
        fetchAnnouncements($conn);
        break;
    case 'create_announcement':
        createAnnouncement($conn);
        break;
    case 'update_announcement':
        updateAnnouncement($conn);
        break;
    case 'delete_announcement':
        deleteAnnouncement($conn);
        break;

    case 'get_setting':
        getSetting($conn);
        break;
    case 'update_setting':
        updateSetting($conn);
        break;

    case 'fetch_students_list':
        fetchStudentsList($conn);
        break;
    case 'update_student_assignment':
        updateStudentAssignment($conn);
        break;
    case 'fetch_supervisors_with_load':
        fetchSupervisorsWithLoad($conn);
        break;
    case 'update_supervisor_capacities':
        updateSupervisorCapacities($conn);
        break;
    case 'bulk_assign_supervisor':
        bulkAssignSupervisor($conn);
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

function fetchDeadlines($conn)
{
    $sql = "SELECT id, title, description, due_date, batch_year FROM deadlines ORDER BY due_date DESC";
    $result = $conn->query($sql);
    $deadlines = $result->fetch_all(MYSQLI_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($deadlines);
}
function createDeadline($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $sql = "INSERT INTO deadlines (title, description, due_date, batch_year, created_by) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssi', $data['title'], $data['description'], $data['due_date'], $data['batch_year'], $_SESSION['id']);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to create deadline.']);
    }
}
function updateDeadline($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $sql = "UPDATE deadlines SET title = ?, description = ?, due_date = ?, batch_year = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssi', $data['title'], $data['description'], $data['due_date'], $data['batch_year'], $data['id']);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update deadline.']);
    }
}
function deleteDeadline($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $sql = "DELETE FROM deadlines WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $data['id']);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to delete deadline.']);
    }
}
function fetchAnnouncements($conn)
{
    $sql = "SELECT a.id, a.title, a.content, a.batch_year, a.created_at, u.name as author_name FROM announcements a JOIN users u ON a.created_by = u.id ORDER BY a.created_at DESC";
    $result = $conn->query($sql);
    $announcements = $result->fetch_all(MYSQLI_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($announcements);
}
function createAnnouncement($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $batch_year = $data['batch_year'] ?? null;
    $sql = "INSERT INTO announcements (title, content, batch_year, created_by) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssi', $data['title'], $data['content'], $batch_year, $_SESSION['id']);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to create announcement.']);
    }
}
function updateAnnouncement($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $batch_year = $data['batch_year'] ?? null;
    $sql = "UPDATE announcements SET title = ?, content = ?, batch_year = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssi', $data['title'], $data['content'], $batch_year, $data['id']);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update announcement.']);
    }
}
function deleteAnnouncement($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $sql = "DELETE FROM announcements WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $data['id']);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to delete announcement.']);
    }
}
function getSetting($conn)
{
    $key = $_GET['key'] ?? '';
    if (empty($key)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Setting key not provided.']);
        return;
    }
    $stmt = $conn->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
    $stmt->bind_param('s', $key);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        echo json_encode(['success' => true, 'value' => $row['setting_value']]);
    } else {
        $defaultValue = ($key === 'supervisor_application_enabled') ? '1' : '';
        $conn->query("INSERT INTO system_settings (setting_key, setting_value) VALUES ('$key', '$defaultValue') ON DUPLICATE KEY UPDATE setting_value = setting_value");
        echo json_encode(['success' => true, 'value' => $defaultValue]);
    }
}
function updateSetting($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $key = $data['key'] ?? '';
    $value = $data['value'] ?? '';
    if (empty($key)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Setting key or value not provided.']);
        return;
    }
    $stmt = $conn->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
    $stmt->bind_param('sss', $key, $value, $value);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update setting.']);
    }
}

function fetchStudentsList($conn) {
    header('Content-Type: application/json');

    $batch = $_GET['batch'] ?? 'all';
    $supervisor_id = $_GET['supervisor'] ?? 'all';
    $status_filter = $_GET['status'] ?? 'all';
    $course = $_GET['course'] ?? 'all';
    $faculty = $_GET['faculty'] ?? 'all';
    $search = $_GET['search'] ?? '';

    $sql = "SELECT 
                CAST(s.id AS CHAR) AS student_id, 
                s.name AS student_name, 
                s.email AS student_email,
                COALESCE(g.batch_year, s.batch_year) AS batch_year,
                COALESCE(sp.proposed_title, 'No project title assigned') AS project_title,
                s.supervisor_id,
                sup.name AS supervisor_name,
                c.name AS course_name,
                f.name AS faculty_name
            FROM 
                users s
            LEFT JOIN 
                group_members gm ON s.id = gm.user_id
            LEFT JOIN 
                groups g ON gm.group_id = g.id
            LEFT JOIN 
                student_proposals sp ON s.id = sp.student_id AND sp.status = 'approved'
            LEFT JOIN 
                users sup ON s.supervisor_id = sup.id AND sup.role = 'supervisor'
            LEFT JOIN 
                courses c ON s.course_id = c.id
            LEFT JOIN 
                faculties f ON c.faculty_id = f.id
            WHERE 
                s.role = 'student'";

    $params = [];
    $types = "";

    if ($batch !== 'all') {
        $sql .= " AND COALESCE(g.batch_year, s.batch_year) = ?";
        $params[] = $batch;
        $types .= "s";
    }
    if ($supervisor_id !== 'all') {
        $sql .= " AND s.supervisor_id = ?";
        $params[] = $supervisor_id;
        $types .= "i";
    }
    if ($status_filter === 'assigned') {
        $sql .= " AND s.supervisor_id IS NOT NULL";
    } elseif ($status_filter === 'unassigned') {
        $sql .= " AND s.supervisor_id IS NULL";
    }
    if ($course !== 'all') {
        $sql .= " AND s.course_id = ?";
        $params[] = $course;
        $types .= "i";
    }
    if ($faculty !== 'all') {
        $sql .= " AND f.id = ?";
        $params[] = $faculty;
        $types .= "i";
    }
    if (!empty($search)) {
        $sql .= " AND (s.name LIKE ? OR s.email LIKE ? OR COALESCE(sp.proposed_title, '') LIKE ?)";
        $searchTerm = "%{$search}%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $types .= "sss";
    }

    $sql .= " ORDER BY batch_year DESC, s.name ASC";

    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $students = $result->fetch_all(MYSQLI_ASSOC);

    echo json_encode($students);
}

function updateStudentAssignment($conn)
{
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents('php://input'), true);

    $student_id = $data['student_id'] ?? null;
    $project_title = $data['project_title'] ?? '';
    $supervisor_id = (empty($data['supervisor_id']) || $data['supervisor_id'] === 'null') ? NULL : (int)$data['supervisor_id'];

    if (empty($student_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Student ID is required.']);
        return;
    }

    $stmt_check = $conn->prepare("SELECT supervisor_id FROM users WHERE id = ? AND role = 'student'");
    $stmt_check->bind_param('i', $student_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();
    if ($result->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Student not found.']);
        return;
    }
    $stmt_check->close();

    $conn->begin_transaction();
    try {
        $stmt_get_batch = $conn->prepare("SELECT batch_year FROM users WHERE id = ?");
        if (!$stmt_get_batch) {
            throw new Exception("Prepare failed (get batch): " . $conn->error);
        }
        $stmt_get_batch->bind_param('i', $student_id);
        if (!$stmt_get_batch->execute()) {
            throw new Exception("Execute failed (get batch): " . $stmt_get_batch->error);
        }
        $batch_result = $stmt_get_batch->get_result();
        $batch_row = $batch_result->fetch_assoc();
        $student_batch = $batch_row['batch_year'] ?? null;
        $stmt_get_batch->close();

        $new_group_id = null;
        if ($supervisor_id !== NULL && $student_batch) {
            $stmt_find_group = $conn->prepare("
                SELECT id FROM groups 
                WHERE supervisor_id = ? AND batch_year = ?
                LIMIT 1
            ");
            if (!$stmt_find_group) {
                throw new Exception("Prepare failed (find group): " . $conn->error);
            }
            $stmt_find_group->bind_param('is', $supervisor_id, $student_batch);
            if (!$stmt_find_group->execute()) {
                throw new Exception("Execute failed (find group): " . $stmt_find_group->error);
            }
            $group_result = $stmt_find_group->get_result();
            if ($group_row = $group_result->fetch_assoc()) {
                $new_group_id = $group_row['id'];
            }
            $stmt_find_group->close();
        }

        $stmt_update = $conn->prepare("UPDATE users SET supervisor_id = ?, group_id = ? WHERE id = ?");
        if (!$stmt_update) {
            throw new Exception("Prepare failed (users update): " . $conn->error);
        }
        $stmt_update->bind_param('iii', $supervisor_id, $new_group_id, $student_id);
        if (!$stmt_update->execute()) {
            throw new Exception("Execute failed (users update): " . $stmt_update->error);
        }
        $stmt_update->close();

        // Always update student_proposals with approved status
        $stmt_check_proposal = $conn->prepare("SELECT id FROM student_proposals WHERE student_id = ? LIMIT 1");
        if (!$stmt_check_proposal) {
            throw new Exception("Prepare failed (check proposal): " . $conn->error);
        }
        $stmt_check_proposal->bind_param('i', $student_id);
        if (!$stmt_check_proposal->execute()) {
            throw new Exception("Execute failed (check proposal): " . $stmt_check_proposal->error);
        }
        $proposal_result = $stmt_check_proposal->get_result();
        $stmt_check_proposal->close();

        if ($proposal_result->num_rows > 0) {
            // Update existing proposal with new title (if provided) and set status to approved
            $stmt_update_proposal = $conn->prepare("
                UPDATE student_proposals 
                SET proposed_title = CASE WHEN ? != '' THEN ? ELSE proposed_title END, 
                    status = 'approved'
                WHERE student_id = ?
            ");
            if (!$stmt_update_proposal) {
                throw new Exception("Prepare failed (update proposal): " . $conn->error);
            }
            $stmt_update_proposal->bind_param('ssi', $project_title, $project_title, $student_id);
            if (!$stmt_update_proposal->execute()) {
                throw new Exception("Execute failed (update proposal): " . $stmt_update_proposal->error);
            }
            $stmt_update_proposal->close();
        } else {
            // Create new proposal if not exists, with provided title or empty
            $stmt_insert_proposal = $conn->prepare("
                INSERT INTO student_proposals (student_id, proposed_title, status, proposal_file_path) 
                VALUES (?, ?, 'approved', '')
            ");
            if (!$stmt_insert_proposal) {
                throw new Exception("Prepare failed (insert proposal): " . $conn->error);
            }
            $stmt_insert_proposal->bind_param('is', $student_id, $project_title);
            if (!$stmt_insert_proposal->execute()) {
                throw new Exception("Execute failed (insert proposal): " . $stmt_insert_proposal->error);
            }
            $stmt_insert_proposal->close();
        }

        $stmt_update_students = $conn->prepare("UPDATE students SET supervisor_id = ? WHERE user_id = ?");
        if (!$stmt_update_students) {
            throw new Exception("Prepare failed (students update): " . $conn->error);
        }
        $stmt_update_students->bind_param('ii', $supervisor_id, $student_id);
        if (!$stmt_update_students->execute()) {
            throw new Exception("Execute failed (students update): " . $stmt_update_students->error);
        }
        $stmt_update_students->close();

        if ($supervisor_id !== NULL) {
            $empty_proposal_path = '';
            $status = 'confirmed';
            $stmt_confirm_app = $conn->prepare("
                INSERT INTO supervisor_applications (student_id, supervisor_id, status, project_title, proposal_file_path) 
                VALUES (?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE status = ?
            ");
            if (!$stmt_confirm_app) {
                throw new Exception("Prepare failed (confirm app): " . $conn->error);
            }
            $stmt_confirm_app->bind_param('iissss', $student_id, $supervisor_id, $status, $project_title, $empty_proposal_path, $status);
            if (!$stmt_confirm_app->execute()) {
                throw new Exception("Execute failed (confirm app): " . $stmt_confirm_app->error);
            }
            $stmt_confirm_app->close();

            $stmt_cancel_others = $conn->prepare("
                UPDATE supervisor_applications 
                SET status = 'cancelled'
                WHERE student_id = ? AND supervisor_id != ? AND status = 'pending'
            ");
            if (!$stmt_cancel_others) {
                throw new Exception("Prepare failed (cancel others): " . $conn->error);
            }
            $stmt_cancel_others->bind_param('ii', $student_id, $supervisor_id);
            if (!$stmt_cancel_others->execute()) {
                throw new Exception("Execute failed (cancel others): " . $stmt_cancel_others->error);
            }
            $stmt_cancel_others->close();
        } else {
            $stmt_clear_apps = $conn->prepare("
                UPDATE supervisor_applications 
                SET status = 'rejected'
                WHERE student_id = ? AND status IN ('confirmed', 'pending')
            ");
            if (!$stmt_clear_apps) {
                throw new Exception("Prepare failed (clear apps): " . $conn->error);
            }
            $stmt_clear_apps->bind_param('i', $student_id);
            if (!$stmt_clear_apps->execute()) {
                throw new Exception("Execute failed (clear apps): " . $stmt_clear_apps->error);
            }
            $stmt_clear_apps->close();
        }

        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update assignment: ' . $e->getMessage()]);
    }
}

function fetchSupervisorsWithLoad($conn)
{
    header('Content-Type: application/json');

    $batch_year = $_GET['batch_year'] ?? null;
    $student_id = $_GET['student_id'] ?? null;

    // If student_id is provided, get batch_year from their group
    if ($student_id !== null && $batch_year === null) {
        $stmt = $conn->prepare("SELECT COALESCE(g.batch_year, u.batch_year) as batch_year 
                               FROM users u 
                               LEFT JOIN group_members gm ON u.id = gm.user_id 
                               LEFT JOIN groups g ON gm.group_id = g.id 
                               WHERE u.id = ?");
        $stmt->bind_param('i', $student_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $batch_year = $row['batch_year'];
        }
        $stmt->close();
    }

    if ($batch_year !== null) {
        // When batch_year is specified, show supervisors who have groups in that batch
        $sql = "SELECT 
                    sup.id, 
                    sup.name, 
                    COALESCE(sd.capacity, 10) as capacity,
                    (SELECT COUNT(s.id) 
                     FROM users s 
                     WHERE s.role = 'student' AND s.supervisor_id = sup.id AND s.batch_year = ?) as load_count
                FROM 
                    users sup
                LEFT JOIN 
                    supervisor_details sd ON sup.id = sd.user_id
                WHERE 
                    sup.role = 'supervisor' 
                    AND sup.status = 'active'
                    AND EXISTS (SELECT 1 FROM groups g WHERE g.supervisor_id = sup.id AND g.batch_year = ?)
                ORDER BY sup.name ASC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ss', $batch_year, $batch_year);
    } else {
        $sql = "SELECT 
                    sup.id, 
                    sup.name, 
                    COALESCE(sd.capacity, 10) as capacity,
                    (SELECT COUNT(s.id) 
                     FROM users s 
                     WHERE s.role = 'student' AND s.supervisor_id = sup.id) as load_count
                FROM 
                    users sup
                LEFT JOIN 
                    supervisor_details sd ON sup.id = sd.user_id
                WHERE 
                    sup.role = 'supervisor' 
                    AND sup.status = 'active'
                ORDER BY sup.name ASC";
        
        $stmt = $conn->prepare($sql);
    }

    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
        return;
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $supervisors = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    echo json_encode($supervisors);
}

function updateSupervisorCapacities($conn)
{
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['capacities']) || !is_array($data['capacities'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid input.']);
        return;
    }

    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO supervisor_details (user_id, capacity) VALUES (?, ?) ON DUPLICATE KEY UPDATE capacity = VALUES(capacity)");

        foreach ($data['capacities'] as $supervisor_id => $capacity) {
            $cap_int = intval($capacity);
            $sup_id_int = intval($supervisor_id);
            if ($cap_int < 0) $cap_int = 0;

            $stmt->bind_param('ii', $sup_id_int, $cap_int);
            $stmt->execute();
        }
        $stmt->close();

        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
}

function bulkAssignSupervisor($conn)
{
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents('php://input'), true);

    $student_ids = $data['student_ids'] ?? [];
    $supervisor_id = (empty($data['supervisor_id']) || $data['supervisor_id'] === 'null') ? NULL : (int)$data['supervisor_id'];

    if (empty($student_ids) || !is_array($student_ids)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'No students selected or invalid data.']);
        return;
    }

    $placeholders = implode(',', array_fill(0, count($student_ids), '?'));
    $types = str_repeat('i', count($student_ids));

    if ($supervisor_id === NULL) {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare("UPDATE users SET supervisor_id = NULL, group_id = NULL WHERE id IN ($placeholders) AND role = 'student'");
            $stmt->bind_param($types, ...$student_ids);
            $stmt->execute();
            $stmt->close();

            $stmt_clear_apps = $conn->prepare("
                UPDATE supervisor_applications 
                SET status = 'rejected'
                WHERE student_id IN ($placeholders) AND status = 'confirmed'
            ");
            $stmt_clear_apps->bind_param($types, ...$student_ids);
            $stmt_clear_apps->execute();
            $stmt_clear_apps->close();

            $conn->commit();
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            $conn->rollback();
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Failed to clear assignments.']);
        }
        return;
    }

    $conn->begin_transaction();
    try {
        $capacity = 10;
        $stmt_cap = $conn->prepare("SELECT capacity FROM supervisor_details WHERE user_id = ? FOR UPDATE");
        $stmt_cap->bind_param('i', $supervisor_id);
        $stmt_cap->execute();
        $cap_result = $stmt_cap->get_result();
        if ($cap_row = $cap_result->fetch_assoc()) {
            $capacity = (int)$cap_row['capacity'];
        }
        $stmt_cap->close();

        $stmt_load = $conn->prepare("SELECT COUNT(*) as load_count FROM users WHERE role = 'student' AND supervisor_id = ? FOR UPDATE");
        $stmt_load->bind_param('i', $supervisor_id);
        $stmt_load->execute();
        $current_load = (int)$stmt_load->get_result()->fetch_assoc()['load_count'];
        $stmt_load->close();

        $stmt_check = $conn->prepare("
            SELECT COUNT(id) as new_assign_count 
            FROM users 
            WHERE id IN ($placeholders) 
              AND role = 'student'
              AND (supervisor_id IS NULL OR supervisor_id != ?)
        ");
        $params = [...$student_ids, $supervisor_id];
        $check_types = $types . 'i';
        $stmt_check->bind_param($check_types, ...$params);
        $stmt_check->execute();
        $num_to_assign = (int)$stmt_check->get_result()->fetch_assoc()['new_assign_count'];
        $stmt_check->close();

        $available_slots = $capacity - $current_load;
        if ($num_to_assign > $available_slots) {
            throw new Exception("Capacity exceeded. Supervisor has $available_slots slot(s) free, but you tried to assign $num_to_assign new student(s).");
        }

        foreach ($student_ids as $student_id) {
            $stmt_get_batch = $conn->prepare("SELECT batch_year FROM users WHERE id = ?");
            $stmt_get_batch->bind_param('i', $student_id);
            $stmt_get_batch->execute();
            $batch_result = $stmt_get_batch->get_result();
            $batch_row = $batch_result->fetch_assoc();
            $student_batch = $batch_row['batch_year'] ?? null;
            $stmt_get_batch->close();

            $new_group_id = null;
            if ($student_batch) {
                $stmt_find_group = $conn->prepare("
                    SELECT id FROM groups 
                    WHERE supervisor_id = ? AND batch_year = ?
                    LIMIT 1
                ");
                $stmt_find_group->bind_param('is', $supervisor_id, $student_batch);
                $stmt_find_group->execute();
                $group_result = $stmt_find_group->get_result();
                if ($group_row = $group_result->fetch_assoc()) {
                    $new_group_id = $group_row['id'];
                }
                $stmt_find_group->close();
            }

            $stmt_update_single = $conn->prepare("UPDATE users SET supervisor_id = ?, group_id = ? WHERE id = ? AND role = 'student'");
            $stmt_update_single->bind_param('iii', $supervisor_id, $new_group_id, $student_id);
            if (!$stmt_update_single->execute()) {
                throw new Exception("Failed to update student $student_id: " . $stmt_update_single->error);
            }
            $stmt_update_single->close();
        }

        $empty_str = '';
        $status = 'confirmed';
        $stmt_confirm_app = $conn->prepare("
            INSERT INTO supervisor_applications (student_id, supervisor_id, status, project_title, proposal_file_path) 
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE status = ?
        ");

        $stmt_cancel_others = $conn->prepare("
            UPDATE supervisor_applications 
            SET status = 'cancelled'
            WHERE student_id = ? 
              AND supervisor_id != ? 
              AND status = 'pending'
        ");

        foreach ($student_ids as $student_id) {
            $stmt_confirm_app->bind_param('iissss', $student_id, $supervisor_id, $status, $empty_str, $empty_str, $status);
            if (!$stmt_confirm_app->execute()) {
                throw new Exception("Failed to confirm app: " . $stmt_confirm_app->error);
            }

            $stmt_cancel_others->bind_param('ii', $student_id, $supervisor_id);
            if (!$stmt_cancel_others->execute()) {
                throw new Exception("Failed to cancel others: " . $stmt_cancel_others->error);
            }
        }
        $stmt_confirm_app->close();
        $stmt_cancel_others->close();

        $conn->commit();
        echo json_encode(['success' => true]);
    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(409);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

$conn->close();
