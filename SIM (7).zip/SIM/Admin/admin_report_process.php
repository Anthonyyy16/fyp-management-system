<?php

session_start();
if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once '../db_connect.php';

$action = $_GET['action'] ?? '';

switch ($action) {

    case 'fetch_report_data':
        fetchReportData($conn);
        break;

    case 'fetch_supervisor_load_by_batch':
        fetchSupervisorLoadByBatch($conn);
        break;

    case 'fetch_deadline_workload_analysis':
        fetchDeadlineWorkloadAnalysis($conn);
        break;

    case 'get_batch_list':
        getBatchList($conn);
        break;

    case 'generate_pdf_report':
        generatePDFReport($conn);
        break;

    default:
        // ... http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;

       
}


function fetchReportData($conn) {
    header('Content-Type: application/json');
    $report_data = [];

    $report_data['stats'] = [
        'students' => $conn->query("SELECT COUNT(id) as total FROM users WHERE role = 'student' AND status = 'active'")->fetch_assoc()['total'],
        'supervisors' => $conn->query("SELECT COUNT(id) as total FROM users WHERE role = 'supervisor' AND status = 'active'")->fetch_assoc()['total'],
        'assigned' => $conn->query("SELECT COUNT(id) as total FROM users WHERE role = 'student' AND status = 'active' AND supervisor_id IS NOT NULL")->fetch_assoc()['total'],
        'pending_apps' => $conn->query("SELECT COUNT(id) as total FROM supervisor_applications WHERE status = 'pending'")->fetch_assoc()['total']
    ];

    $supervisor_load_sql = "
        SELECT 
            sup.id, 
            sup.name, 
            COALESCE(sd.capacity, 10) as capacity, -- (使用 COALESCE 确保有默认值 10)
            (SELECT COUNT(s.id) 
             FROM users s 
             WHERE s.role = 'student' AND s.supervisor_id = sup.id) as load_count
        FROM 
            users sup
        LEFT JOIN 
            supervisor_details sd ON sup.id = sd.user_id
        WHERE 
            sup.role = 'supervisor' 
            AND sup.status = 'active'
        ORDER BY 
            sup.name ASC";
    $supervisor_load_result = $conn->query($supervisor_load_sql);
    $report_data['supervisor_load'] = $supervisor_load_result->fetch_all(MYSQLI_ASSOC);

    $batch_stats_sql = "
        SELECT 
            batch_year, 
            COUNT(id) as total_students,
            SUM(CASE WHEN supervisor_id IS NOT NULL THEN 1 ELSE 0 END) as total_assigned
        FROM 
            users 
        WHERE 
            role = 'student' AND status = 'active' AND batch_year IS NOT NULL
        GROUP BY 
            batch_year
        ORDER BY 
            batch_year DESC";
    $batch_stats_result = $conn->query($batch_stats_sql);
    $report_data['batch_stats'] = $batch_stats_result->fetch_all(MYSQLI_ASSOC);

    $recent_apps_sql = "
        SELECT 
            sa.status, sa.updated_at,
            s.name as student_name,
            sup.name as supervisor_name
        FROM 
            supervisor_applications sa
        JOIN 
            users s ON sa.student_id = s.id
        JOIN 
            users sup ON sa.supervisor_id = sup.id
        ORDER BY 
            sa.updated_at DESC
        LIMIT 10"; 
    $recent_apps_result = $conn->query($recent_apps_sql);
    $report_data['recent_apps'] = $recent_apps_result->fetch_all(MYSQLI_ASSOC);

    
    echo json_encode($report_data);
}

function fetchSupervisorLoadByBatch($conn) {
    header('Content-Type: application/json');
    
    $batch = $_GET['batch'] ?? 'all';
    
    if ($batch === 'all') {
        $sql = "
            SELECT 
                sup.id, 
                sup.name, 
                COALESCE(sd.capacity, 10) as capacity,
                (SELECT COUNT(s.id) 
                 FROM users s 
                 WHERE s.role = 'student' AND s.supervisor_id = sup.id) as load_count
            FROM 
                users sup
            LEFT JOIN 
                supervisor_details sd ON sup.id = sd.user_id
            WHERE 
                sup.role = 'supervisor' 
                AND sup.status = 'active'
            ORDER BY 
                sup.name ASC";
    } else {
        $batch = $conn->real_escape_string($batch);
        $sql = "
            SELECT 
                sup.id, 
                sup.name, 
                COALESCE(sd.capacity, 10) as capacity,
                (SELECT COUNT(s.id) 
                 FROM users s 
                 WHERE s.role = 'student' AND s.supervisor_id = sup.id AND s.batch_year = '$batch') as load_count
            FROM 
                users sup
            LEFT JOIN 
                supervisor_details sd ON sup.id = sd.user_id
            WHERE 
                sup.role = 'supervisor' 
                AND sup.status = 'active'
            ORDER BY 
                sup.name ASC";
    }
    
    $result = $conn->query($sql);
    $data = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['success' => true, 'data' => $data]);
}

function getBatchList($conn) {
    header('Content-Type: application/json');
    
    $sql = "
        SELECT DISTINCT batch_year 
        FROM users 
        WHERE role = 'student' AND status = 'active' AND batch_year IS NOT NULL
        ORDER BY batch_year DESC";
    
    $result = $conn->query($sql);
    $batches = $result->fetch_all(MYSQLI_ASSOC);
    
    echo json_encode(['success' => true, 'batches' => $batches]);
}

function fetchDeadlineWorkloadAnalysis($conn) {
    header('Content-Type: application/json');
    
    $batch = $_GET['batch'] ?? 'all';
    
    
    if ($batch === 'all') {
        $sql = "
            SELECT 
                d.id as deadline_id,
                d.title as deadline_title,
                DATE(d.due_date) as deadline_date,
                d.batch_year,
                COUNT(DISTINCT s.id) as total_students_affected,
                COUNT(DISTINCT sup.id) as supervisors_affected,
                GROUP_CONCAT(DISTINCT sup.name SEPARATOR ', ') as supervisor_names,
                SUM(CASE WHEN s.supervisor_id IS NOT NULL THEN 1 ELSE 0 END) as assigned_students
            FROM 
                deadlines d
            LEFT JOIN 
                users s ON (s.batch_year = d.batch_year AND s.role = 'student' AND s.status = 'active')
            LEFT JOIN 
                users sup ON (s.supervisor_id = sup.id AND sup.role = 'supervisor')
            WHERE 
                DATE(d.due_date) >= CURDATE()
            GROUP BY 
                d.id, d.title, DATE(d.due_date), d.batch_year
            ORDER BY 
                DATE(d.due_date) ASC
            LIMIT 15";
    } else {
        $batch = $conn->real_escape_string($batch);
        $sql = "
            SELECT 
                d.id as deadline_id,
                d.title as deadline_title,
                DATE(d.due_date) as deadline_date,
                d.batch_year,
                COUNT(DISTINCT s.id) as total_students_affected,
                COUNT(DISTINCT sup.id) as supervisors_affected,
                GROUP_CONCAT(DISTINCT sup.name SEPARATOR ', ') as supervisor_names,
                SUM(CASE WHEN s.supervisor_id IS NOT NULL THEN 1 ELSE 0 END) as assigned_students
            FROM 
                deadlines d
            LEFT JOIN 
                users s ON (s.batch_year = d.batch_year AND s.role = 'student' AND s.status = 'active')
            LEFT JOIN 
                users sup ON (s.supervisor_id = sup.id AND sup.role = 'supervisor')
            WHERE 
                d.batch_year = '$batch'
                AND DATE(d.due_date) >= CURDATE()
            GROUP BY 
                d.id, d.title, DATE(d.due_date), d.batch_year
            ORDER BY 
                DATE(d.due_date) ASC
            LIMIT 15";
    }
    
    $result = $conn->query($sql);
    if (!$result) {
        echo json_encode(['success' => true, 'deadlines' => [], 'supervisors' => []]);
        return;
    }
    
    $deadlines = $result->fetch_all(MYSQLI_ASSOC) ?? [];
    
    
    $sup_sql = "
        SELECT 
            sup.id,
            sup.name,
            COUNT(DISTINCT s.id) as student_count,
            COUNT(DISTINCT d.id) as active_deadline_count,
            COALESCE(sd.capacity, 10) as capacity
        FROM 
            users sup
        LEFT JOIN 
            users s ON (s.supervisor_id = sup.id AND s.role = 'student' AND s.status = 'active')
        LEFT JOIN 
            deadlines d ON (s.batch_year = d.batch_year AND DATE(d.due_date) >= CURDATE())
        LEFT JOIN 
            supervisor_details sd ON sup.id = sd.user_id
        WHERE 
            sup.role = 'supervisor' AND sup.status = 'active'
        GROUP BY 
            sup.id, sup.name, sd.capacity
        ORDER BY 
            student_count DESC";
    
    $sup_result = $conn->query($sup_sql);
    $supervisors = $sup_result ? $sup_result->fetch_all(MYSQLI_ASSOC) : [];
    
    echo json_encode([
        'success' => true,
        'deadlines' => $deadlines,
        'supervisors' => $supervisors
    ]);
}

function generatePDFReport($conn) {
    $batch = $_GET['batch'] ?? 'all';
    
    
    if ($batch === 'all') {
        $total_sql = "SELECT COUNT(id) as total FROM users WHERE role = 'student' AND status = 'active'";
        $assigned_sql = "SELECT COUNT(id) as total FROM users WHERE role = 'student' AND status = 'active' AND supervisor_id IS NOT NULL";
        $sup_where = "";
    } else {
        $batch_esc = $conn->real_escape_string($batch);
        $total_sql = "SELECT COUNT(id) as total FROM users WHERE role = 'student' AND status = 'active' AND batch_year = '$batch_esc'";
        $assigned_sql = "SELECT COUNT(id) as total FROM users WHERE role = 'student' AND status = 'active' AND supervisor_id IS NOT NULL AND batch_year = '$batch_esc'";
        $sup_where = "AND s.batch_year = '$batch_esc'";
    }
    
    $total_students = $conn->query($total_sql)->fetch_assoc()['total'];
    $assigned = $conn->query($assigned_sql)->fetch_assoc()['total'];
    $completion_rate = $total_students > 0 ? round(($assigned / $total_students) * 100, 1) : 0;
    
    
    $html = '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background: white; color: #333; }
            h1 { color: #1E3A8A; border-bottom: 3px solid #1E3A8A; padding-bottom: 10px; margin-top: 30px; }
            h2 { color: #1E3A8A; margin-top: 30px; margin-bottom: 15px; font-size: 18px; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; page-break-inside: avoid; }
            th { background-color: #1E3A8A; color: white; padding: 12px; text-align: left; font-weight: bold; }
            td { padding: 10px; border-bottom: 1px solid #ddd; }
            tr:nth-child(even) { background-color: #f9f9f9; }
            .stat-box { background-color: #f5f5f5; padding: 15px; margin: 10px 0; border-left: 4px solid #1E3A8A; }
            .stat-box strong { color: #1E3A8A; }
            .footer { margin-top: 40px; color: #999; font-size: 12px; border-top: 1px solid #ddd; padding-top: 20px; }
            .section-title { background-color: #e8eef7; padding: 10px; margin-top: 20px; font-weight: bold; color: #1E3A8A; }
            .highlight { background-color: #fff3cd; }
            .popular { color: #10B981; font-weight: bold; }
        </style>
    </head>
    <body>
        <h1>Final Year Project - Allocation Report</h1>
        <p><strong>Generated:</strong> ' . date('Y-m-d H:i:s') . '</p>
        <p><strong>Report Type:</strong> ' . ($batch === 'all' ? 'All Batches' : 'Batch: ' . htmlspecialchars($batch)) . '</p>
        
        <div class="stat-box">
            <strong>Total Students:</strong> ' . $total_students . '<br>
            <strong>Assigned Students:</strong> ' . $assigned . '<br>
            <strong>Completion Rate:</strong> ' . $completion_rate . '%
        </div>
    ';
    
    
    $sup_sql = "
        SELECT 
            sup.id,
            sup.name, 
            COALESCE(sd.capacity, 10) as capacity,
            (SELECT COUNT(s.id) FROM users s WHERE s.role = 'student' AND s.supervisor_id = sup.id $sup_where) as load_count
        FROM 
            users sup
        LEFT JOIN 
            supervisor_details sd ON sup.id = sd.user_id
        WHERE 
            sup.role = 'supervisor' AND sup.status = 'active'
        ORDER BY 
            load_count DESC";
    
    $sup_result = $conn->query($sup_sql);
    $supervisors = $sup_result ? $sup_result->fetch_all(MYSQLI_ASSOC) : [];
    
    if ($supervisors) {
        $html .= '<h2>Supervisor Load & Capacity Analysis</h2>
        <table>
            <tr>
                <th>Supervisor Name</th>
                <th>Capacity</th>
                <th>Current Load</th>
                <th>Available</th>
                <th>Utilization %</th>
            </tr>';
        
        $max_load = max(array_column($supervisors, 'load_count'));
        
        foreach ($supervisors as $sup) {
            $capacity = $sup['capacity'];
            $load = $sup['load_count'];
            $available = $capacity - $load;
            $util = $capacity > 0 ? round(($load / $capacity) * 100, 1) : 0;
            $is_popular = $load == $max_load && $max_load > 0 ? ' style="background-color: #fff3cd;"' : '';
            
            $html .= '<tr' . $is_popular . '>
                <td><strong>' . htmlspecialchars($sup['name']) . '</strong>' . ($load == $max_load && $max_load > 0 ? ' ⭐ (Most Popular)' : '') . '</td>
                <td>' . $capacity . '</td>
                <td>' . $load . '</td>
                <td>' . $available . '</td>
                <td>' . $util . '%</td>
            </tr>';
        }
        
        $html .= '</table>';
        
        
        if ($max_load > 0) {
            $html .= '<div class="stat-box">
                <strong>⭐ Most Popular Supervisors Analysis:</strong><br>';
            
            foreach ($supervisors as $sup) {
                if ($sup['load_count'] == $max_load) {
                    $html .= '• <span style="color: #10B981; font-weight: bold;">' . htmlspecialchars($sup['name']) . '</span> - ' . $sup['load_count'] . ' students assigned, ' . round(($sup['load_count'] / $sup['capacity']) * 100) . '% utilization<br>';
                }
            }
            
            $html .= '</div>';
        }
    }
    
    
    if ($batch === 'all') {
        $deadline_sql = "
            SELECT 
                d.title, DATE(d.due_date) as deadline_date, d.batch_year,
                COUNT(DISTINCT s.id) as student_count
            FROM 
                deadlines d
            LEFT JOIN 
                users s ON s.batch_year = d.batch_year AND s.role = 'student' AND s.status = 'active'
            WHERE 
                DATE(d.due_date) >= CURDATE()
            GROUP BY 
                d.id, d.title, DATE(d.due_date), d.batch_year
            ORDER BY 
                DATE(d.due_date) ASC
            LIMIT 10";
    } else {
        $deadline_sql = "
            SELECT 
                d.title, DATE(d.due_date) as deadline_date, d.batch_year,
                COUNT(DISTINCT s.id) as student_count
            FROM 
                deadlines d
            LEFT JOIN 
                users s ON s.batch_year = d.batch_year AND s.role = 'student' AND s.status = 'active'
            WHERE 
                d.batch_year = '$batch_esc'
                AND DATE(d.due_date) >= CURDATE()
            GROUP BY 
                d.id, d.title, DATE(d.due_date), d.batch_year
            ORDER BY 
                DATE(d.due_date) ASC
            LIMIT 10";
    }
    
    $deadline_result = $conn->query($deadline_sql);
    $deadlines = $deadline_result ? $deadline_result->fetch_all(MYSQLI_ASSOC) : [];
    
    if ($deadlines) {
        $html .= '<h2>Upcoming Deadlines</h2>
        <table>
            <tr>
                <th>Deadline Date</th>
                <th>Title</th>
                <th>Batch</th>
                <th>Students Affected</th>
            </tr>';
        
        foreach ($deadlines as $dl) {
            $html .= '<tr>
                <td>' . htmlspecialchars($dl['deadline_date']) . '</td>
                <td>' . htmlspecialchars($dl['title']) . '</td>
                <td>' . htmlspecialchars($dl['batch_year']) . '</td>
                <td>' . $dl['student_count'] . '</td>
            </tr>';
        }
        
        $html .= '</table>';
    }
    
    $html .= '<div class="footer"><p>This report is confidential and for authorized personnel only.</p></div></body></html>';
    
    
    header('Content-Type: text/html; charset=utf-8');
    header('Content-Disposition: attachment; filename="FYP_Report_' . date('Y-m-d_His') . '.html"');
    echo $html;
}


?>
 