<?php

session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once '../db_connect.php';

// autoloader for PhpSpreadsheet and other libraries
// ------------------------------------------------------------------
spl_autoload_register(function ($class) {
    // define namespace prefixes and their base directories
    $prefixes = [
        'PhpOffice\\PhpSpreadsheet\\' => __DIR__ . '/../lib/PhpSpreadsheet/src/PhpSpreadsheet/',
        'Psr\\SimpleCache\\'        => __DIR__ . '/../lib/SimpleCache/src/', // New: Path for SimpleCache library
    ];

    // iterate through the prefixes to find a match
    foreach ($prefixes as $prefix => $base_dir) {
        // check if the class uses the namespace prefix
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            // If not, skip and continue to the next prefix
            continue;
        }
        // get the relative class name
        $relative_class = substr($class, $len);

        // replace namespace separators with directory separators, append with .php
        $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

       // if the file exists, require it
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
});
// ------------------------------------------------------------------

// import necessary classes from PhpSpreadsheet
use PhpOffice\PhpSpreadsheet\IOFactory;

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'fetch':
        fetchUsers($conn);
        break;
    case 'fetch_one':
        fetchSingleUser($conn);
        break;
    case 'create':
        createUser($conn);
        break;
    case 'update':
        updateUser($conn);
        break;
    case 'toggle_status':
        toggleUserStatus($conn);
        break;
    case 'bulk_toggle_status':
        bulkToggleStatus($conn);
        break;
    case 'bulk_delete':
        bulkDelete($conn);
        break;
    case 'import_excel':
        importFromExcel($conn);
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}



// Fetch a list of users with optional filters (batch, role, search).
// Returns JSON array of users with fields: id, name, email, role, batch_year, status.
function fetchUsers($conn) {
    $batch = $_GET['batch'] ?? 'all';
    $role = $_GET['role'] ?? 'all';
    $status = $_GET['status'] ?? 'all';
    $course = $_GET['course'] ?? 'all';
    $faculty = $_GET['faculty'] ?? 'all';
    $search = $_GET['search'] ?? '';
    

    $sql = "SELECT 
            u.id, u.name, u.email, u.role, u.batch_year, u.status, u.course_id,
            c.name AS course_name,
            f.name AS faculty_name
        FROM 
            users u
       LEFT JOIN 
            courses c ON u.course_id = c.id
       LEFT JOIN
            faculties f ON c.faculty_id = f.id
        WHERE 
            1=1";
    $params = [];
    $types = '';
    if ($batch !== 'all') {
        $sql .= " AND batch_year = ?";
        $params[] = $batch;
        $types .= 's';
    }
    if ($role !== 'all') {
        $sql .= " AND role = ?";
        $params[] = $role;
        $types .= 's';
    }
    if (!empty($search)) {
        $sql .= " AND (name LIKE ? OR email LIKE ?)";
        $searchTerm = "%{$search}%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $types .= 'ss';
    }
    if ($status !== 'all') {
        $sql .= " AND status = ?";
        $params[] = $status;
        $types .= 's';
    }

if ($course !== 'all') {
    $sql .= " AND u.course_id = ?";
    $params[] = $course;
    $types .= 'i';
}
if ($faculty !== 'all') {
    $sql .= " AND f.id = ?";
    $params[] = $faculty;
    $types .= 'i';
}
    $sql .= " ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    if (!empty($params)) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $users = $result->fetch_all(MYSQLI_ASSOC);
    header('Content-Type: application/json');
    echo json_encode($users);
}

// Fetch a single user's details by ID.
// Returns JSON object with fields: id, name, email, role, batch_year.
function fetchSingleUser($conn) {
    $id = $_GET['id'] ?? 0;

$stmt = $conn->prepare("SELECT id, name, email, role, batch_year, course_id, 
                        (SELECT faculty_id FROM courses WHERE id = course_id) AS faculty_id 
                        FROM users WHERE id = ?");    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    header('Content-Type: application/json');
    echo json_encode($user);
}

// Create a new user from JSON request body.
// Expects: name, email, password, role, batch_year. Password is hashed before insert.
function createUser($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
$stmt = $conn->prepare("INSERT INTO users (name, email, password, role, batch_year, course_id) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param('sssssi', $data['name'], $data['email'], $hashed_password, $data['role'], $data['batch_year'], $data['course']);    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to create user. Email might already exist.']);
    }
}

// Update an existing user from JSON request body.
// If password is provided it will be hashed and updated; otherwise password is left unchanged.
function updateUser($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'];
    if (!empty($data['password'])) {
        $hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, role = ?, batch_year = ?, password = ? WHERE id = ?");
        $stmt->bind_param('sssssi', $data['name'], $data['email'], $data['role'], $data['batch_year'], $hashed_password, $id);
    } else {
$stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, role = ?, batch_year = ?, course_id = ? WHERE id = ?");
$stmt->bind_param('ssssii', $data['name'], $data['email'], $data['role'], $data['batch_year'], $data['course'], $id);    }
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update user.']);
    }
}

// Toggle a single user's status between 'active' and 'inactive'.
// Expects JSON body with id and current status; returns new_status.
function toggleUserStatus($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'];
    $current_status = $data['status'];
    $new_status = ($current_status === 'active') ? 'inactive' : 'active';
    $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id = ?");
    $stmt->bind_param('si', $new_status, $id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'new_status' => $new_status]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update status.']);
    }
}

// Bulk update status for multiple users.
// Expects JSON body with ids (array) and status ('active' or 'inactive').
function bulkToggleStatus($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    $ids = $data['ids'] ?? [];
    $new_status = $data['status'] ?? 'inactive';
    if (empty($ids) || !in_array($new_status, ['active', 'inactive'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid data provided.']);
        return;
    }
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    $stmt = $conn->prepare("UPDATE users SET status = ? WHERE id IN ($placeholders)");
    $stmt->bind_param("s" . $types, $new_status, ...$ids);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update statuses.']);
    }
}

// Bulk delete users by IDs.
// Expects JSON body with ids (array). Returns success or error.
function bulkDelete($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    $ids = $data['ids'] ?? [];
    if (empty($ids)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'No user IDs provided.']);
        return;
    }
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids));
    $stmt = $conn->prepare("DELETE FROM users WHERE id IN ($placeholders)");
    $stmt->bind_param($types, ...$ids);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to delete users. They might be linked to other data.']);
    }
}

// Import users from an uploaded Excel file (multipart form upload with 'excelFile').
// Reads rows starting at row 2 and inserts/updates users with fields: name(A), email(B), role(C), password(D), faculty(E), course(F).
// Returns JSON summary with imported, updated and failed counts and any row errors.
function importFromExcel($conn) {
    if (isset($_FILES['excelFile'])) {
        $file = $_FILES['excelFile']['tmp_name'];
        try {
            $spreadsheet = IOFactory::load($file);
            $sheet = $spreadsheet->getActiveSheet();
            $highestRow = $sheet->getHighestRow();
            $importedCount = 0;
            $updatedCount = 0;
            $failedCount = 0;
            $errors = [];
            
            // Prepare statements for insert and update
            $stmt_insert = $conn->prepare("INSERT INTO users (name, email, role, password, course_id) VALUES (?, ?, ?, ?, ?)");
            $stmt_update = $conn->prepare("UPDATE users SET role = ?, course_id = ? WHERE email = ?");
            $stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ?");
            
            for ($row = 2; $row <= $highestRow; $row++) {
                $name = $sheet->getCell('A' . $row)->getValue();
                $email = $sheet->getCell('B' . $row)->getValue();
                $role = strtolower($sheet->getCell('C' . $row)->getValue());
                $password = $sheet->getCell('D' . $row)->getValue();
                $faculty_name = trim($sheet->getCell('E' . $row)->getValue());
                $course_name = trim($sheet->getCell('F' . $row)->getValue());
                
                // Check if email is empty (end of data)
                if (empty($email)) {
                    break;
                }
                
                if (empty($name) || empty($role)) {
                    $failedCount++;
                    $errors[] = "Row $row: Skipped due to missing name or role.";
                    continue;
                }
                
                // Get course_id from faculty and course names
                $course_id = null;
                if (!empty($faculty_name) && !empty($course_name)) {
                    $sql_get_course = "SELECT c.id FROM courses c 
                                      JOIN faculties f ON c.faculty_id = f.id 
                                      WHERE f.name = ? AND c.name = ?";
                    $stmt_get_course = $conn->prepare($sql_get_course);
                    if ($stmt_get_course) {
                        $stmt_get_course->bind_param('ss', $faculty_name, $course_name);
                        $stmt_get_course->execute();
                        $result = $stmt_get_course->get_result();
                        if ($result->num_rows > 0) {
                            $course_row = $result->fetch_assoc();
                            $course_id = $course_row['id'];
                        } else {
                            $errors[] = "Row $row: Faculty '$faculty_name' or Course '$course_name' not found.";
                            $failedCount++;
                            $stmt_get_course->close();
                            continue;
                        }
                        $stmt_get_course->close();
                    }
                }
                
                // Check if user exists
                $stmt_check->bind_param('s', $email);
                $stmt_check->execute();
                $check_result = $stmt_check->get_result();
                
                if ($check_result->num_rows > 0) {
                    // User exists - update
                    $stmt_update->bind_param('sis', $role, $course_id, $email);
                    if ($stmt_update->execute()) {
                        $updatedCount++;
                    } else {
                        $failedCount++;
                        $errors[] = "Row $row: Failed to update user with email '$email'.";
                    }
                } else {
                    // User doesn't exist - insert
                    if (empty($password)) {
                        $failedCount++;
                        $errors[] = "Row $row: Password is required for new users.";
                        continue;
                    }
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt_insert->bind_param('ssssi', $name, $email, $role, $hashed_password, $course_id);
                    if ($stmt_insert->execute()) {
                        $importedCount++;
                    } else {
                        $failedCount++;
                        $errors[] = "Row $row: Failed to insert user with email '$email' (might already exist).";
                    }
                }
            }
            
            $stmt_insert->close();
            $stmt_update->close();
            $stmt_check->close();
            
            echo json_encode([
                'success' => true, 
                'message' => "Import complete. $importedCount users added, $updatedCount users updated, $failedCount failed.",
                'errors' => $errors
            ]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Error processing file: ' . $e->getMessage()]);
        }
    } else {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'No file uploaded.']);
    }
}

$conn->close();
?>

