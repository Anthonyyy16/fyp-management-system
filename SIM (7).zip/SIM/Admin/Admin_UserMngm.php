<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}
require_once '../db_connect.php';

// get distinct batch years for filter dropdown
$batch_years = [];
$result = $conn->query("SELECT DISTINCT batch_year FROM users WHERE batch_year IS NOT NULL AND batch_year != '' ORDER BY batch_year DESC");
while ($row = $result->fetch_assoc()) {
    $batch_years[] = $row['batch_year'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Admin</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="../index.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<body>
    <div class="navbar">
        <h2>Admin Panel - User Management</h2>
        <div class="button-group">
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>

    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Admin Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="Admin_Dashboard.php"><span class="material-icons">dashboard</span> Dashboard</a></li>
                <li class="active"><a href="Admin_UserMngm.php"><span class="material-icons">people</span> User Management</a></li>
                <li><a href="Admin_Announcements.php"><span class="material-icons">campaign</span>Announcements</a></li>
                <li><a href="Admin_Deadline.php"><span class="material-icons">event</span>Global Deadlines</a></li>
                <li><a href="Admin_Allocation.php"><span class="material-icons">assignment_ind</span>Project Allocation</a></li>
                <li><a href="Admin_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <!-- <li><a href="Admin_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li> -->
                <li ><a href="Admin_Batch.php"><span class="material-icons">school</span>Batch Management</a></li>
                <li><a href="Admin_Report.php"><span class="material-icons">bar_chart</span>Reports</a></li>
                <li><a href="Admin_System.php"><span class="material-icons">settings</span>System Settings</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="content-header">
                <h1>Manage All Users</h1>
                <p>Add, edit, and manage all users in the system from here.</p>
            </div>

            <!-- Filters and Actions Card -->
            <div class="card actions">
                <div class="filters">
                    <select id="batchFilter" class="filter-select">
                        <option value="all">All Batches</option>
                        <?php foreach ($batch_years as $year): ?>
                            <option value="<?php echo htmlspecialchars($year); ?>"><?php echo htmlspecialchars($year); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select id="roleFilter" class="filter-select">
                        <option value="all">All Roles</option>
                        <option value="student">Student</option>
                        <option value="supervisor">Supervisor</option>
                        <option value="committee">Committee</option>
                        <option value="admin">Admin</option>
                    </select>
                    <select id="statusFilter" class="filter-select">
                        <option value="all">All Statuses</option>
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                    <select id="courseFilter" class="filter-select">
                        <option value="all">All Courses</option>
                        <?php $course_result = $conn->query("SELECT id, name FROM courses ORDER BY name ASC");
                        while ($course = $course_result->fetch_assoc()): ?>
                            <option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['name']); ?></option>
                        <?php endwhile; ?>
                    </select>
                    <select id="facultyFilter" class="filter-select">
                        <option value="all">All Faculties</option>
                        <?php $faculty_result = $conn->query("SELECT id, name FROM faculties ORDER BY name ASC");
                        while ($faculty = $faculty_result->fetch_assoc()): ?>
                            <option value="<?php echo $faculty['id']; ?>"><?php echo htmlspecialchars($faculty['name']); ?></option>
                        <?php endwhile; ?>
                    </select>

                    <input type="text" id="search" placeholder="Search by name or email...">
                </div>
                <div class="action-buttons">
                    <button id="importBtn" class="btn secondary"><span class="material-icons">upload_file</span> Import from Excel</button>
                    <button id="addUserBtn" class="btn primary"><span class="material-icons">add</span> Add New User</button>
                </div>
            </div>

            <!-- Bulk Actions Toolbar (Initially hidden) -->
            <div id="bulkActionsToolbar" class="bulk-actions-toolbar card" style="display: none;">
                <span id="selectionCount">0 users selected</span>
                <div class="bulk-buttons">
                    <button id="bulkActivateBtn" class="btn success">Activate</button>
                    <button id="bulkDeactivateBtn" class="btn secondary">Deactivate</button>
                    <button id="bulkDeleteBtn" class="btn danger">Delete</button>
                </div>
            </div>

            <!-- User Data Table Card -->
            <div class="card">
                <div class="data-table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th><input type="checkbox" id="selectAllCheckbox"></th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Faculty</th>
                                <th>Role</th>
                                <th>Batch</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="userTableBody">

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit User Modal -->
    <div class="modal" id="userModal" style="display: none;">
        <div class="modal-content">
            <h3 id="modalTitle">Add New User</h3>
            <form id="userForm">
                <input type="hidden" id="userId" name="id">
                <div class="form-group"><label for="name">Full Name</label><input type="text" id="name" name="name" required></div>
                <div class="form-group"><label for="email">Email</label><input type="email" id="email" name="email" required></div>
                <div class="form-group"><label for="role">Role</label><select id="role" name="role" required>
                        <option value="student">Student</option>
                        <option value="supervisor">Supervisor</option>
                        <option value="committee">Committee</option>
                        <option value="admin">Admin</option>
                    </select></div>
                <div class="form-group"><label for="course">Course</label><select id="course" name="course" required>
                        <option value="">Select Course</option>
                        <?php
                        $course_result = $conn->query("SELECT id, name FROM courses ORDER BY name ASC");
                        while ($course = $course_result->fetch_assoc()): ?>
                            <option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['name']); ?></option>
                        <?php endwhile; ?>
                    </select></div>
                <div class="form-group"><label for="faculty">Faculty</label><select id="faculty" name="faculty" required>
                        <option value="">Select Faculty</option>
                        <?php
                        $faculty_result = $conn->query("SELECT id, name FROM faculties ORDER BY name ASC");
                        while ($faculty = $faculty_result->fetch_assoc()): ?>
                            <option value="<?php echo $faculty['id']; ?>"><?php echo htmlspecialchars($faculty['name']); ?></option>
                        <?php endwhile; ?>
                    </select></div>
                <div class="form-group"><label for="batch_year">Batch Year</label><input type="text" id="batch_year" name="batch_year" placeholder="e.g., 2024/2025" required></div>
                <div class="form-group"><label for="password">Password</label><input type="password" id="password" name="password" placeholder="Leave blank to keep unchanged"></div>
                <div class="form-buttons"><button type="button" class="btn secondary" id="cancelBtn">Cancel</button><button type="submit" class="btn primary">Save User</button></div>
            </form>
        </div>
    </div>

    <!-- Import Excel Modal -->
    <div class="modal" id="importModal" style="display: none;">
        <div class="modal-content">
            <h3>Import Users from Excel</h3>
            <form id="importForm" enctype="multipart/form-data">
                <div class="form-group"><label for="excelFile">Select Excel File (.xlsx)</label><input type="file" id="excelFile" name="excelFile" accept=".xlsx" required></div>
                <div class="import-instructions">
                    <p><strong>Instructions:</strong></p>
                    <ul>
                        <li>Format: .xlsx only</li>
                        <li><strong>Columns:</strong> A=Name, B=Email, C=Role, D=Password, E=Faculty, F=Course</li>
                        <li>Role: student, supervisor, committee, or admin</li>
                        <li>New users: Password required</li>
                        <li>Existing users: Password ignored, Faculty/Course will update</li>
                        <li>Faculty & Course names must match system exactly</li>
                    </ul>
                </div>
                <div class="form-buttons"><button type="button" class="btn secondary" id="cancelImportBtn">Cancel</button><button type="submit" class="btn primary">Upload and Import</button></div>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const userTableBody = document.getElementById('userTableBody');
            const selectAllCheckbox = document.getElementById('selectAllCheckbox');
            const bulkActionsToolbar = document.getElementById('bulkActionsToolbar');
            const selectionCountSpan = document.getElementById('selectionCount');
            const modal = document.getElementById('userModal');
            const userForm = document.getElementById('userForm');
            const modalTitle = document.getElementById('modalTitle');
            const importModal = document.getElementById('importModal');
            const importForm = document.getElementById('importForm');
            let editMode = false;



            const fetchUsers = () => {
                const batch = document.getElementById('batchFilter').value;
                const role = document.getElementById('roleFilter').value;
                const status = document.getElementById('statusFilter').value;
                const course = document.getElementById('courseFilter').value; // Add course filter
                const faculty = document.getElementById('facultyFilter').value; // Add faculty filter
                const search = document.getElementById('search').value;

                userTableBody.innerHTML = '<tr><td colspan="8" style="text-align:center;">Loading...</td></tr>';

                fetch(`user_process.php?action=fetch&batch=${batch}&role=${role}&status=${status}&course=${course}&faculty=${faculty}&search=${search}`)
                    .then(response => response.json())
                    .then(data => {
                        userTableBody.innerHTML = '';
                        if (data.length === 0) {
                            userTableBody.innerHTML = '<tr><td colspan="8" style="text-align:center;">No users found.</td></tr>';
                            return;
                        }
                        data.forEach(user => {
                            const tr = document.createElement('tr');
                            tr.innerHTML = `
                    <td><input type="checkbox" class="user-checkbox" data-id="${user.id}"></td>
                    <td>${user.name}</td>
                    <td>${user.email}</td>
                    <td>${user.course_name || 'N/A'}<br>${user.faculty_name || 'N/A'}</td>
                    <td>${user.role.charAt(0).toUpperCase() + user.role.slice(1)}</td>
                    <td>${user.batch_year || 'N/A'}</td>
                    <td><span class="status ${user.status}">${user.status}</span></td>
                    <td class="actions-cell">
                        <button class="btn-icon edit-btn" data-id="${user.id}" title="Edit"><span class="material-icons">edit</span></button>
                        <button class="btn-icon status-btn" data-id="${user.id}" data-status="${user.status}" title="${user.status === 'active' ? 'Deactivate' : 'Activate'}">
                            <span class="material-icons">${user.status === 'active' ? 'toggle_off' : 'toggle_on'}</span>
                        </button>
                    </td>
                `;
                            userTableBody.appendChild(tr);
                        });
                    }).catch(error => {
                        userTableBody.innerHTML = '<tr><td colspan="8" style="text-align:center; color:red;">Failed to load data.</td></tr>';
                        console.error('Fetch error:', error);
                    });
            };

            const openModal = (mode = 'add', userId = null) => {
                editMode = (mode === 'edit');
                userForm.reset();
                document.getElementById('userId').value = '';

                if (editMode && userId) {
                    modalTitle.textContent = 'Edit User';
                    fetch(`user_process.php?action=fetch_one&id=${userId}`).then(res => res.json()).then(user => {
                        document.getElementById('userId').value = user.id;
                        document.getElementById('name').value = user.name;
                        document.getElementById('email').value = user.email;
                        document.getElementById('role').value = user.role;
                        document.getElementById('batch_year').value = user.batch_year;
                        document.getElementById('course').value = user.course_id || ''; // Populate course
                        document.getElementById('faculty').value = user.faculty_id || ''; // Populate faculty
                        document.getElementById('password').placeholder = 'Leave blank to keep unchanged';
                        document.getElementById('password').required = false;
                    });
                } else {
                    modalTitle.textContent = 'Add New User';
                    document.getElementById('password').placeholder = 'Enter password';
                    document.getElementById('password').required = true;
                }
                modal.style.display = 'flex';
            };

            const closeModal = () => modal.style.display = 'none';
            const openImportModal = () => importModal.style.display = 'flex';
            const closeImportModal = () => importModal.style.display = 'none';

            const updateSelectionToolbar = () => {
                const selectedCheckboxes = document.querySelectorAll('.user-checkbox:checked');
                const count = selectedCheckboxes.length;
                if (count > 0) {
                    bulkActionsToolbar.style.display = 'flex';
                    selectionCountSpan.textContent = `${count} user(s) selected`;
                } else {
                    bulkActionsToolbar.style.display = 'none';
                }
                selectAllCheckbox.checked = count > 0 && count === document.querySelectorAll('.user-checkbox').length;
            };

            document.getElementById('batchFilter').addEventListener('change', fetchUsers);
            document.getElementById('roleFilter').addEventListener('change', fetchUsers);
            document.getElementById('search').addEventListener('input', fetchUsers);
            document.getElementById('statusFilter').addEventListener('change', fetchUsers);
            document.getElementById('courseFilter').addEventListener('change', fetchUsers);
            document.getElementById('facultyFilter').addEventListener('change', fetchUsers);
            document.getElementById('addUserBtn').addEventListener('click', () => openModal('add'));
            document.getElementById('cancelBtn').addEventListener('click', closeModal);
            document.getElementById('importBtn').addEventListener('click', openImportModal);
            document.getElementById('cancelImportBtn').addEventListener('click', closeImportModal);

            selectAllCheckbox.addEventListener('change', (e) => {
                document.querySelectorAll('.user-checkbox').forEach(checkbox => checkbox.checked = e.target.checked);
                updateSelectionToolbar();
            });

            userTableBody.addEventListener('change', (e) => {
                if (e.target.classList.contains('user-checkbox')) {
                    updateSelectionToolbar();
                }
            });

            userTableBody.addEventListener('click', (e) => {
                const button = e.target.closest('button.btn-icon');
                if (!button) return;
                const userId = button.dataset.id;
                if (button.classList.contains('edit-btn')) {
                    openModal('edit', userId);
                }
                if (button.classList.contains('status-btn')) {
                    const status = button.dataset.status;
                    fetch('user_process.php?action=toggle_status', {
                            method: 'POST',
                            body: JSON.stringify({
                                id: userId,
                                status: status
                            })
                        })
                        .then(res => res.json()).then(data => {
                            if (data.success) fetchUsers();
                        });
                }
            });

            document.getElementById('bulkActivateBtn').addEventListener('click', () => handleBulkAction('active'));
            document.getElementById('bulkDeactivateBtn').addEventListener('click', () => handleBulkAction('inactive'));
            document.getElementById('bulkDeleteBtn').addEventListener('click', () => handleBulkAction('delete'));

            const handleBulkAction = (action) => {
                const selectedIds = [...document.querySelectorAll('.user-checkbox:checked')].map(cb => cb.dataset.id);
                if (selectedIds.length === 0) return alert('Please select at least one user.');

                let url, body, confirmation;
                if (action === 'delete') {
                    confirmation = confirm(`Are you sure you want to delete ${selectedIds.length} user(s)? This action cannot be undone.`);
                    url = 'user_process.php?action=bulk_delete';
                    body = {
                        ids: selectedIds
                    };
                } else {
                    confirmation = confirm(`Are you sure you want to set status to '${action}' for ${selectedIds.length} user(s)?`);
                    url = 'user_process.php?action=bulk_toggle_status';
                    body = {
                        ids: selectedIds,
                        status: action
                    };
                }

                if (confirmation) {
                    fetch(url, {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify(body)
                        })
                        .then(res => res.json()).then(data => {
                            if (data.success) {
                                fetchUsers();
                                bulkActionsToolbar.style.display = 'none';
                            } else {
                                alert(data.message || 'An error occurred.');
                            }
                        });
                }
            };

            userForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const data = Object.fromEntries(new FormData(userForm).entries());
                const url = editMode ? 'user_process.php?action=update' : 'user_process.php?action=create';
                fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(data)
                    })
                    .then(res => res.json())
                    .then(response => {
                        if (response.success) {
                            closeModal();
                            fetchUsers();
                        } else {
                            alert(response.message || 'An error occurred.');
                        }
                    });
            });

            importForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(importForm);
                fetch('user_process.php?action=import_excel', {
                        method: 'POST',
                        body: formData
                    })
                    .then(res => res.json()).then(response => {
                        alert(response.message);
                        if (response.success) {
                            closeImportModal();
                            fetchUsers();
                        }
                    });
            });

            fetchUsers();
        });
    </script>
</body>

</html>