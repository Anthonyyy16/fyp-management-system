<?php

session_start();
if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once '../db_connect.php';

$action = $_GET['action'] ?? '';

switch ($action) {

    case 'fetch_all_settings':
        fetchAllSettings($conn);
        break;
    case 'save_all_settings':
        saveAllSettings($conn);
        break;

    
    default:
        // ...

        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}


function fetchAllSettings($conn) {
    header('Content-Type: application/json');
    $sql = "SELECT setting_key, setting_value FROM system_settings";
    $result = $conn->query($sql);
    
    $settings = [];
    while($row = $result->fetch_assoc()) {
        $settings[$row['setting_key']] = $row['setting_value'];
    }
    
    echo json_encode(['success' => true, 'data' => $settings]);
}

function saveAllSettings($conn) {
    header('Content-Type: application/json');
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data) || !is_array($data)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid settings data.']);
        return;
    }

    $conn->begin_transaction();
    try {
        
        $stmt = $conn->prepare("
            INSERT INTO system_settings (setting_key, setting_value) 
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");

        foreach ($data as $key => $value) {
            
            if (is_bool($value)) {
                $value_str = $value ? 'true' : 'false';
            } else {
                $value_str = (string)$value;
            }
            $stmt->bind_param('ss', $key, $value_str);
            $stmt->execute();
        }
        $stmt->close();
        
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Settings saved successfully.']);
        
    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
}

?>
