<?php
session_start();

if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    header("Location: ../index.php");
    exit();
}

require_once '../db_connect.php';$batches = [];
$batch_result = $conn->query("SELECT DISTINCT batch_year FROM users WHERE batch_year IS NOT NULL AND batch_year != '' ORDER BY batch_year DESC");
if ($batch_result) {
    while ($row = $batch_result->fetch_assoc()) {
        $batches[] = $row['batch_year'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcement Management - Admin</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="admin.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        .form-group label {
            flex: 1 1 100%;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <h2>Admin Panel - Announcement Management</h2>
        <div class="button-group">
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>

    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Admin Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="Admin_Dashboard.php"><span class="material-icons">dashboard</span> Dashboard</a></li>
                <li><a href="Admin_UserMngm.php"><span class="material-icons">people</span> User Management</a></li>
                <li class="active"><a href="admin_announcements.php"><span class="material-icons">campaign</span> Announcements</a></li>
                <li><a href="Admin_Deadline.php"><span class="material-icons">event</span>Global Deadlines</a></li>
                <li><a href="Admin_Allocation.php"><span class="material-icons">assignment_ind</span>Project Allocation</a></li>
                <li><a href="Admin_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <!-- <li><a href="Admin_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li> -->
                <li ><a href="Admin_Batch.php"><span class="material-icons">school</span>Batch Management</a></li>
                <li><a href="Admin_Report.php"><span class="material-icons">bar_chart</span>Reports</a></li>
                <li><a href="Admin_System.php"><span class="material-icons">settings</span>System Settings</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="content-header">
                <h1>Manage Announcements</h1>
                <p>Create, edit, and manage system-wide announcements.</p>
            </div>

            <!-- Add/Edit Announcement Card -->
            <div class="card">
                <h3 id="formTitle">Create a New Announcement</h3>
                <form id="announcementForm">
                    <input type="hidden" id="announcementId" name="id">
                    <div class="form-group">
                        <label for="batch">Target Batch</label>
                        <select id="batch" name="batch_year" class="form-input">
                            <option value="">-- All Batches --</option>
                            <?php foreach ($batches as $batch): ?>
                                <option value="<?php echo htmlspecialchars($batch); ?>">
                                    <?php echo htmlspecialchars($batch); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p style="font-size: 0.85rem; color: var(--muted); margin-top: 5px;">If "All Batches" is selected, this announcement will be visible to all batches.</p>
                    </div>
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" id="title" name="title" placeholder="Enter the announcement title" required>
                    </div>
                    <div class="form-group">
                        <label for="content">Content</label>
                        <textarea id="content" name="content" rows="5" placeholder="Write the content of the announcement here." required></textarea>
                    </div>
                    <div class="form-buttons">
                        <button type="button" class="btn secondary" id="cancelBtn" style="display: none;">Cancel Edit</button>
                        <button type="submit" class="btn primary">Post Announcement</button>
                    </div>
                </form>
            </div>

            <!-- Announcements Table Card -->
            <div class="card">
                <h3>Posted Announcements</h3>
                <div class="data-table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Batch</th>
                                <th>Posted By</th>
                                <th>Date Posted</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="announcementTableBody"></tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const announcementForm = document.getElementById('announcementForm');
            const announcementTableBody = document.getElementById('announcementTableBody');
            const formTitle = document.getElementById('formTitle');
            const announcementIdInput = document.getElementById('announcementId');
            const cancelBtn = document.getElementById('cancelBtn');
            let editMode = false;

            const fetchAnnouncements = () => {
                announcementTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;">Loading...</td></tr>';
                fetch('admin_action.php?action=fetch_announcements')
                    .then(res => res.json())
                    .then(data => {
                        announcementTableBody.innerHTML = '';
                        if (data.length === 0) {
                            announcementTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;">No announcements posted yet.</td></tr>';
                            return;
                        }
                        data.forEach(announcement => {
                            const tr = document.createElement('tr');
                            const postedDate = new Date(announcement.created_at).toLocaleString('en-GB');
                            const batchDisplay = announcement.batch_year ? `<td>${announcement.batch_year}</td>` : '<td><span style="color: var(--muted);">All Batches</span></td>';
                            tr.innerHTML = `
                    <td>${announcement.title}</td>
                    ${batchDisplay}
                    <td>${announcement.author_name}</td>
                    <td>${postedDate}</td>
                    <td class="actions-cell">
                        <button class="btn-icon edit-btn" data-id='${announcement.id}' data-announcement='${JSON.stringify(announcement)}' title="Edit"><span class="material-icons">edit</span></button>
                        <button class="btn-icon delete-btn" data-id="${announcement.id}" title="Delete"><span class="material-icons">delete</span></button>
                    </td>
                `;
                            announcementTableBody.appendChild(tr);
                        });
                    });
            };

            const resetForm = () => {
                announcementForm.reset();
                announcementIdInput.value = '';
                formTitle.textContent = 'Create a New Announcement';
                announcementForm.querySelector('button[type="submit"]').textContent = 'Post Announcement';
                cancelBtn.style.display = 'none';
                editMode = false;
            };

            announcementForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(announcementForm);
                const data = Object.fromEntries(formData.entries());

                const url = editMode ? 'admin_action.php?action=update_announcement' : 'admin_action.php?action=create_announcement';

                fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(data)
                    })
                    .then(res => res.json())
                    .then(response => {
                        if (response.success) {
                            resetForm();
                            fetchAnnouncements();
                        } else {
                            alert(response.message || 'An error occurred.');
                        }
                    });
            });

            announcementTableBody.addEventListener('click', (e) => {
                const target = e.target.closest('button');
                if (!target) return;

                const id = target.dataset.id;
                if (target.classList.contains('edit-btn')) {
                    const announcementData = JSON.parse(target.dataset.announcement);
                    formTitle.textContent = 'Edit Announcement';
                    announcementForm.querySelector('button[type="submit"]').textContent = 'Save Changes';
                    announcementIdInput.value = announcementData.id;
                    document.getElementById('title').value = announcementData.title;
                    document.getElementById('content').value = announcementData.content;
                    document.getElementById('batch').value = announcementData.batch_year || '';
                    cancelBtn.style.display = 'inline-flex';
                    editMode = true;
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }

                if (target.classList.contains('delete-btn')) {
                    if (confirm('Are you sure you want to delete this announcement?')) {
                        fetch('admin_action.php?action=delete_announcement', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    id: id
                                })
                            })
                            .then(res => res.json())
                            .then(response => {
                                if (response.success) {
                                    fetchAnnouncements();
                                } else {
                                    alert(response.message || 'Failed to delete.');
                                }
                            });
                    }
                }
            });

            cancelBtn.addEventListener('click', resetForm);

            fetchAnnouncements();
        });
    </script>
</body>

</html>