<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once '../db_connect.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'fetch_batches':
        fetchBatches($conn);
        break;
    case 'create_batch':
        createBatch($conn);
        break;
    case 'delete_batch':
        deleteBatch($conn);
        break;
    case 'fetch_batch_details':
        fetchBatchDetails($conn);
        break;
    case 'add_group_to_batch':
        addGroupToBatch($conn);
        break;
    case 'remove_group':
        removeGroup($conn);
        break;
    case 'assign_supervisor_to_group':
        assignSupervisorToGroup($conn);
        break;
    case 'assign_moderator_to_group':
        assignModeratorToGroup($conn);
        break;
    case 'fetch_supervisors':
        fetchSupervisors($conn);
        break;
    case 'fetch_batch_committees':
        fetchBatchCommittees($conn);
        break;
    case 'add_committee_to_batch':
        addCommitteeToBatch($conn);
        break;
    case 'remove_committee_from_batch':
        removeCommitteeFromBatch($conn);
        break;
    case 'check_table':
        checkTableExists($conn);
        break;
    case 'run_migrations':
        runMigrations($conn);
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}


function fetchBatches($conn)
{
    $sql = "SELECT 
                g.batch_year,
                COUNT(g.id) as group_count,
                COUNT(DISTINCT g.supervisor_id) as supervisor_count,
                COUNT(DISTINCT CASE WHEN g.moderator_id IS NOT NULL THEN g.id END) as assigned_moderators,
                MIN(g.created_at) as created_at
            FROM groups g
            WHERE g.batch_year IS NOT NULL AND g.batch_year != ''
            GROUP BY g.batch_year
            ORDER BY g.batch_year DESC";
    
    $result = $conn->query($sql);
    $batches = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($batches);
}

/**
 */
function createBatch($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    
    $batch_year = $data['batch_year'] ?? '';
    $supervisor_ids = $data['supervisor_ids'] ?? [];
    
    if (empty($batch_year)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'batch_year is required']);
        return;
    }
    
    // Check if batch already exists
    $stmt_check = $conn->prepare("SELECT id FROM groups WHERE batch_year = ? LIMIT 1");
    $stmt_check->bind_param('s', $batch_year);
    $stmt_check->execute();
    $stmt_check->store_result();
    
    if ($stmt_check->num_rows > 0) {
        $stmt_check->close();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Batch already exists']);
        return;
    }
    $stmt_check->close();
    
    try {
        $conn->begin_transaction();        $placeholder_sup_id = NULL;
        $status = 'active';
        $stmt_placeholder = $conn->prepare(
            "INSERT INTO groups (supervisor_id, batch_year, status, created_at) 
             VALUES (NULL, ?, ?, NOW())"
        );
        $stmt_placeholder->bind_param('ss', $batch_year, $status);
        $stmt_placeholder->execute();
        $stmt_placeholder->close();        if (!empty($supervisor_ids) && is_array($supervisor_ids)) {
            $stmt_insert = $conn->prepare(
                "INSERT INTO groups (supervisor_id, batch_year, status, created_at) 
                 VALUES (?, ?, ?, NOW())"
            );
            
            foreach ($supervisor_ids as $sup_id) {
                $stmt_insert->bind_param('iss', $sup_id, $batch_year, $status);
                $stmt_insert->execute();
            }
            $stmt_insert->close();
        }
        
        $conn->commit();
        echo json_encode(['success' => true, 'message' => 'Batch created successfully']);
        
    } catch (Exception $e) {
        $conn->rollback();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error creating batch: ' . $e->getMessage()]);
    }
}


function deleteBatch($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $batch_year = $data['batch_year'] ?? '';
    
    if (empty($batch_year)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'batch_year is required']);
        return;
    }
    
    // Check if batch has moderators assigned
    $stmt_check = $conn->prepare(
        "SELECT COUNT(*) as count FROM groups 
         WHERE batch_year = ? AND moderator_id IS NOT NULL"
    );
    $stmt_check->bind_param('s', $batch_year);
    $stmt_check->execute();
    $result = $stmt_check->get_result()->fetch_assoc();
    $stmt_check->close();
    
    if ($result['count'] > 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Cannot delete batch with assigned moderators']);
        return;
    }
    
    // Delete batch
    $stmt_delete = $conn->prepare("DELETE FROM groups WHERE batch_year = ?");
    $stmt_delete->bind_param('s', $batch_year);
    $stmt_delete->execute();
    $stmt_delete->close();
    
    echo json_encode(['success' => true, 'message' => 'Batch deleted successfully']);
}


function fetchBatchDetails($conn)
{
    $batch_year = $_GET['batch_year'] ?? '';
    
    if (empty($batch_year)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'batch_year is required']);
        return;
    }    $sql_groups = "SELECT g.id, g.supervisor_id, sup.name as supervisor_name, g.moderator_id, moderator.name as moderator_name FROM groups g LEFT JOIN users sup ON g.supervisor_id = sup.id LEFT JOIN users moderator ON g.moderator_id = moderator.id WHERE g.batch_year = ? ORDER BY g.id";
    
    $stmt = $conn->prepare($sql_groups);
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
        return;
    }
    
    $stmt->bind_param('s', $batch_year);
    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Query error: ' . $stmt->error]);
        $stmt->close();
        return;
    }
    
    $groups = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    echo json_encode(['success' => true, 'groups' => $groups]);
}


function addGroupToBatch($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $batch_year = $data['batch_year'] ?? '';
    $supervisor_id = $data['supervisor_id'] ?? null;
    
    if (empty($batch_year)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'batch_year is required']);
        return;
    }
    
    try {
        $stmt = $conn->prepare(
            "INSERT INTO groups (supervisor_id, batch_year, status, created_at) 
             VALUES (?, ?, 'active', NOW())"
        );
        
        $stmt->bind_param('is', $supervisor_id, $batch_year);
        $stmt->execute();
        $group_id = $conn->insert_id;
        $stmt->close();
        
        echo json_encode(['success' => true, 'group_id' => $group_id, 'message' => 'Group added successfully']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error adding group: ' . $e->getMessage()]);
    }
}


function removeGroup($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $group_id = $data['group_id'] ?? null;
    
    if (empty($group_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'group_id is required']);
        return;
    }
    
    // Check if moderator is assigned
    $stmt_check = $conn->prepare("SELECT moderator_id FROM groups WHERE id = ?");
    $stmt_check->bind_param('i', $group_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result()->fetch_assoc();
    $stmt_check->close();
    
    if ($result['moderator_id'] !== NULL) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Cannot delete group with assigned moderator']);
        return;
    }
    
    try {
        $stmt = $conn->prepare("DELETE FROM groups WHERE id = ?");
        $stmt->bind_param('i', $group_id);
        $stmt->execute();
        $stmt->close();
        
        echo json_encode(['success' => true, 'message' => 'Group deleted successfully']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error deleting group: ' . $e->getMessage()]);
    }
}


function assignSupervisorToGroup($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $group_id = $data['group_id'] ?? null;
    $supervisor_id = $data['supervisor_id'] ?? null;
    
    if (empty($group_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'group_id is required']);
        return;
    }
    
    // Validate supervisor exists if provided
    if (!empty($supervisor_id)) {
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE id = ? AND role = 'supervisor'");
        $stmt_check->bind_param('i', $supervisor_id);
        $stmt_check->execute();
        $stmt_check->store_result();
        
        if ($stmt_check->num_rows === 0) {
            $stmt_check->close();
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Selected user is not a supervisor']);
            return;
        }
        $stmt_check->close();
    }
    
    try {
        $stmt = $conn->prepare("UPDATE groups SET supervisor_id = ? WHERE id = ?");
        $stmt->bind_param('ii', $supervisor_id, $group_id);
        $stmt->execute();
        $stmt->close();
        
        echo json_encode(['success' => true, 'message' => 'Supervisor assigned successfully']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error assigning supervisor: ' . $e->getMessage()]);
    }
}


function assignModeratorToGroup($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $group_id = $data['group_id'] ?? null;
    $moderator_id = $data['moderator_id'] ?? null;
    
    if (empty($group_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'group_id is required']);
        return;
    }
    
    // Validate moderator exists if provided (moderator should be a supervisor)
    if (!empty($moderator_id)) {
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE id = ? AND role = 'supervisor'");
        $stmt_check->bind_param('i', $moderator_id);
        $stmt_check->execute();
        $stmt_check->store_result();
        
        if ($stmt_check->num_rows === 0) {
            $stmt_check->close();
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Selected user is not a supervisor']);
            return;
        }
        $stmt_check->close();
    }
    
    try {
        $stmt = $conn->prepare("UPDATE groups SET moderator_id = ? WHERE id = ?");
        $stmt->bind_param('ii', $moderator_id, $group_id);
        $stmt->execute();
        $stmt->close();
        
        echo json_encode(['success' => true, 'message' => 'Moderator assigned successfully']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error assigning moderator: ' . $e->getMessage()]);
    }
}


function fetchSupervisors($conn)
{
    $batch_year = $_GET['batch_year'] ?? null;
    
    if ($batch_year !== null) {
        // When batch_year is specified, show supervisors applicable to that batch
        $sql = "SELECT DISTINCT u.id, u.name 
                FROM users u
                WHERE u.role = 'supervisor' AND u.status = 'active'
                AND (
                    -- Already has groups in this batch
                    EXISTS (SELECT 1 FROM groups g WHERE g.supervisor_id = u.id AND g.batch_year = ?)
                    OR 
                    -- Or supervisor has no groups anywhere (brand new)
                    NOT EXISTS (SELECT 1 FROM groups g WHERE g.supervisor_id = u.id)
                )
                ORDER BY u.name ASC";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('s', $batch_year);
        $stmt->execute();
        $result = $stmt->get_result();
        $supervisors = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
    } else {
        // No batch specified, return all supervisors
        $sql = "SELECT id, name FROM users WHERE role = 'supervisor' AND status = 'active' ORDER BY name ASC";
        $result = $conn->query($sql);
        $supervisors = $result->fetch_all(MYSQLI_ASSOC);
    }
    
    echo json_encode($supervisors);
}


function fetchBatchCommittees($conn)
{
    $batch_year = $_GET['batch_year'] ?? '';
    
    if (empty($batch_year)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'batch_year is required']);
        return;
    }
    
    // Create table if not exists
    $sql_create = "CREATE TABLE IF NOT EXISTS batch_committees (
        id INT AUTO_INCREMENT PRIMARY KEY,
        batch_year VARCHAR(20) NOT NULL,
        committee_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (committee_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE KEY unique_batch_committee (batch_year, committee_id)
    )";
    $conn->query($sql_create);
    
    $sql = "SELECT u.id, u.name, u.email 
            FROM batch_committees bc
            JOIN users u ON bc.committee_id = u.id
            WHERE bc.batch_year = ?
            ORDER BY u.name ASC";
    
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
        return;
    }
    
    $stmt->bind_param('s', $batch_year);
    if (!$stmt->execute()) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Query error: ' . $stmt->error]);
        $stmt->close();
        return;
    }
    
    $committees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    echo json_encode(['success' => true, 'committees' => $committees]);
}


function addCommitteeToBatch($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $batch_year = $data['batch_year'] ?? '';
    $committee_id = $data['committee_id'] ?? null;
    
    if (empty($batch_year) || empty($committee_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'batch_year and committee_id are required']);
        return;
    }
    
    // Create table if not exists
    $sql_create = "CREATE TABLE IF NOT EXISTS batch_committees (
        id INT AUTO_INCREMENT PRIMARY KEY,
        batch_year VARCHAR(20) NOT NULL,
        committee_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (committee_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE KEY unique_batch_committee (batch_year, committee_id)
    )";
    $conn->query($sql_create);
    
    // Validate committee member exists
    $stmt_check = $conn->prepare("SELECT id FROM users WHERE id = ? AND role = 'supervisor' AND status = 'active'");
    $stmt_check->bind_param('i', $committee_id);
    $stmt_check->execute();
    $stmt_check->store_result();
    
    if ($stmt_check->num_rows === 0) {
        $stmt_check->close();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Selected user is not an active supervisor']);
        return;
    }
    $stmt_check->close();
    
    // Check if already exists
    $stmt_check_exists = $conn->prepare("SELECT id FROM batch_committees WHERE batch_year = ? AND committee_id = ?");
    $stmt_check_exists->bind_param('si', $batch_year, $committee_id);
    $stmt_check_exists->execute();
    $stmt_check_exists->store_result();
    
    if ($stmt_check_exists->num_rows > 0) {
        $stmt_check_exists->close();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'This person is already a committee member for this batch']);
        return;
    }
    $stmt_check_exists->close();
    
    try {
        $stmt = $conn->prepare(
            "INSERT INTO batch_committees (batch_year, committee_id, created_at) 
             VALUES (?, ?, NOW())"
        );
        
        $stmt->bind_param('si', $batch_year, $committee_id);
        $stmt->execute();
        $stmt->close();
        
        echo json_encode(['success' => true, 'message' => 'Committee member added successfully']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error adding committee member: ' . $e->getMessage()]);
    }
}


function removeCommitteeFromBatch($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    $batch_year = $data['batch_year'] ?? '';
    $committee_id = $data['committee_id'] ?? null;
    
    if (empty($batch_year) || empty($committee_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'batch_year and committee_id are required']);
        return;
    }
    
    // Create table if not exists
    $sql_create = "CREATE TABLE IF NOT EXISTS batch_committees (
        id INT AUTO_INCREMENT PRIMARY KEY,
        batch_year VARCHAR(20) NOT NULL,
        committee_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (committee_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE KEY unique_batch_committee (batch_year, committee_id)
    )";
    $conn->query($sql_create);
    
    try {
        $stmt = $conn->prepare("DELETE FROM batch_committees WHERE batch_year = ? AND committee_id = ?");
        $stmt->bind_param('si', $batch_year, $committee_id);
        $stmt->execute();
        $stmt->close();
        
        echo json_encode(['success' => true, 'message' => 'Committee member removed successfully']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error removing committee member: ' . $e->getMessage()]);
    }
}


function checkTableExists($conn)
{
    $table = $_GET['table'] ?? '';
    
    if (empty($table)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'exists' => false]);
        return;
    }
    
    $sql = "SHOW TABLES LIKE ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $table);
    $stmt->execute();
    $stmt->store_result();
    
    $exists = $stmt->num_rows > 0;
    $stmt->close();
    
    echo json_encode(['success' => true, 'exists' => $exists]);
}


function runMigrations($conn)
{
    try {
        // Create batch_committees table
        $sql_create_batch_committees = "CREATE TABLE IF NOT EXISTS batch_committees (
            id INT AUTO_INCREMENT PRIMARY KEY,
            batch_year VARCHAR(20) NOT NULL,
            committee_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (committee_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY unique_batch_committee (batch_year, committee_id),
            INDEX idx_batch_year (batch_year)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
        
        if (!$conn->query($sql_create_batch_committees)) {
            throw new Exception('Failed to create batch_committees table: ' . $conn->error);
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Migration completed successfully. batch_committees table is ready.'
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'message' => 'Migration failed: ' . $e->getMessage()
        ]);
    }
}

$conn->close();
?>
