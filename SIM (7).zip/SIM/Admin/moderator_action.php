<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once '../db_connect.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'fetch_batches':
        fetchBatches($conn);
        break;
    case 'fetch_groups_by_batch':
        fetchGroupsByBatch($conn);
        break;
    case 'fetch_supervisors':
        fetchSupervisors($conn);
        break;
    case 'update_moderator':
        updateModerator($conn);
        break;
    default:
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}


function fetchBatches($conn)
{
    $sql = "SELECT DISTINCT batch_year FROM groups WHERE batch_year IS NOT NULL AND batch_year != '' ORDER BY batch_year DESC";
    $result = $conn->query($sql);
    $batches = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($batches);
}


function fetchGroupsByBatch($conn)
{
    $batch_year = $_GET['batch_year'] ?? '';
    
    if (empty($batch_year)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'batch_year is required']);
        return;
    }

    $sql = "SELECT 
                g.id, 
                g.batch_year,
                (SELECT u.project_title 
                 FROM users u 
                 WHERE u.group_id = g.id 
                 AND u.project_title IS NOT NULL 
                 LIMIT 1) AS project_title,
                g.supervisor_id, 
                sup.name AS supervisor_name, 
                g.moderator_id, 
                moderator.name AS moderator_name
            FROM groups g
            LEFT JOIN users sup ON g.supervisor_id = sup.id
            LEFT JOIN users moderator ON g.moderator_id = moderator.id
            WHERE g.batch_year = ?
            ORDER BY g.id";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
        return;
    }

    $stmt->bind_param('s', $batch_year);
    $stmt->execute();
    $result = $stmt->get_result();
    $groups = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    echo json_encode($groups);
}


function fetchSupervisors($conn)
{
    $sql = "SELECT id, name FROM users WHERE role = 'supervisor' AND status = 'active' ORDER BY name ASC";
    $result = $conn->query($sql);
    $supervisors = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($supervisors);
}


function updateModerator($conn)
{
    $data = json_decode(file_get_contents('php://input'), true);
    
    $group_id = $data['group_id'] ?? null;
    $moderator_id = $data['moderator_id'] ?? null;

    if (empty($group_id)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'group_id is required']);
        return;
    }

    
    if (!empty($moderator_id)) {
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE id = ? AND role = 'supervisor'");
        if (!$stmt_check) {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
            return;
        }
        $stmt_check->bind_param('i', $moderator_id);
        $stmt_check->execute();
        $stmt_check->store_result();
        if ($stmt_check->num_rows === 0) {
            $stmt_check->close();
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Selected user is not a supervisor']);
            return;
        }
        $stmt_check->close();
    }

    
    $stmt_update = $conn->prepare("UPDATE groups SET moderator_id = ? WHERE id = ?");
    if (!$stmt_update) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
        return;
    }

    $stmt_update->bind_param('ii', $moderator_id, $group_id);
    if (!$stmt_update->execute()) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to update moderator']);
        $stmt_update->close();
        return;
    }
    $stmt_update->close();

    echo json_encode(['success' => true, 'message' => 'Moderator updated successfully']);
}

$conn->close();
?>
