<?php
session_start();if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings - Admin</title>
    <link rel="stylesheet" href="../index.css?v=1.1">
    <link rel="stylesheet" href="admin.css?v=1.1">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <style>
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 36px;
            height: 20px;
            vertical-align: middle;
        }

        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 20px;
        }

        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 2px;
            bottom: 2px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked+.toggle-slider {
            background-color: var(--primary);
        }

        input:checked+.toggle-slider:before {
            transform: translateX(16px);
        }

        .settings-form {
            display: block;
        }

        .settings-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(450px, 1fr));
            gap: 25px;
            margin-bottom: 25px;
            align-items: start;
        }

        .card h2 {
            margin-top: 0;
            margin-bottom: 20px;
            color: var(--text);
            border-bottom: 1px solid var(--border-color, #eee);
            padding-bottom: 10px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
            margin-bottom: 20px;
        }

        .form-group.horizontal {
            flex-direction: row;
            justify-content: space-between;
            align-items: center;
        }

        .form-group label {
            font-weight: 500;
            color: var(--text);
        }

        .form-group p {
            font-size: 0.9rem;
            color: var(--muted);
            margin: 0;
        }

        .form-input {
            padding: 10px 15px;
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            font-size: 1rem;
            width: 100%;
        }

        .form-input:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
            outline: none;
        }

        .form-footer {
            margin-top: 10px;
            text-align: right;
        }

        #saveStatus {
            text-align: right;
            color: var(--muted);
            opacity: 0;
            transition: opacity 0.5s;
        }

        #saveStatus.show {
            opacity: 1;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <h2>Admin Panel - User Management</h2>
        <div class="button-group">
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>

    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Admin Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="Admin_Dashboard.php"><span class="material-icons">dashboard</span> Dashboard</a></li>
                <li><a href="Admin_UserMngm.php"><span class="material-icons">people</span> User Management</a></li>
                <li><a href="Admin_Announcements.php"><span class="material-icons">campaign</span>Announcements</a></li>
                <li><a href="Admin_Deadline.php"><span class="material-icons">event</span>Global Deadlines</a></li>
                <li><a href="Admin_Allocation.php"><span class="material-icons">assignment_ind</span>Project Allocation</a></li>
                <li><a href="Admin_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <!-- <li><a href="Admin_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li> -->
                <li ><a href="Admin_Batch.php"><span class="material-icons">school</span>Batch Management</a></li>
                <li><a href="Admin_Report.php"><span class="material-icons">bar_chart</span>Reports</a></li>
                <li class="active"><a href="Admin_System.php"><span class="material-icons">settings</span>System Settings</a></li>
            </ul>
        </div>


        <main class="main-content">

            <div class="page-header">
                <h1>System Settings</h1>
                <p>Configure the core settings for the FYP Management System.</p>
            </div>

            <form id="settingsForm" class="settings-form">

                <div class="settings-grid">

                    <div class="card">
                        <h2>General Settings</h2>
                        <div class="form-group">
                            <label for="current_academic_year">Current Academic Year</label>
                            <p>Set the active session (e.g., 2024/2025). This controls the default batch for new users and archives.</p>
                            <input type="text" id="current_academic_year" class="form-input" placeholder="e.g., 2024/2025">
                        </div>

                        <div class="form-group horizontal">
                            <div>
                                <label>Maintenance Mode</label>
                                <p>Temporarily disable access for students and supervisors while performing maintenance.</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="maintenance_mode">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>

                    <div class="card">
                        <h2>Allocation Settings</h2>

                        <div class="form-group horizontal">
                            <div>
                                <label>Enable Student Applications</label>
                                <p>Allow students to send applications to supervisors. (Recommended: On)</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="allow_student_applications">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>

                        <div class="form-group" >
                            <label for="max_student_applications">Max Pending Applications</label>
                            <p>Limit how many *pending* applications a student can have simultaneously.</p>
                            <input type="number" id="max_student_applications" class="form-input" min="1" max="10" placeholder="e.g., 3">
                        </div>

                        <div class="form-group horizontal">
                            <div>
                                <label>Supervisor Can Edit Capacity</label>
                                <p>Allow supervisors to set their own student capacity. (If Off, only Admin can set capacity).</p>
                            </div>
                            <label class="toggle-switch">
                                <input type="checkbox" id="allow_supervisor_capacity_edit">
                                <span class="toggle-slider"></span>
                            </label>
                        </div>
                    </div>

                    <div class="card">
                        <h2>Submission Settings</h2>
                        <div class="form-group">
                            <label for="allowed_file_types">Allowed File Types</label>
                            <p>Comma-separated list of allowed file extensions (without dots).</p>
                            <input type="text" id="allowed_file_types" class="form-input" placeholder="pdf,zip,doc,docx">
                        </div>
                        <div class="form-group">
                            <label for="max_file_size_mb">Max File Size (in MB)</label>
                            <p>Set the maximum upload size for a single submission.</p>
                            <input type="number" id="max_file_size_mb" class="form-input" min="1" placeholder="e.g., 25">
                        </div>
                    </div>

                    <div class="card">
                        <h2>System Maintenance</h2>
                        <div id="systemStatus" style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin-bottom: 15px; font-size: 0.9em;">
                            <p style="margin: 5px 0;"><strong>Database Size:</strong> <span id="dbSize">Loading...</span></p>
                            <p style="margin: 5px 0;"><strong>Backups:</strong> <span id="backupCount">Loading...</span></p>
                            <p style="margin: 5px 0;"><strong>Disk Free:</strong> <span id="diskFree">Loading...</span></p>
                        </div>
                        <button type="button" class="btn primary" id="optimizeDbBtn" style="width: 100%; margin-bottom: 10px;">
                            <span class="material-icons" style="vertical-align: middle;">tune</span> Optimize Database
                        </button>
                        <button type="button" class="btn secondary" id="clearCacheBtn" style="width: 100%; margin-bottom: 10px;">
                            <span class="material-icons" style="vertical-align: middle;">delete_sweep</span> Clear System Cache
                        </button>
                    </div>

                </div>

                <!-- Backup Management Section -->
                <div class="page-header" style="margin-top: 40px; margin-bottom: 20px;">
                    <h2 style="margin: 0;">Backup Management</h2>
                    <p>Create and manage database backups.</p>
                </div>

                <div class="settings-grid">
                    <div class="card">
                        <h2>Backup Schedule</h2>
                        <div class="form-group">
                            <label for="backup_frequency">Backup Frequency</label>
                            <p>Set how often automatic backups should be created.</p>
                            <select id="backup_frequency" class="form-input">
                                <option value="daily">Daily</option>
                                <option value="weekly">Weekly</option>
                                <option value="monthly">Monthly</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Last Backup</label>
                            <p id="lastBackupTime" style="color: var(--muted); margin: 0;">Loading...</p>
                        </div>
                        <button type="button" class="btn primary" id="createBackupBtn" style="width: 100%;">
                            <span class="material-icons" style="vertical-align: middle;">cloud_upload</span> Create Backup Now
                        </button>
                    </div>

                    <div class="card">
                        <h2>Existing Backups</h2>
                        <div id="backupsList" style="max-height: 400px; overflow-y: auto;">
                            <p style="text-align: center; color: var(--muted);">Loading backups...</p>
                        </div>
                    </div>
                </div>

                <!-- System Logs Section -->
                <div class="form-footer">
                    <span id="saveStatus"></span>
                    <button type="submit" class="btn primary">
                        <span class="material-icons">save</span>
                        Save All Settings
                    </button>
                </div>

            </form>
        </main>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {

            const form = document.getElementById('settingsForm');
            const saveStatus = document.getElementById('saveStatus');

            function loadSettings() {
                showStatus('Loading settings...');                fetch('admin_system_process.php?action=fetch_all_settings')
                    .then(res => res.json())
                    .then(response => {
                        if (response.success) {
                            populateForm(response.data);
                            showStatus('Settings loaded.', false);
                        } else {
                            showStatus('Failed to load settings.', true);
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        showStatus('Error connecting to server.', true);
                    });
            }

            function populateForm(settings) {                document.getElementById('current_academic_year').value = settings.current_academic_year || '';
                document.getElementById('max_student_applications').value = settings.max_student_applications || '3';
                document.getElementById('allowed_file_types').value = settings.allowed_file_types || 'pdf,zip';
                document.getElementById('max_file_size_mb').value = settings.max_file_size_mb || '25';                document.getElementById('maintenance_mode').checked = (settings.maintenance_mode === 'true');
                document.getElementById('allow_student_applications').checked = (settings.allow_student_applications === 'true');
                document.getElementById('allow_supervisor_capacity_edit').checked = (settings.allow_supervisor_capacity_edit === 'true');
            }

            form.addEventListener('submit', function(e) {
                e.preventDefault();
                showStatus('Saving...');                const settingsData = {
                    current_academic_year: document.getElementById('current_academic_year').value,
                    max_student_applications: document.getElementById('max_student_applications').value,
                    allowed_file_types: document.getElementById('allowed_file_types').value,
                    max_file_size_mb: document.getElementById('max_file_size_mb').value,

                    maintenance_mode: document.getElementById('maintenance_mode').checked,
                    allow_student_applications: document.getElementById('allow_student_applications').checked,
                    allow_supervisor_capacity_edit: document.getElementById('allow_supervisor_capacity_edit').checked
                };                fetch('admin_system_process.php?action=save_all_settings', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(settingsData)
                    })
                    .then(res => res.json())
                    .then(response => {
                        if (response.success) {
                            showStatus('Settings saved successfully!', false);
                        } else {
                            showStatus(response.message || 'Failed to save.', true);
                        }
                    })
                    .catch(err => {
                        console.error(err);
                        showStatus('Error connecting to server.', true);
                    });
            });

            let statusTimer;

            function showStatus(message, isError = false) {
                clearTimeout(statusTimer);
                saveStatus.textContent = message;
                saveStatus.style.color = isError ? 'red' : 'var(--muted)';
                saveStatus.classList.add('show');

                statusTimer = setTimeout(() => {
                    saveStatus.classList.remove('show');
                }, 3000);
            }

            // ========== SYSTEM MAINTENANCE ==========
            
            // Load system status
            function loadSystemStatus() {
                fetch('admin_maintenance_process.php?action=get_system_status')
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById('dbSize').textContent = data.status.database_size;
                            document.getElementById('backupCount').textContent = data.status.backup_count + ' backups';
                            document.getElementById('diskFree').textContent = data.status.disk_free;
                        }
                    })
                    .catch(err => console.error('Error loading system status:', err));
            }

            // Optimize database
            document.getElementById('optimizeDbBtn').addEventListener('click', function() {
                if (confirm('This will optimize all database tables. Continue?')) {
                    this.disabled = true;
                    this.textContent = 'Optimizing...';
                    
                    fetch('admin_maintenance_process.php?action=optimize_database')
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                alert('Database optimization completed!\n\nTables optimized: ' + data.tables_optimized);
                                loadSystemStatus();
                            } else {
                                alert('Error: ' + data.message);
                            }
                        })
                        .catch(err => {
                            console.error(err);
                            alert('Error optimizing database');
                        })
                        .finally(() => {
                            this.disabled = false;
                            this.innerHTML = '<span class="material-icons" style="vertical-align: middle;">tune</span> Optimize Database';
                        });
                }
            });

            // Clear cache
            document.getElementById('clearCacheBtn').addEventListener('click', function() {
                if (confirm('This will clear all system cache. Continue?')) {
                    this.disabled = true;
                    this.textContent = 'Clearing...';
                    
                    fetch('admin_maintenance_process.php?action=clear_cache')
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                alert('Cache cleared!\n\n' + data.message);
                                loadSystemStatus();
                            } else {
                                alert('Error: ' + data.message);
                            }
                        })
                        .catch(err => {
                            console.error(err);
                            alert('Error clearing cache');
                        })
                        .finally(() => {
                            this.disabled = false;
                            this.innerHTML = '<span class="material-icons" style="vertical-align: middle;">delete_sweep</span> Clear System Cache';
                        });
                }
            });

            // ========== BACKUP MANAGEMENT ==========

            // Load backup settings
            function loadBackupSettings() {
                fetch('admin_maintenance_process.php?action=get_backup_settings')
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById('backup_frequency').value = data.backup_frequency;
                            document.getElementById('lastBackupTime').textContent = data.backup_last_run;
                        }
                    })
                    .catch(err => console.error('Error loading backup settings:', err));
            }

            // Load backups list
            function loadBackupsList() {
                fetch('admin_maintenance_process.php?action=list_backups')
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            const backupsList = document.getElementById('backupsList');
                            if (data.backups.length === 0) {
                                backupsList.innerHTML = '<p style="text-align: center; color: var(--muted);">No backups yet</p>';
                            } else {
                                let html = '<table style="width: 100%; font-size: 0.9em;">';
                                html += '<thead><tr style="border-bottom: 2px solid var(--border-color);"><th style="text-align: left; padding: 8px;">File</th><th style="text-align: left; padding: 8px;">Size</th><th style="text-align: left; padding: 8px;">Date</th></tr></thead>';
                                html += '<tbody>';
                                data.backups.forEach(backup => {
                                    html += '<tr style="border-bottom: 1px solid var(--border-color);">';
                                    html += '<td style="padding: 8px; word-break: break-all;">' + backup.filename + '</td>';
                                    html += '<td style="padding: 8px;">' + backup.size + '</td>';
                                    html += '<td style="padding: 8px; white-space: nowrap;">' + backup.date + '</td>';
                                    html += '</tr>';
                                });
                                html += '</tbody></table>';
                                backupsList.innerHTML = html;
                            }
                        }
                    })
                    .catch(err => console.error('Error loading backups:', err));
            }

            // Create backup
            document.getElementById('createBackupBtn').addEventListener('click', function() {
                if (confirm('Create a database backup now?')) {
                    this.disabled = true;
                    this.textContent = 'Creating backup...';
                    
                    fetch('admin_maintenance_process.php?action=create_backup')
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                alert('Backup created successfully!\n\nFile: ' + data.filename + '\nSize: ' + data.size);
                                loadBackupsList();
                                loadBackupSettings();
                                loadSystemStatus();
                            } else {
                                alert('Error: ' + data.message);
                            }
                        })
                        .catch(err => {
                            console.error(err);
                            alert('Error creating backup');
                        })
                        .finally(() => {
                            this.disabled = false;
                            this.innerHTML = '<span class="material-icons" style="vertical-align: middle;">cloud_upload</span> Create Backup Now';
                        });
                }
            });

            // Save backup frequency
            document.getElementById('backup_frequency').addEventListener('change', function() {
                fetch('admin_maintenance_process.php?action=save_backup_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ backup_frequency: this.value })
                })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            alert('Backup frequency updated');
                        }
                    })
                    .catch(err => console.error('Error saving backup settings:', err));
            });

            // Initial loads
            loadSettings();
            loadSystemStatus();
            loadBackupSettings();
            loadBackupsList();
        });
    </script>

</body>

</html>