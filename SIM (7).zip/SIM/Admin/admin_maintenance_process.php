<?php
session_start();

if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once '../db_connect.php';

$action = $_GET['action'] ?? '';

// ============================================
// BACKUP MANAGEMENT
// ============================================

if ($action === 'get_backup_settings') {
    try {
        $stmt = $conn->prepare("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('backup_frequency', 'backup_last_run')");
        $stmt->execute();
        $result = $stmt->get_result();
        $settings = [];
        while ($row = $result->fetch_assoc()) {
            $settings[$row['setting_key']] = $row['setting_value'];
        }

        echo json_encode([
            'success' => true,
            'backup_frequency' => $settings['backup_frequency'] ?? 'weekly',
            'backup_last_run' => $settings['backup_last_run'] ?? 'Never'
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

elseif ($action === 'save_backup_settings') {
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        $frequency = $data['backup_frequency'] ?? 'weekly';

        // Update frequency setting
        $stmt = $conn->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
        $stmt->bind_param('sss', $key, $frequency, $frequency);
        $key = 'backup_frequency';
        $stmt->execute();

        echo json_encode(['success' => true, 'message' => 'Backup settings saved']);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

elseif ($action === 'create_backup') {
    try {
        $backup_dir = __DIR__ . '/../backups';
        
        // Create backups directory if it doesn't exist
        if (!is_dir($backup_dir)) {
            mkdir($backup_dir, 0755, true);
        }

        $backup_filename = 'fyp_backup_' . date('Y-m-d_His') . '.sql';
        $backup_path = $backup_dir . '/' . $backup_filename;

        // Get database name from connection
        $database_name = 'LASTEST_FYP';  // Default database name
        
        // Try to get actual database from connection
        $result = $conn->query("SELECT DATABASE() as db");
        if ($result) {
            $row = $result->fetch_assoc();
            if ($row && isset($row['db'])) {
                $database_name = $row['db'];
            }
        }

        // Use PHP to dump database directly via mysqldump
        $host = 'localhost';
        $user = 'root';
        $password = '';
        
        // Windows XAMPP paths
        $mysqldump_path = 'C:\\xampp\\mysql\\bin\\mysqldump.exe';
        
        // Fallback to system mysqldump if XAMPP path doesn't exist
        if (!file_exists($mysqldump_path)) {
            $mysqldump_path = 'mysqldump';
        }
        
        // Build mysqldump command - handle spaces in paths
        $cmd = '"' . $mysqldump_path . '" --user=' . escapeshellarg($user);
        if (!empty($password)) {
            $cmd .= ' --password=' . escapeshellarg($password);
        }
        $cmd .= ' --host=' . escapeshellarg($host);
        $cmd .= ' ' . escapeshellarg($database_name);
        $cmd .= ' > ' . escapeshellarg($backup_path);

        // Execute mysqldump
        $output = array();
        $return_var = null;
        exec($cmd, $output, $return_var);

        if ($return_var === 0 && file_exists($backup_path)) {
            // Update last backup time in database
            $now = date('Y-m-d H:i:s');
            $stmt = $conn->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
            $key = 'backup_last_run';
            $stmt->bind_param('sss', $key, $now, $now);
            $stmt->execute();

            $backup_size = filesize($backup_path);
            $size_mb = round($backup_size / (1024 * 1024), 2);

            echo json_encode([
                'success' => true,
                'message' => 'Backup created successfully',
                'filename' => $backup_filename,
                'size' => $size_mb . ' MB',
                'timestamp' => $now
            ]);
        } else {
            $error_msg = 'Failed to create backup.';
            if (!empty($output)) {
                $error_msg .= ' Details: ' . implode(' | ', $output);
            }
            throw new Exception($error_msg);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

elseif ($action === 'list_backups') {
    try {
        $backup_dir = __DIR__ . '/../backups';
        $backups = [];

        if (is_dir($backup_dir)) {
            $files = array_reverse(scandir($backup_dir));
            foreach ($files as $file) {
                if (substr($file, 0, 1) === '.') continue;
                if (strpos($file, 'fyp_backup_') === 0 && substr($file, -4) === '.sql') {
                    $path = $backup_dir . '/' . $file;
                    $backups[] = [
                        'filename' => $file,
                        'size' => round(filesize($path) / (1024 * 1024), 2) . ' MB',
                        'date' => date('Y-m-d H:i:s', filemtime($path))
                    ];
                }
            }
        }

        echo json_encode(['success' => true, 'backups' => $backups]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

// ============================================
// CACHE MANAGEMENT
// ============================================

elseif ($action === 'clear_cache') {
    try {
        $cache_dir = __DIR__ . '/../cache';
        $cleared = 0;

        if (is_dir($cache_dir)) {
            $files = scandir($cache_dir);
            foreach ($files as $file) {
                if ($file !== '.' && $file !== '..') {
                    $path = $cache_dir . '/' . $file;
                    if (is_file($path) && unlink($path)) {
                        $cleared++;
                    }
                }
            }
        }

        // Also clear PHP session cache if using file-based sessions
        session_write_close();

        echo json_encode([
            'success' => true,
            'message' => "Cache cleared ({$cleared} files removed)",
            'files_cleared' => $cleared
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

// ============================================
// DATABASE MAINTENANCE
// ============================================

elseif ($action === 'optimize_database') {
    try {
        $tables = [];
        $result = $conn->query("SHOW TABLES");

        while ($row = $result->fetch_array()) {
            $table = $row[0];
            
            // Optimize table
            $conn->query("OPTIMIZE TABLE " . $table);
            
            // Analyze table
            $conn->query("ANALYZE TABLE " . $table);
            
            $tables[] = $table;
        }

        echo json_encode([
            'success' => true,
            'message' => 'Database optimization completed',
            'tables_optimized' => count($tables),
            'tables' => $tables
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

// ============================================
// SYSTEM STATUS
// ============================================

elseif ($action === 'get_system_status') {
    try {
        $status = [
            'database_size' => getDBSize($conn),
            'backup_count' => countBackups(),
            'php_version' => phpversion(),
            'server_time' => date('Y-m-d H:i:s'),
            'disk_free' => round(disk_free_space('/') / (1024 * 1024 * 1024), 2) . ' GB'
        ];

        echo json_encode(['success' => true, 'status' => $status]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}

else {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

// ============================================
// HELPER FUNCTIONS
// ============================================

function getDBSize($conn) {
    try {
        $result = $conn->query("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size FROM information_schema.tables WHERE table_schema = DATABASE()");
        $row = $result->fetch_assoc();
        return ($row['size'] ?? 0) . ' MB';
    } catch (Exception $e) {
        return 'Unknown';
    }
}

function countBackups() {
    $backup_dir = __DIR__ . '/../backups';
    if (!is_dir($backup_dir)) return 0;
    
    $count = 0;
    $files = scandir($backup_dir);
    foreach ($files as $file) {
        if (strpos($file, 'fyp_backup_') === 0 && substr($file, -4) === '.sql') {
            $count++;
        }
    }
    return $count;
}
