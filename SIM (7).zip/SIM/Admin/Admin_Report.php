<?php
session_start();if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    header("Location: ../index.php");
    exit();
}?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Admin</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="admin.css">
    <link rel="stylesheet" href="report_styles.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
</head>

<body>

    <div class="navbar">
        <h2>Admin Panel - Project Allocation</h2>
        <div class="button-group">
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>

    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Admin Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="Admin_Dashboard.php"><span class="material-icons">dashboard</span> Dashboard</a></li>
                <li><a href="Admin_UserMngm.php"><span class="material-icons">people</span> User Management</a></li>
                <li><a href="Admin_announcements.php"><span class="material-icons">campaign</span> Announcements</a></li>
                <li><a href="Admin_deadline.php"><span class="material-icons">event_note</span> Global Deadlines</a></li>
                <li><a href="Admin_allocation.php"><span class="material-icons">assignment_ind</span> Project Allocation</a></li>
                <li><a href="Admin_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <!-- <li><a href="Admin_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li> -->
                <li ><a href="Admin_Batch.php"><span class="material-icons">school</span>Batch Management</a></li>
                <li class="active"><a href="Admin_Report.php"><span class="material-icons">bar_chart</span> Reports</a></li>
                <li><a href="Admin_System.php"><span class="material-icons">settings</span> System Settings</a></li>
            </ul>
        </div>


        <main class="main-content">

            <div class="page-header">
                <h1>Reports & Analytics</h1>
                <p>Overview of the Final Year Project allocation status.</p>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <div></div>
                <button id="downloadPdfBtn" class="btn-pdf" onclick="downloadPDFReport()">
                    <span class="material-icons" style="vertical-align: middle;">download</span> Download PDF Report
                </button>
            </div>

            <div class="stat-grid">
                <div class="stat-card">
                    <h3>Total Students</h3>
                    <div class="stat-number" id="stat_students">...</div>
                </div>
                <div class="stat-card">
                    <h3>Total Supervisors</h3>
                    <div class="stat-number" id="stat_supervisors">...</div>
                </div>
                <div class="stat-card">
                    <h3>Students Assigned</h3>
                    <div class="stat-number" id="stat_assigned">...</div>
                </div>
                <div class="stat-card">
                    <h3>Pending Applications</h3>
                    <div class="stat-number" id="stat_pending_apps">...</div>
                </div>
            </div>

            
            <div class="chart-wrapper">
                <div class="card">
                    <h2>Student Assignment Overview</h2>
                    <div class="chart-container">
                        <canvas id="assignmentChart"></canvas>
                    </div>
                </div>

                <div class="card">
                    <h2>Batch Distribution</h2>
                    <div class="chart-container">
                        <canvas id="batchChart"></canvas>
                    </div>
                </div>
            </div>

            
            <div class="analysis-panel">
                <h3>📊 Key Analytics & Insights</h3>
                <div id="analysisContent">
                    <p style="text-align: center; color: var(--muted);">Loading analysis...</p>
                </div>
            </div>

            <div class="card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h2 style="margin: 0;">Supervisor Load Distribution</h2>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <label for="batchFilter" style="font-weight: 500;">Filter by Batch:</label>
                        <select id="batchFilter" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px;">
                            <option value="all">All Batches</option>
                        </select>
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="supervisorLoadChart"></canvas>
                </div>
            </div>

            
            <div class="card">
                <h2>Deadline & Supervisor Workload Analysis</h2>
                <div style="margin-bottom: 15px;">
                    <label for="deadlineFilter" style="font-weight: 500;">Filter by Batch:</label>
                    <select id="deadlineFilter" style="padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px; margin-left: 10px;">
                        <option value="all">All Batches</option>
                    </select>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 25px;">
                    <div>
                        <h3 style="margin-top: 0; color: var(--text);">Supervisor Workload by Deadline</h3>
                        <div class="chart-container">
                            <canvas id="workloadTimeline"></canvas>
                        </div>
                    </div>
                    <div>
                        <h3 style="margin-top: 0; color: var(--text);">Supervisors with Deadlines</h3>
                        <div class="chart-container">
                            <canvas id="deadlineImpactChart"></canvas>
                        </div>
                    </div>
                </div>
                <div style="margin-top: 20px;">
                    <h3 style="color: var(--text);">Upcoming Deadlines & Supervisor Impact</h3>
                    <div id="deadlineTableContainer" style="max-height: 500px; overflow-y: auto;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Deadline</th>
                                    <th>Title</th>
                                    <th>Students Affected</th>
                                    <th>Supervisors Involved</th>
                                    <th>Assigned %</th>
                                </tr>
                            </thead>
                            <tbody id="deadlineTableBody">
                                <tr><td colspan="5" style="text-align: center;">Loading...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="card">
                <h2>Supervisor Load & Capacity</h2>
                <div class="table-wrapper">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Supervisor Name</th>
                                <th>Capacity</th>
                                <th>Current Load</th>
                                <th>Available Slots</th>
                                <th style="width: 20%;">Load Percentage</th>
                            </tr>
                        </thead>
                        <tbody id="supervisorLoadBody">
                            <tr>
                                <td colspan="5" style="text-align: center;">Loading report data...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 25px; align-items: start;">

                <div class="card">
                    <h2>Assignment by Batch</h2>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Batch Year</th>
                                <th>Total Students</th>
                                <th>Assigned</th>
                                <th>% Complete</th>
                            </tr>
                        </thead>
                        <tbody id="batchStatsBody">
                            <tr>
                                <td colspan="4" style="text-align: center;">Loading...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="card">
                    <h2>Recent Application Activity</h2>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Supervisor</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="recentAppsBody">
                            <tr>
                                <td colspan="3" style="text-align: center;">Loading...</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>

    <script>
        let charts = {};
        document.addEventListener('DOMContentLoaded', function() {

                        loadBatchOptions();

                        function fetchReportData() {
                fetch('admin_report_process.php?action=fetch_report_data')
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Network response was not ok');
                        }
                        return response.json();
                    })
                    .then(data => {                        renderStats(data.stats);
                        renderSupervisorLoad(data.supervisor_load);
                        renderBatchStats(data.batch_stats);
                        renderRecentApps(data.recent_apps);                        renderCharts(data);                        renderAnalysis(data);
                    })
                    .catch(error => {
                        console.error('Error fetching report data:', error);                        document.getElementById('supervisorLoadBody').innerHTML = `<tr><td colspan="5" class="error">Failed to load data.</td></tr>`;
                        document.getElementById('batchStatsBody').innerHTML = `<tr><td colspan="4" class="error">Failed to load data.</td></tr>`;
                        document.getElementById('recentAppsBody').innerHTML = `<tr><td colspan="3" class="error">Failed to load data.</td></tr>`;
                        document.getElementById('analysisContent').innerHTML = `<p style="text-align: center; color: var(--muted);">Failed to load analysis.</p>`;
                    });
            }

                        function loadBatchOptions() {
                fetch('admin_report_process.php?action=get_batch_list')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.batches.length > 0) {
                            const batchFilter = document.getElementById('batchFilter');
                            const deadlineFilter = document.getElementById('deadlineFilter');
                            
                            data.batches.forEach(batch => {
                                const option = document.createElement('option');
                                option.value = batch.batch_year;
                                option.textContent = batch.batch_year;
                                batchFilter.appendChild(option);
                                
                                const option2 = document.createElement('option');
                                option2.value = batch.batch_year;
                                option2.textContent = batch.batch_year;
                                deadlineFilter.appendChild(option2);
                            });
                        }
                    })
                    .catch(error => console.error('Error loading batches:', error));
            }

                        document.getElementById('batchFilter').addEventListener('change', function() {
                const selectedBatch = this.value;
                updateSupervisorLoadChart(selectedBatch);
            });

            document.getElementById('deadlineFilter').addEventListener('change', function() {
                const selectedBatch = this.value;
                updateDeadlineAnalysis(selectedBatch);
            });

                        function updateSupervisorLoadChart(batch) {
                const url = batch === 'all' 
                    ? 'admin_report_process.php?action=fetch_supervisor_load_by_batch&batch=all'
                    : `admin_report_process.php?action=fetch_supervisor_load_by_batch&batch=${encodeURIComponent(batch)}`;
                
                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            renderSupervisorLoadChart(data.data);
                        }
                    })
                    .catch(error => console.error('Error updating supervisor load:', error));
            }

                        function updateDeadlineAnalysis(batch) {
                const url = batch === 'all'
                    ? 'admin_report_process.php?action=fetch_deadline_workload_analysis&batch=all'
                    : `admin_report_process.php?action=fetch_deadline_workload_analysis&batch=${encodeURIComponent(batch)}`;
                
                console.log('Fetching deadline analysis from:', url);
                
                fetch(url)
                    .then(response => {
                        console.log('Response status:', response.status);
                        return response.json();
                    })
                    .then(data => {
                        console.log('Deadline analysis data:', data);
                        if (data.success) {
                            console.log('Rendering deadline analysis...');
                            renderDeadlineAnalysis(data);
                        } else {
                            console.error('API returned success=false');
                        }
                    })
                    .catch(error => console.error('Error updating deadline analysis:', error));
            }            function renderStats(stats) {
                document.getElementById('stat_students').textContent = stats.students;
                document.getElementById('stat_supervisors').textContent = stats.supervisors;
                document.getElementById('stat_assigned').textContent = stats.assigned;
                document.getElementById('stat_pending_apps').textContent = stats.pending_apps;
            }            function renderSupervisorLoadChart(data) {
                const ctx3 = document.getElementById('supervisorLoadChart');
                if (ctx3) {
                    if (charts.supervisorLoad) charts.supervisorLoad.destroy();
                    const supNames = data.map(s => s.name);
                    const supLoad = data.map(s => parseInt(s.load_count));
                    const supCapacity = data.map(s => parseInt(s.capacity));

                    charts.supervisorLoad = new Chart(ctx3, {
                        type: 'bar',
                        data: {
                            labels: supNames,
                            datasets: [
                                {
                                    label: 'Current Load',
                                    data: supLoad,
                                    backgroundColor: '#3B82F6',
                                    borderRadius: 6,
                                    borderSkipped: false
                                },
                                {
                                    label: 'Remaining Capacity',
                                    data: supCapacity.map((c, i) => c - supLoad[i]),
                                    backgroundColor: '#E5E7EB',
                                    borderRadius: 6,
                                    borderSkipped: false
                                }
                            ]
                        },
                        options: {
                            indexAxis: 'y',
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    labels: {
                                        font: { size: 12 },
                                        color: 'var(--text)',
                                        padding: 15
                                    }
                                }
                            },
                            scales: {
                                x: {
                                    stacked: true,
                                    grid: { color: 'rgba(0,0,0,0.05)' }
                                },
                                y: {
                                    stacked: true,
                                    grid: { display: false }
                                }
                            }
                        }
                    });
                }
            }            function renderDeadlineAnalysis(data) {
                console.log('renderDeadlineAnalysis called with data:', data);                if (!data || !data.deadlines) {
                    console.error('Invalid data structure:', data);
                    return;
                }
                
                const workloadData = data.deadlines.map(d => ({
                    date: d.deadline_date,
                    title: d.deadline_title,
                    students: parseInt(d.total_students_affected),
                    supervisors: parseInt(d.supervisors_affected),
                    assigned: parseInt(d.assigned_students)
                }));

                console.log('workloadData:', workloadData);

                const ctx1 = document.getElementById('workloadTimeline');
                if (ctx1) {
                    if (charts.workloadTimeline) charts.workloadTimeline.destroy();                    if (workloadData.length === 0) {
                        console.warn('No workload data available');
                        ctx1.getContext('2d').clearRect(0, 0, ctx1.width, ctx1.height);
                    } else {
                        const labels = workloadData.map(d => d.date.substring(5));
                        const studentData = workloadData.map(d => d.students);
                        const supervisorData = workloadData.map(d => d.supervisors);

                        charts.workloadTimeline = new Chart(ctx1, {
                            type: 'line',
                            data: {
                                labels: labels,
                                datasets: [
                                    {
                                        label: 'Students Affected',
                                        data: studentData,
                                        borderColor: '#3B82F6',
                                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                                        tension: 0.4,
                                        fill: true,
                                        pointBackgroundColor: '#3B82F6',
                                        pointBorderColor: '#fff',
                                        pointBorderWidth: 2,
                                        pointRadius: 5
                                    },
                                    {
                                        label: 'Supervisors Involved',
                                        data: supervisorData,
                                        borderColor: '#F59E0B',
                                        backgroundColor: 'rgba(245, 158, 11, 0.1)',
                                        tension: 0.4,
                                        fill: true,
                                        pointBackgroundColor: '#F59E0B',
                                        pointBorderColor: '#fff',
                                        pointBorderWidth: 2,
                                        pointRadius: 5
                                    }
                                ]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        labels: { font: { size: 12 }, color: 'var(--text)', padding: 15 }
                                    }
                                },
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        grid: { color: 'rgba(0,0,0,0.05)' }
                                    }
                                }
                            }
                        });
                    }
                }

                const ctx2 = document.getElementById('deadlineImpactChart');
                if (ctx2) {
                    if (charts.deadlineImpact) charts.deadlineImpact.destroy();
                    
                    console.log('supervisors data:', data.supervisors);
                    
                    const supervisorMap = {};
                    if (data.supervisors) {
                        data.supervisors.forEach(sup => {
                            supervisorMap[sup.name] = {
                                students: sup.student_count,
                                deadlines: sup.active_deadline_count,
                                capacity: sup.capacity
                            };
                        });
                    }

                    const supNames = Object.keys(supervisorMap);
                    const deadlineCounts = supNames.map(name => supervisorMap[name].deadlines);

                    console.log('supervisorMap:', supervisorMap);
                    console.log('supNames:', supNames);
                    console.log('deadlineCounts:', deadlineCounts);

                    if (supNames.length > 0) {
                        charts.deadlineImpact = new Chart(ctx2, {
                            type: 'bar',
                            data: {
                                labels: supNames,
                                datasets: [{
                                    label: 'Active Deadlines',
                                    data: deadlineCounts,
                                    backgroundColor: '#10B981',
                                    borderRadius: 6,
                                    borderSkipped: false
                                }]
                            },
                            options: {
                                indexAxis: 'y',
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        labels: { font: { size: 12 }, color: 'var(--text)', padding: 15 }
                                    }
                                },
                                scales: {
                                    x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } },
                                    y: { grid: { display: false } }
                                }
                            }
                        });
                    } else {
                        console.warn('No supervisors data available');
                    }
                }

                const tbody = document.getElementById('deadlineTableBody');
                tbody.innerHTML = '';

                if (data.deadlines.length === 0) {
                    tbody.innerHTML = '<tr><td colspan="5" style="text-align: center;">No upcoming deadlines found.</td></tr>';
                    return;
                }

                data.deadlines.forEach(deadline => {
                    const total = parseInt(deadline.total_students_affected);
                    const assigned = parseInt(deadline.assigned_students);
                    const percentage = total > 0 ? Math.round((assigned / total) * 100) : 0;

                    const tr = `
                    <tr>
                        <td>${deadline.deadline_date}</td>
                        <td><strong>${escapeHTML(deadline.deadline_title)}</strong></td>
                        <td>${total}</td>
                        <td>${escapeHTML(deadline.supervisor_names || 'N/A')}</td>
                        <td>${percentage}%</td>
                    </tr>
                    `;
                    tbody.innerHTML += tr;
                });
            }            function renderCharts(data) {
                const stats = data.stats;
                const supervisor_load = data.supervisor_load;
                const batch_stats = data.batch_stats;

                const unassigned = stats.students - stats.assigned;
                const ctx1 = document.getElementById('assignmentChart');
                if (ctx1) {
                    if (charts.assignment) charts.assignment.destroy();
                    charts.assignment = new Chart(ctx1, {
                        type: 'doughnut',
                        data: {
                            labels: ['Assigned', 'Unassigned'],
                            datasets: [{
                                data: [stats.assigned, unassigned],
                                backgroundColor: ['#10B981', '#E5E7EB'],
                                borderColor: ['#059669', '#D1D5DB'],
                                borderWidth: 2
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            plugins: {
                                legend: {
                                    position: 'bottom',
                                    labels: {
                                        font: { size: 12 },
                                        color: 'var(--text)',
                                        padding: 15
                                    }
                                }
                            }
                        }
                    });
                }

                if (batch_stats.length > 0) {
                    const ctx2 = document.getElementById('batchChart');
                    if (ctx2) {
                        if (charts.batch) charts.batch.destroy();
                        const batchLabels = batch_stats.map(b => b.batch_year);
                        const batchTotals = batch_stats.map(b => parseInt(b.total_students));
                        const batchAssigned = batch_stats.map(b => parseInt(b.total_assigned));

                        charts.batch = new Chart(ctx2, {
                            type: 'bar',
                            data: {
                                labels: batchLabels,
                                datasets: [
                                    {
                                        label: 'Assigned',
                                        data: batchAssigned,
                                        backgroundColor: '#10B981',
                                        borderRadius: 6,
                                        borderSkipped: false
                                    },
                                    {
                                        label: 'Unassigned',
                                        data: batchTotals.map((t, i) => t - batchAssigned[i]),
                                        backgroundColor: '#FBBF24',
                                        borderRadius: 6,
                                        borderSkipped: false
                                    }
                                ]
                            },
                            options: {
                                indexAxis: 'y',
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: {
                                        labels: {
                                            font: { size: 12 },
                                            color: 'var(--text)',
                                            padding: 15
                                        }
                                    }
                                },
                                scales: {
                                    x: {
                                        stacked: true,
                                        grid: { color: 'rgba(0,0,0,0.05)' }
                                    },
                                    y: {
                                        stacked: true,
                                        grid: { display: false }
                                    }
                                }
                            }
                        });
                    }
                }

                renderSupervisorLoadChart(supervisor_load);
            }            function renderAnalysis(data) {
                const stats = data.stats;
                const supervisor_load = data.supervisor_load;
                const batch_stats = data.batch_stats;

                let analysisHTML = '';

                const completionRate = stats.students > 0 ? ((stats.assigned / stats.students) * 100).toFixed(1) : 0;
                const completionClass = completionRate >= 80 ? 'success' : (completionRate >= 50 ? 'warning' : 'critical');

                analysisHTML += `
                    <div class="analysis-item">
                        <span class="analysis-label">🎯 Overall Assignment Completion</span>
                        <span class="analysis-value ${completionClass}">${completionRate}%</span>
                    </div>
                `;

                if (supervisor_load.length > 0) {
                    const avgLoad = (supervisor_load.reduce((sum, s) => sum + parseInt(s.load_count), 0) / supervisor_load.length).toFixed(1);
                    const avgCapacity = (supervisor_load.reduce((sum, s) => sum + parseInt(s.capacity), 0) / supervisor_load.length).toFixed(1);
                    analysisHTML += `
                        <div class="analysis-item">
                            <span class="analysis-label">👨‍🏫 Average Supervisor Load</span>
                            <span class="analysis-value">${avgLoad} / ${avgCapacity}</span>
                        </div>
                    `;

                    const overloadedCount = supervisor_load.filter(s => parseInt(s.load_count) > parseInt(s.capacity)).length;
                    if (overloadedCount > 0) {
                        const overloadClass = overloadedCount > 2 ? 'critical' : 'warning';
                        analysisHTML += `
                            <div class="analysis-item">
                                <span class="analysis-label">⚠️ Supervisors Over Capacity</span>
                                <span class="analysis-value ${overloadClass}">${overloadedCount} supervisors</span>
                            </div>
                        `;
                    }

                    const totalLoad = supervisor_load.reduce((sum, s) => sum + parseInt(s.load_count), 0);
                    const totalCapacity = supervisor_load.reduce((sum, s) => sum + parseInt(s.capacity), 0);
                    const utilizationRate = totalCapacity > 0 ? ((totalLoad / totalCapacity) * 100).toFixed(1) : 0;
                    analysisHTML += `
                        <div class="analysis-item">
                            <span class="analysis-label">📈 Capacity Utilization</span>
                            <span class="analysis-value">${utilizationRate}%</span>
                        </div>
                    `;
                }

                if (batch_stats.length > 0) {
                    let batchAnalysisHTML = '<div style="margin-top: 10px;"><strong>Batch Details:</strong><div class="stats-row">';
                    batch_stats.forEach(batch => {
                        const total = parseInt(batch.total_students);
                        const assigned = parseInt(batch.total_assigned);
                        const rate = total > 0 ? ((assigned / total) * 100).toFixed(0) : 0;
                        batchAnalysisHTML += `
                            <div class="mini-stat">
                                <div class="mini-stat-label">${batch.batch_year}</div>
                                <div class="mini-stat-value">${rate}%</div>
                                <div class="mini-stat-label">${assigned}/${total}</div>
                            </div>
                        `;
                    });
                    batchAnalysisHTML += '</div></div>';
                    analysisHTML += batchAnalysisHTML;
                }

                document.getElementById('analysisContent').innerHTML = analysisHTML;
            }            function renderSupervisorLoad(data) {
                const tbody = document.getElementById('supervisorLoadBody');
                tbody.innerHTML = '';
                if (data.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="5" style="text-align: center;">No supervisors found.</td></tr>`;
                    return;
                }

                data.forEach(row => {
                    const capacity = parseInt(row.capacity, 10);
                    const load_count = parseInt(row.load_count, 10);
                    const available = capacity - load_count;
                    const percentage = (capacity > 0) ? (load_count / capacity) * 100 : 0;

                    let bar_class = '';
                    if (percentage >= 100) bar_class = 'full';
                    else if (percentage >= 75) bar_class = 'high';

                    const tr = `
                <tr>
                    <td><strong>${escapeHTML(row.name)}</strong></td>
                    <td>${capacity}</td>
                    <td>${load_count}</td>
                    <td>${available}</td>
                    <td>
                        <div class="progress-bar">
                            <div class="progress-bar-inner ${bar_class}" style="width: ${Math.min(100, percentage)}%;"></div>
                        </div>
                    </td>
                </tr>
            `;
                    tbody.innerHTML += tr;
                });
            }            function renderBatchStats(data) {
                const tbody = document.getElementById('batchStatsBody');
                tbody.innerHTML = '';

                if (data.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center;">No student batches found.</td></tr>`;
                    return;
                }

                data.forEach(row => {
                    const total = parseInt(row.total_students, 10);
                    const assigned = parseInt(row.total_assigned, 10);
                    const percentage = (total > 0) ? (assigned / total) * 100 : 0;

                    const tr = `
                <tr>
                    <td><strong>${escapeHTML(row.batch_year)}</strong></td>
                    <td>${total}</td>
                    <td>${assigned}</td>
                    <td>${Math.round(percentage)}%</td>
                </tr>
            `;
                    tbody.innerHTML += tr;
                });
            }            function renderRecentApps(data) {
                const tbody = document.getElementById('recentAppsBody');
                tbody.innerHTML = '';

                if (data.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="3" style="text-align: center;">No application activity found.</td></tr>`;
                    return;
                }

                data.forEach(row => {
                    let status_class = '';
                    if (row.status === 'confirmed') status_class = 'active';
                    if (row.status === 'rejected' || row.status === 'cancelled') status_class = 'inactive';
                    if (row.status === 'pending') status_class = 'pending';

                    const tr = `
                <tr>
                    <td>${escapeHTML(row.student_name)}</td>
                    <td>${escapeHTML(row.supervisor_name)}</td>
                    <td>
                        <span class="status ${status_class}">
                            ${escapeHTML(row.status)}
                        </span>
                    </td>
                </tr>
            `;
                    tbody.innerHTML += tr;
                });
            }

                        function escapeHTML(str) {
                return str.replace(/[&<>"']/g, function(m) {
                    return {
                        '&': '&amp;',
                        '<': '&lt;',
                        '>': '&gt;',
                        '"': '&quot;',
                        "'": '&#39;'
                    } [m];
                });
            }

                        window.downloadPDFReport = function() {
                const selectedBatch = document.getElementById('batchFilter').value;
                const url = selectedBatch === 'all'
                    ? 'admin_report_process.php?action=generate_pdf_report&batch=all'
                    : `admin_report_process.php?action=generate_pdf_report&batch=${encodeURIComponent(selectedBatch)}`;
                
                window.open(url, '_blank');
            };

                        fetchReportData();            updateDeadlineAnalysis('all');
        });
    </script>

</body>

</html>