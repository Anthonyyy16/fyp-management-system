<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

require_once '../db_connect.php';

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'fetch_all':
        handleFetchAll($conn);
        break;
    case 'upload':
        handleUpload($conn);
        break;
    case 'update':
        handleUpdate($conn);
        break;
    case 'delete':
        handleDelete($conn);
        break;
    case 'download':
        handleDownload($conn);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
}

function handleFetchAll($conn) {
    $files = [];
    $sql = "SELECT * FROM downloadable_files ORDER BY upload_date DESC";
    $result = $conn->query($sql);
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $files[] = $row;
        }
        echo json_encode(['success' => true, 'files' => $files]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to fetch files']);
    }
}

function handleUpload($conn) {
    // Validate inputs
    $file_name = trim($_POST['file_name'] ?? '');
    $category = $_POST['category'] ?? '';
    $description = $_POST['description'] ?? '';
    $batch_year = !empty($_POST['batch_year']) ? $_POST['batch_year'] : null;
    
    if (empty($file_name) || empty($category)) {
        echo json_encode(['success' => false, 'message' => 'File name and category are required']);
        return;
    }
    
    // Check if file was uploaded
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'message' => 'No file uploaded or upload error']);
        return;
    }
    
    $file = $_FILES['file'];
    $file_size = $file['size'];
    $file_tmp = $file['tmp_name'];
    $file_original_name = $file['name'];
    $original_extension = strtolower(pathinfo($file_original_name, PATHINFO_EXTENSION));
    
    // Validate file size (10MB max)
    if ($file_size > 10 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'File size exceeds 10MB limit']);
        return;
    }
    
    // Validate file type
    $allowed_extensions = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'zip', 'jpg', 'png', 'jpeg'];
    
    if (!in_array($original_extension, $allowed_extensions)) {
        echo json_encode(['success' => false, 'message' => 'File type not allowed']);
        return;
    }
    
    // Clean filename and ensure it has correct extension
    $clean_filename = preg_replace('/\\.[^.\\s]{3,4}$/', '', $file_name);
    $final_filename = $clean_filename . '.' . $original_extension;
    
    // Create uploads directory if it doesn't exist
    $upload_dir = '../uploads/documents/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    // Generate unique filename but preserve extension
    $unique_filename = uniqid() . '_' . time() . '.' . $original_extension;
    $file_path = $upload_dir . $unique_filename;
    
    // Move uploaded file
    if (!move_uploaded_file($file_tmp, $file_path)) {
        echo json_encode(['success' => false, 'message' => 'Failed to save file']);
        return;
    }
    
    // Insert into database
    $sql = "INSERT INTO downloadable_files (file_name, file_path, category, description, batch_year, file_size, upload_date) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())";
    
    if ($stmt = $conn->prepare($sql)) {
        $relative_path = 'uploads/documents/' . $unique_filename;
        $stmt->bind_param("sssssi", $final_filename, $relative_path, $category, $description, $batch_year, $file_size);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'File uploaded successfully']);
        } else {
            // Delete file if database insert fails
            unlink($file_path);
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $stmt->error]);
        }
        $stmt->close();
    } else {
        unlink($file_path);
        echo json_encode(['success' => false, 'message' => 'Database prepare error']);
    }
}

function handleUpdate($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $id = $data['id'] ?? 0;
    $file_name = $data['file_name'] ?? '';
    $category = $data['category'] ?? '';
    $description = $data['description'] ?? '';
    $batch_year = !empty($data['batch_year']) ? $data['batch_year'] : null;
    
    if (empty($id) || empty($file_name) || empty($category)) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        return;
    }
    
    $sql = "UPDATE downloadable_files SET file_name = ?, category = ?, description = ?, batch_year = ? WHERE id = ?";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssssi", $file_name, $category, $description, $batch_year, $id);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'File updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Update failed: ' . $stmt->error]);
        }
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Database prepare error']);
    }
}

function handleDelete($conn) {
    $data = json_decode(file_get_contents('php://input'), true);
    $id = $data['id'] ?? 0;
    
    if (empty($id)) {
        echo json_encode(['success' => false, 'message' => 'Invalid file ID']);
        return;
    }
    
    // Get file path before deleting
    $sql = "SELECT file_path FROM downloadable_files WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            $file_path = '../' . $row['file_path'];
            
            // Delete from database
            $delete_sql = "DELETE FROM downloadable_files WHERE id = ?";
            if ($delete_stmt = $conn->prepare($delete_sql)) {
                $delete_stmt->bind_param("i", $id);
                
                if ($delete_stmt->execute()) {
                    // Delete physical file
                    if (file_exists($file_path)) {
                        unlink($file_path);
                    }
                    echo json_encode(['success' => true, 'message' => 'File deleted successfully']);
                } else {
                    echo json_encode(['success' => false, 'message' => 'Delete failed: ' . $delete_stmt->error]);
                }
                $delete_stmt->close();
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'File not found']);
        }
        $stmt->close();
    }
}

function handleDownload($conn) {
    $id = $_GET['id'] ?? 0;
    
    if (empty($id)) {
        die('Invalid file ID');
    }
    
    // Get file info
    $sql = "SELECT file_path, file_name FROM downloadable_files WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            $file_path = '../' . $row['file_path'];
            $file_name = $row['file_name'];
            
            if (!file_exists($file_path)) {
                die('File not found on server');
            }
            
            // Get file extension from actual file
            $file_extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
            
            // Ensure filename has correct extension
            $base_name = pathinfo($file_name, PATHINFO_FILENAME);
            $download_filename = $base_name . '.' . $file_extension;
            
            // Update download count
            $update_sql = "UPDATE downloadable_files SET download_count = download_count + 1 WHERE id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("i", $id);
            $update_stmt->execute();
            $update_stmt->close();
            
            // Set proper MIME types
            $mime_types = [
                'pdf' => 'application/pdf',
                'doc' => 'application/msword',
                'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'xls' => 'application/vnd.ms-excel',
                'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'ppt' => 'application/vnd.ms-powerpoint',
                'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                'zip' => 'application/zip',
                'jpg' => 'image/jpeg',
                'jpeg' => 'image/jpeg',
                'png' => 'image/png',
                'txt' => 'text/plain',
            ];
            
            // Clear output buffer
            while (ob_get_level()) {
                ob_end_clean();
            }
            
            // Set headers
            header('Content-Type: ' . ($mime_types[$file_extension] ?? 'application/octet-stream'));
            header('Content-Disposition: attachment; filename="' . $download_filename . '"');
            header('Content-Length: ' . filesize($file_path));
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Expires: 0');
            
            // Output file
            readfile($file_path);
            exit;
            
        } else {
            die('File record not found');
        }
        $stmt->close();
    }
}
?>