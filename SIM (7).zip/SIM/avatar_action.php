<?php
/**
 * avatar_action.php
 * Handles avatar upload, validation, and database updates for all user roles
 */

session_start();
include 'db_connect.php';

// Check if user is authenticated
if (!isset($_SESSION['loggedin']) || !$_SESSION['loggedin']) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Get user info from session
$user_id = $_SESSION['id'] ?? $_SESSION['user_id'];
$action = $_GET['action'] ?? $_POST['action'] ?? '';
// Allow getting another user's avatar (for viewing supervisor/student avatars)
$target_user_id = $_GET['user_id'] ?? $user_id;

if (empty($user_id)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'User ID not found']);
    exit;
}

try {
    switch ($action) {
        case 'upload':
            handleAvatarUpload($conn, $user_id);
            break;

        case 'get_avatar':
            getAvatarPath($conn, $target_user_id);
            break;

        case 'delete':
            deleteAvatar($conn, $user_id);
            break;

        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

/**
 * Handle avatar file upload
 */
function handleAvatarUpload($conn, $user_id) {
    // Check if file was uploaded
    if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('No file uploaded or upload error occurred');
    }

    $file = $_FILES['avatar'];
    
    // Validate file type
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime_type, $allowed_types)) {
        throw new Exception('Invalid file type. Only JPG, PNG, GIF, and WebP are allowed');
    }

    // Validate file size (max 5MB)
    $max_size = 5 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        throw new Exception('File size exceeds 5MB limit');
    }

    // Create upload directory if it doesn't exist
    $upload_dir = 'uploads/avatars/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Generate unique filename
    $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'avatar_' . $user_id . '_' . time() . '.' . $file_extension;
    $file_path = $upload_dir . $filename;

    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $file_path)) {
        throw new Exception('Failed to move uploaded file');
    }

    // Delete old avatar if exists
    deleteOldAvatar($conn, $user_id);

    // Update database
    $sql = "UPDATE users SET profile_picture = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        unlink($file_path); // Delete uploaded file if DB update fails
        throw new Exception('Database error: ' . $conn->error);
    }

    $stmt->bind_param('si', $file_path, $user_id);
    if (!$stmt->execute()) {
        unlink($file_path); // Delete uploaded file if DB update fails
        throw new Exception('Failed to update profile picture');
    }

    echo json_encode([
        'success' => true,
        'message' => 'Avatar uploaded successfully',
        'avatar_path' => $file_path
    ]);
}

/**
 * Delete old avatar file
 */
function deleteOldAvatar($conn, $user_id) {
    // Get current avatar path
    $sql = "SELECT profile_picture FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    // Delete file if it exists
    if ($user && $user['profile_picture'] && file_exists($user['profile_picture'])) {
        unlink($user['profile_picture']);
    }
}

/**
 * Get avatar path for a user
 */
function getAvatarPath($conn, $user_id) {
    $sql = "SELECT profile_picture FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception('Database error: ' . $conn->error);
    }

    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    if ($user && $user['profile_picture']) {
        echo json_encode([
            'success' => true,
            'avatar_path' => $user['profile_picture']
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No avatar found',
            'avatar_path' => null
        ]);
    }
}

/**
 * Delete avatar
 */
function deleteAvatar($conn, $user_id) {
    // Delete file
    deleteOldAvatar($conn, $user_id);

    // Update database to remove avatar path
    $sql = "UPDATE users SET profile_picture = NULL WHERE id = ?";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception('Database error: ' . $conn->error);
    }

    $stmt->bind_param('i', $user_id);
    if (!$stmt->execute()) {
        throw new Exception('Failed to delete avatar from database');
    }

    echo json_encode([
        'success' => true,
        'message' => 'Avatar deleted successfully'
    ]);
}
?>
