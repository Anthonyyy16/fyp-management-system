<?php
/**
 */

session_start();
require_once 'google_config.php';
require_once 'db_connect.php';


if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Not logged in']);
        exit;
    }
    
    $user_id = (int)$_SESSION['user_id'];
    $token_file = TOKENS_DIR . DIRECTORY_SEPARATOR . 'user_' . $user_id . '_token.json';
    
    
    if (file_exists($token_file)) {
        unlink($token_file);
        error_log('Token file deleted for user ' . $user_id);
    }
    
    
    try {
        $stmt = $conn->prepare("UPDATE users SET google_email = NULL, google_integration_enabled = 0 WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $stmt->close();
        error_log('Google authorization revoked for user ' . $user_id);
    } catch (Exception $e) {
        error_log('Error updating user record: ' . $e->getMessage());
    }
    
    echo json_encode(['success' => true, 'message' => 'Google authorization revoked']);
    exit;
}


if (isset($_GET['action']) && $_GET['action'] === 'check_status') {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['authorized' => false, 'message' => 'Not logged in']);
        exit;
    }
    
    $user_id = (int)$_SESSION['user_id'];
    $token_file = TOKENS_DIR . DIRECTORY_SEPARATOR . 'user_' . $user_id . '_token.json';
    
    if (file_exists($token_file)) {
        $token_data = json_decode(file_get_contents($token_file), true);
        
        
        if (isset($token_data['expires_at']) && time() > $token_data['expires_at']) {
            
            if (isset($token_data['refresh_token'])) {
                $new_token = refreshAccessToken($token_data['refresh_token']);
                if ($new_token) {
                    saveTokenData($user_id, $new_token);
                }
            }
        }
        
        
        $stmt = $conn->prepare("SELECT google_email FROM users WHERE id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        echo json_encode([
            'authorized' => true,
            'google_email' => $result['google_email'] ?? 'Unknown'
        ]);
    } else {
        echo json_encode(['authorized' => false, 'message' => 'No token found']);
    }
    exit;
}


if (!isset($_GET['code'])) {
    
    if (!isset($_SESSION['user_id'])) {
        http_response_code(403);
        header('Content-Type: text/html; charset=UTF-8');
        echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Google Authorization</title></head><body>';
        echo '<h1>❌ Not Logged In</h1>';
        echo '<p>Please log in first before authorizing Google Calendar.</p>';
        echo '<a href="index.php">← Back to Login</a>';
        echo '</body></html>';
        exit;
    }
    
    
    $auth_url = getGoogleAuthUrl('google_auth.php');
    
    
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html>';
    echo '<html><head>';
    echo '<meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<title>Google Calendar Authorization</title>';
    echo '<link rel="stylesheet" href="index.css">';
    echo '<style>';
    echo 'body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }';
    echo '.card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }';
    echo '.btn { background: #1976d2; color: white; padding: 12px 24px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; text-decoration: none; display: inline-block; }';
    echo '.btn:hover { background: #1565c0; }';
    echo 'h1 { color: #333; }';
    echo '.info { background: #e3f2fd; padding: 15px; border-radius: 4px; margin: 20px 0; color: #0d47a1; }';
    echo '</style>';
    echo '</head><body>';
    echo '<div class="card">';
    echo '<h1>📅 Google Calendar Authorization</h1>';
    echo '<p>To create Google Meet meetings, you need to authorize this application to access your Google Calendar.</p>';
    echo '<div class="info">';
    echo '<strong>ℹ️ What this allows:</strong><br>';
    echo '✓ Create events in your Google Calendar<br>';
    echo '✓ Generate Google Meet links<br>';
    echo '✓ Send invitations to meeting attendees';
    echo '</div>';
    echo '<p><a href="' . htmlspecialchars($auth_url) . '" class="btn">🔐 Authorize with Google</a></p>';
    echo '<p style="margin-top: 30px; font-size: 14px; color: #666;">';
    echo 'After authorization, you\'ll be redirected back to the chat page.<br>';
    echo 'This permission can be revoked anytime in your <a href="https://myaccount.google.com/permissions" target="_blank">Google Account Settings</a>.';
    echo '</p>';
    echo '</div>';
    echo '</body></html>';
    exit;
}


if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Error</title></head><body>';
    echo '<h1>❌ Error</h1>';
    echo '<p>You must be logged in to authorize Google Calendar.</p>';
    echo '<a href="index.php">← Back to Login</a>';
    echo '</body></html>';
    exit;
}


if (!isset($_GET['state']) || !isset($_SESSION['oauth_state']) || $_GET['state'] !== $_SESSION['oauth_state']) {
    http_response_code(400);
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Security Error</title></head><body>';
    echo '<h1>❌ Security Validation Failed</h1>';
    echo '<p>The OAuth state parameter does not match. This may indicate a security issue.</p>';
    echo '<p><a href="chat.php">← Back to Chat</a></p>';
    echo '</body></html>';
    error_log('OAuth state mismatch - possible CSRF attack');
    exit;
}


if (isset($_GET['error'])) {
    http_response_code(400);
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Authorization Error</title></head><body>';
    echo '<h1>❌ Authorization Failed</h1>';
    echo '<p><strong>Error:</strong> ' . htmlspecialchars($_GET['error']) . '</p>';
    if (isset($_GET['error_description'])) {
        echo '<p><strong>Details:</strong> ' . htmlspecialchars($_GET['error_description']) . '</p>';
    }
    echo '<p><a href="google_auth.php">← Try Again</a> | <a href="chat.php">← Back to Chat</a></p>';
    echo '</body></html>';
    error_log('OAuth error: ' . $_GET['error']);
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$auth_code = $_GET['code'] ?? null;

if (!$auth_code) {
    http_response_code(400);
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Error</title></head><body>';
    echo '<h1>❌ Authorization Code Missing</h1>';
    echo '<p>No authorization code received from Google.</p>';
    echo '<p><a href="google_auth.php">← Try Again</a></p>';
    echo '</body></html>';
    exit;
}

try {
    
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost:8000';
    $redirect_uri = $protocol . '://' . $host . '/google_auth.php';
    
    
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_POSTFIELDS => http_build_query([
            'code' => $auth_code,
            'client_id' => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'redirect_uri' => $redirect_uri,
            'grant_type' => 'authorization_code',
        ], '', '&', PHP_QUERY_RFC3986),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/x-www-form-urlencoded',
        ],
    ]);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);
    
    if ($response === false || $curl_error) {
        throw new Exception('cURL Error: ' . $curl_error);
    }
    
    if ($http_code !== 200) {
        $error_data = json_decode($response, true);
        $error_msg = $error_data['error_description'] ?? 'Unknown error';
        throw new Exception('Failed to exchange authorization code (HTTP ' . $http_code . '): ' . $error_msg);
    }
    
    $token_data = json_decode($response, true);
    
    if (!isset($token_data['access_token'])) {
        throw new Exception('No access token in response: ' . json_encode($token_data));
    }
    
    
    $token_data['expires_at'] = time() + ($token_data['expires_in'] ?? 3600);
    
    
    saveTokenData($user_id, $token_data);
    
    
    $ch = curl_init('https://www.googleapis.com/userinfo/v2/me');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $token_data['access_token'],
        ],
    ]);
    
    $userinfo_response = curl_exec($ch);
    curl_close($ch);
    
    $userinfo = json_decode($userinfo_response, true);
    
    
    if (isset($userinfo['email'])) {
        $stmt = $conn->prepare("UPDATE users SET google_email = ?, google_integration_enabled = 1 WHERE id = ?");
        $stmt->bind_param('si', $userinfo['email'], $user_id);
        $stmt->execute();
        $stmt->close();
    }
    
    
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html>';
    echo '<html><head>';
    echo '<meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<title>Authorization Successful</title>';
    echo '<style>';
    echo 'body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }';
    echo '.success { background: #d4edda; padding: 30px; border-radius: 8px; border-left: 4px solid #28a745; text-align: center; }';
    echo 'h1 { color: #155724; }';
    echo 'p { color: #0c5460; }';
    echo '.spinner { border: 4px solid #f3f3f3; border-top: 4px solid #28a745; border-radius: 50%; width: 40px; height: 40px; animation: spin 1s linear infinite; margin: 20px auto; }';
    echo '@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }';
    echo '</style>';
    echo '</head><body>';
    echo '<div class="success">';
    echo '<h1>✓ Authorization Successful!</h1>';
    echo '<p>Your Google Calendar has been connected.</p>';
    echo '<p style="font-size: 14px; margin-top: 20px;">Redirecting back to chat...</p>';
    echo '<div class="spinner"></div>';
    echo '</div>';
    echo '<script>';
    echo 'setTimeout(() => { window.location.href = "chat.php"; }, 2000);';
    echo '</script>';
    echo '</body></html>';
    
} catch (Exception $e) {
    error_log('Google OAuth error: ' . $e->getMessage());
    
    
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!DOCTYPE html>';
    echo '<html><head>';
    echo '<meta charset="UTF-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<title>Authorization Failed</title>';
    echo '<style>';
    echo 'body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }';
    echo '.error { background: #f8d7da; padding: 30px; border-radius: 8px; border-left: 4px solid #f5c6cb; }';
    echo 'h1 { color: #721c24; }';
    echo 'p { color: #721c24; }';
    echo '.btn { background: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }';
    echo '</style>';
    echo '</head><body>';
    echo '<div class="error">';
    echo '<h1>❌ Authorization Failed</h1>';
    echo '<p><strong>Error:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>';
    echo '<p>Please try again or contact support if the problem persists.</p>';
    echo '<a href="google_auth.php" class="btn">← Try Again</a> ';
    echo '<a href="chat.php" class="btn" style="background: #6c757d;">← Back to Chat</a>';
    echo '</div>';
    echo '</body></html>';
}
?>
