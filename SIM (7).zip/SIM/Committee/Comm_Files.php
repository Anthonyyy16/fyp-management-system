<?php
session_start();

if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    header("Location: ../index.php");
    exit();
}
require_once '../db_connect.php';

// Fetch categories for filter
$categories = ['Documentation', 'Report Template', 'Guidelines', 'Forms', 'Others'];

// Fetch available batch years from database
$batch_years = [];
$batch_query = "SELECT DISTINCT batch_year FROM projects WHERE batch_year IS NOT NULL AND batch_year != '' ORDER BY batch_year DESC";
$batch_result = $conn->query($batch_query);

if ($batch_result && $batch_result->num_rows > 0) {
    while ($row = $batch_result->fetch_assoc()) {
        $batch_years[] = $row['batch_year'];
    }
}

// If no batches found in projects, try fetching from students table
if (empty($batch_years)) {
    $batch_query = "SELECT DISTINCT batch_year FROM students WHERE batch_year IS NOT NULL AND batch_year != '' ORDER BY batch_year DESC";
    $batch_result = $conn->query($batch_query);

    if ($batch_result && $batch_result->num_rows > 0) {
        while ($row = $batch_result->fetch_assoc()) {
            $batch_years[] = $row['batch_year'];
        }
    }
}

// If still no batches, try fetching from downloadable_files table itself
if (empty($batch_years)) {
    $batch_query = "SELECT DISTINCT batch_year FROM downloadable_files WHERE batch_year IS NOT NULL AND batch_year != '' ORDER BY batch_year DESC";
    $batch_result = $conn->query($batch_query);

    if ($batch_result && $batch_result->num_rows > 0) {
        while ($row = $batch_result->fetch_assoc()) {
            $batch_years[] = $row['batch_year'];
        }
    }
}

// If still empty, provide some default recent years
if (empty($batch_years)) {
    $current_year = date('Y');
    for ($year = $current_year - 2; $year <= $current_year + 1; $year++) {
        $next_year = $year + 1;
        $batch_years[] = $year . '/' . $next_year;
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Management - FYP System</title>
    <link rel="stylesheet" href="../index.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        .file-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .file-card {
            background: var(--card);
            border-radius: var(--radius);
            padding: 20px;
            box-shadow: var(--shadow);
            transition: all 0.3s ease;
            animation: fadeInUp 0.4s ease;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }

            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .file-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        }

        .file-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 15px;
            font-size: 32px;
            color: white;
        }

        .file-icon.pdf {
            background: linear-gradient(135deg, #f44336, #e91e63);
        }

        .file-icon.doc {
            background: linear-gradient(135deg, #2196F3, #1976D2);
        }

        .file-icon.xls {
            background: linear-gradient(135deg, #4CAF50, #388E3C);
        }

        .file-icon.img {
            background: linear-gradient(135deg, #FF9800, #F57C00);
        }

        .file-icon.other {
            background: linear-gradient(135deg, #9E9E9E, #616161);
        }

        .file-info h4 {
            margin: 0 0 8px 0;
            color: var(--text);
            font-size: 1.1rem;
        }

        .file-meta {
            font-size: 0.85rem;
            color: var(--muted);
            margin: 5px 0;
        }

        .file-category {
            display: inline-block;
            padding: 4px 12px;
            background: var(--secondary);
            color: white;
            border-radius: 12px;
            font-size: 0.75rem;
            margin: 10px 0;
        }

        .file-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }

        .file-actions button {
            flex: 1;
            padding: 8px;
            font-size: 0.9rem;
        }

        .upload-section {
            background: var(--card);
            padding: 30px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            margin-bottom: 30px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .form-full {
            grid-column: 1 / -1;
        }

        .file-upload-area {
            border: 2px dashed var(--border-color, #ddd);
            border-radius: var(--radius);
            padding: 30px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .file-upload-area.error {
            border-color: #f44336;
            animation: shake 0.5s ease;
        }

        @keyframes shake {

            0%,
            100% {
                transform: translateX(0);
            }

            10%,
            30%,
            50%,
            70%,
            90% {
                transform: translateX(-5px);
            }

            20%,
            40%,
            60%,
            80% {
                transform: translateX(5px);
            }
        }

        .file-upload-area::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(14, 74, 138, 0.05), rgba(14, 74, 138, 0.1));
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .file-upload-area:hover::before,
        .file-upload-area.dragover::before {
            opacity: 1;
        }

        .file-upload-area:hover {
            border-color: var(--primary);
            transform: scale(1.01);
        }

        .file-upload-area.dragover {
            border-color: var(--primary);
            background: rgba(14, 74, 138, 0.05);
            border-style: solid;
        }

        .filter-section {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .filter-section input,
        .filter-section select {
            padding: 10px 15px;
            border: 1px solid var(--border-color, #ddd);
            border-radius: var(--radius);
            font-size: 0.95rem;
        }

        .stats-bar {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .stat-item {
            background: var(--card);
            padding: 15px 25px;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            animation: scaleIn 0.4s ease;
        }

        @keyframes scaleIn {
            from {
                opacity: 0;
                transform: scale(0.9);
            }

            to {
                opacity: 1;
                transform: scale(1);
            }
        }

        .stat-item h3 {
            margin: 0;
            color: var(--primary);
            font-size: 1.8rem;
        }

        .stat-item p {
            margin: 5px 0 0 0;
            color: var(--muted);
            font-size: 0.9rem;
        }

        .notification-badge-wrapper {
            position: relative;
            display: inline-block;
        }

        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #DC2626;
            color: white;
            font-size: 10px;
            font-weight: bold;
            padding: 2px 6px;
            border-radius: 50%;
            display: block;
            z-index: 10;
        }

        /* Enhanced Notification Styles */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: white;
            padding: 16px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            display: flex;
            align-items: center;
            gap: 12px;
            z-index: 10000;
            transform: translateX(400px);
            opacity: 0;
            transition: all 0.3s ease;
            min-width: 300px;
            max-width: 450px;
        }

        .notification.show {
            transform: translateX(0);
            opacity: 1;
        }

        .notification-success {
            border-left: 4px solid #4CAF50;
        }

        .notification-success .material-icons {
            color: #4CAF50;
        }

        .notification-error {
            border-left: 4px solid #f44336;
        }

        .notification-error .material-icons {
            color: #f44336;
        }

        .notification-info {
            border-left: 4px solid #2196F3;
        }

        .notification-info .material-icons {
            color: #2196F3;
        }

        .notification span:not(.material-icons) {
            flex: 1;
            font-size: 0.95rem;
            color: #333;
        }

        /* Loading Overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            backdrop-filter: blur(4px);
        }

        .loading-spinner {
            background: white;
            padding: 40px;
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        }

        .spinner {
            width: 50px;
            height: 50px;
            margin: 0 auto 20px;
            border: 4px solid #f3f3f3;
            border-top: 4px solid var(--primary, #0E4A8A);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        .loading-spinner p {
            margin: 0;
            color: #555;
            font-size: 1rem;
        }

        /* Enhanced Confirmation Modal */
        .confirm-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9998;
            backdrop-filter: blur(4px);
        }

        .confirm-content {
            background: white;
            padding: 30px;
            border-radius: 12px;
            max-width: 450px;
            width: 90%;
            text-align: center;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        }

        .warning-icon {
            font-size: 64px;
            color: #ff9800;
            margin-bottom: 15px;
        }

        .confirm-content h3 {
            margin: 0 0 15px 0;
            color: #333;
        }

        .confirm-content p {
            margin: 0 0 25px 0;
            color: #666;
            line-height: 1.5;
        }

        .confirm-content .form-buttons {
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        #filePreview {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            animation: slideDown 0.3s ease;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                max-height: 0;
            }

            to {
                opacity: 1;
                max-height: 100px;
            }
        }

        #filePreview strong {
            color: var(--primary);
        }

        .no-results-message {
            animation: fadeIn 0.3s ease;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
            }

            to {
                opacity: 1;
            }
        }

        /* Batch Year Styles */
        .batch-badge {
            display: inline-block;
            padding: 4px 10px;
            background: var(--primary);
            color: white;
            border-radius: 12px;
            font-size: 0.75rem;
            margin: 5px 0;
            font-weight: 500;
        }

        .batch-all {
            background: #6B7280;
        }

        .file-meta-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 8px 0;
        }

        .file-tags {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        /* Custom Alert Modal base */
        #alertModal {
            position: fixed;
            z-index: 999999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.45);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #alertModal .modal-content {
            background: #fff;
            border-radius: 12px;
            animation: popupFade 0.25s ease-out;
        }

        @keyframes popupFade {
            from {
                transform: scale(0.85);
                opacity: 0;
            }

            to {
                transform: scale(1);
                opacity: 1;
            }
        }

        @media (max-width: 768px) {
            .notification {
                right: 10px;
                left: 10px;
                min-width: auto;
                max-width: none;
            }

            .confirm-content {
                padding: 20px;
                width: 95%;
            }

            .confirm-content .form-buttons {
                flex-direction: column;
            }

            .confirm-content .form-buttons button {
                width: 100%;
            }

            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <div class="navbar">
        <h2>FYP System - File Management</h2>
        <div class="button-group">
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>

    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Committee Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li><a href="Comm_Dashboard.php"><span class="material-icons">dashboard</span> Dashboard</a></li>
                <li><a href="Comm_Announcements.php"><span class="material-icons">campaign</span> Announcements</a></li>
                <li><a href="Comm_Deadline.php"><span class="material-icons">event_note</span> Global Deadlines</a></li>
                <li><a href="Comm_Allocation.php"><span class="material-icons">assignment_ind</span> Project Allocation</a></li>
                <li class="active"><a href="Comm_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <li><a href="Comm_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="content-header">
                <h1>Manage File Management</h1>
                <p>Upload and manage downloadable files for specific student batches</p>
            </div>

            <!-- Statistics -->
            <div class="stats-bar">
                <div class="stat-item">
                    <h3 id="totalFiles">0</h3>
                    <p>Total Files</p>
                </div>
                <div class="stat-item">
                    <h3 id="totalDownloads">0</h3>
                    <p>Total Downloads</p>
                </div>
                <div class="stat-item">
                    <h3 id="totalSize">0 MB</h3>
                    <p>Storage Used</p>
                </div>
            </div>

            <!-- Upload Section -->
            <div class="upload-section">
                <h3><span class="material-icons">cloud_upload</span> Upload New File</h3>
                <form id="uploadForm" enctype="multipart/form-data">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="fileName">File Name *</label>
                            <input type="text" id="fileName" name="file_name" required placeholder="e.g., FYP Guidelines 2025">
                        </div>
                        <div class="form-group">
                            <label for="fileCategory">Category *</label>
                            <select id="fileCategory" name="category" required>
                                <option value="">-- Select Category --</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="batchYear">Batch Year</label>
                            <select id="batchYear" name="batch_year">
                                <option value="">All Batches (General)</option>
                                <?php foreach ($batch_years as $year): ?>
                                    <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small style="color: var(--muted); font-size: 0.85rem;">Leave empty for general files accessible to all</small>
                        </div>
                        <div class="form-group form-full">
                            <label for="fileDescription">Description</label>
                            <textarea id="fileDescription" name="description" rows="3" placeholder="Brief description of the file"></textarea>
                        </div>
                        <div class="form-group form-full">
                            <label>File Upload *</label>
                            <div class="file-upload-area" id="fileUploadArea">
                                <span class="material-icons" style="font-size: 48px; color: var(--primary);">cloud_upload</span>
                                <p>Drag & drop file here or click to browse</p>
                                <p style="font-size: 0.85rem; color: var(--muted);">Max file size: 10MB</p>
                                <input type="file" id="fileInput" name="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.zip,.jpg,.png" style="display: none;" required>
                            </div>
                            <div id="filePreview" style="margin-top: 10px; display: none;">
                                <p><strong>Selected:</strong> <span id="selectedFileName"></span></p>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn primary" style="margin-top: 20px;">
                        <span class="material-icons">upload</span> Upload File
                    </button>
                </form>
            </div>

            <!-- Filter Section -->
            <div class="card">
                <h3>Manage Files</h3>
                <div class="filter-section">
                    <input type="text" id="searchInput" placeholder="Search files..." style="flex: 1; min-width: 200px;">
                    <select id="categoryFilter">
                        <option value="">All Categories</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select id="batchYearFilter">
                        <option value="">All Batches</option>
                        <option value="general">General Files</option>
                        <?php foreach ($batch_years as $year): ?>
                            <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                        <?php endforeach; ?>
                    </select>

                    <button class="btn secondary" onclick="resetFilters()">
                        <span class="material-icons">refresh</span> Reset
                    </button>
                </div>

                <!-- Files Grid -->
                <div class="file-grid" id="filesGrid">
                    <!-- Files will be loaded here via JavaScript -->
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="modal" id="editModal" style="display: none;">
        <div class="modal-content">
            <h3>Edit File Details</h3>
            <form id="editForm">
                <input type="hidden" id="editFileId">
                <div class="form-group">
                    <label for="editFileName">File Name</label>
                    <input type="text" id="editFileName" required>
                </div>
                <div class="form-group">
                    <label for="editCategory">Category</label>
                    <select id="editCategory" required>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="editBatchYear">Batch Year</label>
                    <select id="editBatchYear">
                        <option value="">All Batches (General)</option>
                        <?php foreach ($batch_years as $year): ?>
                            <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="editDescription">Description</label>
                    <textarea id="editDescription" rows="3"></textarea>
                </div>
                <div class="form-buttons">
                    <button type="submit" class="btn primary">Save Changes</button>
                    <button type="button" class="btn secondary" onclick="closeEditModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Custom Alert Modal -->
    <div id="alertModal" class="modal" style="display:none;">
        <div class="modal-content" style="max-width: 400px; text-align: center; padding: 25px;">
            <h3 id="alertTitle" style="margin-bottom: 15px;"></h3>
            <p id="alertMessage" style="font-size: 16px; margin-bottom: 20px;"></p>
            <button onclick="closeAlertModal()"
                style="padding: 8px 20px; background: #2196F3; color: white; border: none; border-radius: 5px; cursor: pointer;">
                OK
            </button>
        </div>
    </div>

    <script>
        // Initialize with empty array - will be populated via AJAX
        let allFiles = [];

        document.addEventListener('DOMContentLoaded', function() {
            fetchUnreadMessages();
            fetchFiles().then(() => {
                loadFiles();
                updateStats();
            });
            setupFileUpload();
            setupFilters();
        });

        // ============================================
        // UTILITY FUNCTIONS
        // ============================================

        function fetchFiles() {
            return fetch('Comm_file_action.php?action=fetch_all')
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        allFiles = data.files || [];
                    } else {
                        console.error('Failed to fetch files:', data.message);
                        showNotification('Failed to load files', 'error');
                    }
                })
                .catch(error => {
                    console.error('Error fetching files:', error);
                    showNotification('Error loading files', 'error');
                });
        }

        function showNotification(message, type = 'success') {
            // Create notification element
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
            <span class="material-icons">${type === 'success' ? 'check_circle' : type === 'error' ? 'error' : 'info'}</span>
            <span>${message}</span>
        `;

            // Add to body
            document.body.appendChild(notification);

            // Trigger animation
            setTimeout(() => notification.classList.add('show'), 10);

            // Remove after 4 seconds
            setTimeout(() => {
                notification.classList.remove('show');
                setTimeout(() => notification.remove(), 300);
            }, 4000);
        }

        function showLoadingOverlay(message = 'Processing...') {
            const overlay = document.createElement('div');
            overlay.id = 'loadingOverlay';
            overlay.className = 'loading-overlay';
            overlay.innerHTML = `
            <div class="loading-spinner">
                <div class="spinner"></div>
                <p>${message}</p>
            </div>
        `;
            document.body.appendChild(overlay);
        }

        function hideLoadingOverlay() {
            const overlay = document.getElementById('loadingOverlay');
            if (overlay) overlay.remove();
        }

        function confirmAction(message, onConfirm) {
            const modal = document.createElement('div');
            modal.className = 'modal confirm-modal';
            modal.innerHTML = `
            <div class="modal-content confirm-content">
                <span class="material-icons warning-icon">warning</span>
                <h3>Confirm Action</h3>
                <p>${message}</p>
                <div class="form-buttons">
                    <button class="btn danger" id="confirmYes">Yes, proceed</button>
                    <button class="btn secondary" id="confirmNo">Cancel</button>
                </div>
            </div>
        `;

            document.body.appendChild(modal);
            modal.style.display = 'flex';

            document.getElementById('confirmYes').onclick = () => {
                modal.remove();
                onConfirm();
            };

            document.getElementById('confirmNo').onclick = () => modal.remove();

            // Close on outside click
            modal.onclick = (e) => {
                if (e.target === modal) modal.remove();
            };
        }

        function escapeHTML(str) {
            if (str === null || str === undefined) return '';
            return String(str).replace(/[&<>"']/g, function(m) {
                return {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#39;'
                } [m];
            });
        }

        // ============================================
        // FILE UPLOAD HANDLING
        // ============================================

        function setupFileUpload() {
            const uploadArea = document.getElementById('fileUploadArea');
            const fileInput = document.getElementById('fileInput');
            const uploadForm = document.getElementById('uploadForm');

            // Click to upload
            uploadArea.addEventListener('click', () => fileInput.click());

            // Drag and drop
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });

            uploadArea.addEventListener('dragleave', () => {
                uploadArea.classList.remove('dragover');
            });

            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    fileInput.files = files;
                    showFilePreview(files[0]);
                }
            });

            // File selection preview
            fileInput.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    showFilePreview(e.target.files[0]);
                }
            });

            // Form submission handler
            uploadForm.addEventListener('submit', handleFileUpload);
        }

        function showFilePreview(file) {
            // Reset any previous error styling
            document.getElementById('fileUploadArea').style.borderColor = '';
            document.getElementById('fileUploadArea').classList.remove('error');

            // Validate file size
            const maxSize = 10 * 1024 * 1024; // 10MB
            if (file.size > maxSize) {
                showNotification('File size exceeds 10MB limit', 'error');
                document.getElementById('fileInput').value = '';
                document.getElementById('filePreview').style.display = 'none';
                return;
            }

            // Validate file type
            const allowedTypes = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'zip', 'jpg', 'png', 'jpeg'];
            const ext = file.name.split('.').pop().toLowerCase();

            if (!allowedTypes.includes(ext)) {
                showNotification('File type not allowed. Allowed types: ' + allowedTypes.join(', '), 'error');
                document.getElementById('fileInput').value = '';
                document.getElementById('filePreview').style.display = 'none';
                return;
            }

            // Show preview
            const sizeInMB = (file.size / (1024 * 1024)).toFixed(2);
            document.getElementById('selectedFileName').innerHTML = `
            <strong>${escapeHTML(file.name)}</strong> (${sizeInMB} MB)
        `;
            document.getElementById('filePreview').style.display = 'block';
        }

        function handleFileUpload(e) {
            e.preventDefault();

            // Reset all error states
            document.getElementById('fileName').style.borderColor = '';
            document.getElementById('fileCategory').style.borderColor = '';
            document.getElementById('fileUploadArea').classList.remove('error');
            document.getElementById('fileUploadArea').style.borderColor = '';

            // Validate form
            const fileName = document.getElementById('fileName').value.trim();
            const category = document.getElementById('fileCategory').value;
            const fileInput = document.getElementById('fileInput');

            // Check each field individually
            if (!fileName) {
                showNotification('⚠ Please enter a file name', 'error');
                const fileNameInput = document.getElementById('fileName');
                fileNameInput.style.borderColor = '#f44336';
                fileNameInput.focus();
                setTimeout(() => {
                    fileNameInput.style.borderColor = '';
                }, 3000);
                return;
            }

            if (!category) {
                showNotification('⚠ Please select a category', 'error');
                const categorySelect = document.getElementById('fileCategory');
                categorySelect.style.borderColor = '#f44336';
                categorySelect.focus();
                setTimeout(() => {
                    categorySelect.style.borderColor = '';
                }, 3000);
                return;
            }

            if (!fileInput.files[0]) {
                showNotification('⚠ Please select a file to upload', 'error');
                const uploadArea = document.getElementById('fileUploadArea');
                uploadArea.classList.add('error');
                uploadArea.style.borderColor = '#f44336';
                uploadArea.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });
                setTimeout(() => {
                    uploadArea.classList.remove('error');
                    uploadArea.style.borderColor = '';
                }, 1000);
                return;
            }

            // Create FormData from the form
            const formData = new FormData(e.target);

            showLoadingOverlay('Uploading file...');

            fetch('Comm_file_action.php?action=upload', {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    hideLoadingOverlay();

                    if (data.success) {
                        showNotification('✓ File uploaded successfully!', 'success');

                        // Reset form
                        e.target.reset();
                        document.getElementById('filePreview').style.display = 'none';

                        // Fetch updated file list
                        fetchFiles().then(() => {
                            loadFiles();
                            updateStats();
                        });
                    } else {
                        showNotification('Upload failed: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    hideLoadingOverlay();
                    console.error('Upload error:', error);
                    showNotification('An error occurred during upload. Please try again.', 'error');
                });
        }

        // ============================================
        // FILE MANAGEMENT
        // ============================================

        function loadFiles() {
            const grid = document.getElementById('filesGrid');
            grid.innerHTML = '';

            if (allFiles.length === 0) {
                grid.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
                    <span class="material-icons" style="font-size: 64px; color: var(--muted);">folder_open</span>
                    <p style="color: var(--muted); margin-top: 10px;">No files uploaded yet.</p>
                </div>
            `;
                return;
            }

            allFiles.forEach(file => {
                const fileExt = file.file_path.split('.').pop().toLowerCase();
                let iconClass = 'other';
                let icon = 'insert_drive_file';

                if (fileExt === 'pdf') {
                    iconClass = 'pdf';
                    icon = 'picture_as_pdf';
                } else if (['doc', 'docx'].includes(fileExt)) {
                    iconClass = 'doc';
                    icon = 'description';
                } else if (['xls', 'xlsx'].includes(fileExt)) {
                    iconClass = 'xls';
                    icon = 'table_chart';
                } else if (['jpg', 'png', 'jpeg'].includes(fileExt)) {
                    iconClass = 'img';
                    icon = 'image';
                }

                // Determine batch year display - CHANGED: Show just the year value without "Batch" text
                const batchYear = file.batch_year;
                const batchDisplay = batchYear ?
                    `<span class="batch-badge">${batchYear}</span>` :
                    `<span class="batch-badge batch-all">All Batches</span>`;

                const fileCard = `
                <div class="file-card" data-category="${escapeHTML(file.category)}" data-batch-year="${batchYear || 'general'}">
                    <div class="file-icon ${iconClass}">
                        <span class="material-icons">${icon}</span>
                    </div>
                    <div class="file-info">
                        <h4>${escapeHTML(file.file_name)}</h4>
                        <div class="file-tags">
                            <div class="file-category">${escapeHTML(file.category)}</div>
                            ${batchDisplay}
                        </div>
                        <p class="file-meta">${escapeHTML(file.description) || 'No description'}</p>
                        <div class="file-meta-row">
                            <span>
                                <span class="material-icons" style="font-size: 14px; vertical-align: middle;">download</span> 
                                ${file.download_count} downloads
                            </span>
                            <span>${new Date(file.upload_date).toLocaleDateString()}</span>
                        </div>
                    </div>
                    <div class="file-actions">
                        <button class="btn primary small" onclick="downloadFile(${file.id})" title="Download">
                            <span class="material-icons">download</span>
                        </button>
                        <button class="btn secondary small" onclick="openEditModal(${file.id})" title="Edit">
                            <span class="material-icons">edit</span>
                        </button>
                        <button class="btn danger small" onclick="deleteFile(${file.id})" title="Delete">
                            <span class="material-icons">delete</span>
                        </button>
                    </div>
                </div>
            `;
                grid.innerHTML += fileCard;
            });
        }

        function downloadFile(fileId) {
            const file = allFiles.find(f => f.id == fileId);
            if (file) {
                showNotification(`Downloading ${file.file_name}...`, 'info');
                window.open(`Comm_file_action.php?action=download&id=${fileId}`, '_blank');
            }
        }

        // ============================================
        // EDIT FUNCTIONALITY
        // ============================================

        function openEditModal(fileId) {
            const file = allFiles.find(f => f.id == fileId);
            if (!file) {
                showNotification('File not found', 'error');
                return;
            }

            document.getElementById('editFileId').value = file.id;
            document.getElementById('editFileName').value = file.file_name;
            document.getElementById('editCategory').value = file.category;
            document.getElementById('editBatchYear').value = file.batch_year || '';
            document.getElementById('editDescription').value = file.description || '';
            document.getElementById('editModal').style.display = 'flex';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        document.getElementById('editForm').addEventListener('submit', function(e) {
            e.preventDefault();

            const formData = {
                id: document.getElementById('editFileId').value,
                file_name: document.getElementById('editFileName').value.trim(),
                category: document.getElementById('editCategory').value,
                batch_year: document.getElementById('editBatchYear').value || null,
                description: document.getElementById('editDescription').value.trim()
            };

            if (!formData.file_name || !formData.category) {
                showNotification('File name and category are required', 'error');
                return;
            }

            showLoadingOverlay('Updating file...');

            fetch('Comm_file_action.php?action=update', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                })
                .then(res => res.json())
                .then(data => {
                    hideLoadingOverlay();

                    if (data.success) {
                        showNotification('✓ File updated successfully!', 'success');
                        closeEditModal();

                        // Update the file in the array
                        const fileIndex = allFiles.findIndex(f => f.id == formData.id);
                        if (fileIndex !== -1) {
                            allFiles[fileIndex].file_name = formData.file_name;
                            allFiles[fileIndex].category = formData.category;
                            allFiles[fileIndex].batch_year = formData.batch_year;
                            allFiles[fileIndex].description = formData.description;
                            loadFiles();
                        }
                    } else {
                        showNotification('Update failed: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    hideLoadingOverlay();
                    console.error('Update error:', error);
                    showNotification('An error occurred during update', 'error');
                });
        });

        // ============================================
        // DELETE FUNCTIONALITY
        // ============================================

        function deleteFile(fileId) {
            const file = allFiles.find(f => f.id == fileId);
            if (!file) return;

            confirmAction(
                `Are you sure you want to delete "<strong>${escapeHTML(file.file_name)}</strong>"?<br><br>This action cannot be undone.`,
                () => performDelete(fileId)
            );
        }

        function performDelete(fileId) {
            showLoadingOverlay('Deleting file...');

            fetch('Comm_file_action.php?action=delete', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: fileId
                    })
                })
                .then(res => res.json())
                .then(data => {
                    hideLoadingOverlay();

                    if (data.success) {
                        showNotification('✓ File deleted successfully!', 'success');

                        // Remove from array and reload
                        allFiles = allFiles.filter(f => f.id != fileId);
                        loadFiles();
                        updateStats();
                    } else {
                        showNotification('Delete failed: ' + data.message, 'error');
                    }
                })
                .catch(error => {
                    hideLoadingOverlay();
                    console.error('Delete error:', error);
                    showNotification('An error occurred during deletion', 'error');
                });
        }

        // ============================================
        // FILTERS
        // ============================================

        function setupFilters() {
            document.getElementById('searchInput').addEventListener('input', filterFiles);
            document.getElementById('categoryFilter').addEventListener('change', filterFiles);
            document.getElementById('batchYearFilter').addEventListener('change', filterFiles);
        }

        function filterFiles() {
            const searchTerm = document.getElementById('searchInput').value.toLowerCase();
            const category = document.getElementById('categoryFilter').value;
            const batchYear = document.getElementById('batchYearFilter').value;
            const cards = document.querySelectorAll('.file-card');

            let visibleCount = 0;

            cards.forEach(card => {
                const fileName = card.querySelector('h4').textContent.toLowerCase();
                const fileCategory = card.dataset.category;
                const fileBatchYear = card.dataset.batchYear;

                const matchesSearch = fileName.includes(searchTerm);
                const matchesCategory = !category || fileCategory === category;
                const matchesBatch = !batchYear ||
                    (batchYear === 'general' && fileBatchYear === 'general') ||
                    (batchYear !== 'general' && fileBatchYear === batchYear);

                if (matchesSearch && matchesCategory && matchesBatch) {
                    card.style.display = 'block';
                    visibleCount++;
                } else {
                    card.style.display = 'none';
                }
            });

            // Show message if no results
            const grid = document.getElementById('filesGrid');
            const existingMsg = grid.querySelector('.no-results-message');
            if (existingMsg) existingMsg.remove();

            if (visibleCount === 0 && allFiles.length > 0) {
                const noResults = document.createElement('div');
                noResults.className = 'no-results-message';
                noResults.style.cssText = 'grid-column: 1/-1; text-align: center; padding: 40px; color: var(--muted);';
                noResults.innerHTML = `
                <span class="material-icons" style="font-size: 48px;">search_off</span>
                <p>No files match your search criteria</p>
            `;
                grid.appendChild(noResults);
            }
        }

        function resetFilters() {
            document.getElementById('searchInput').value = '';
            document.getElementById('categoryFilter').value = '';
            document.getElementById('batchYearFilter').value = '';
            filterFiles();
            showNotification('Filters reset', 'info');
        }

        // ============================================
        // STATISTICS
        // ============================================

        function updateStats() {
            document.getElementById('totalFiles').textContent = allFiles.length;
            const totalDownloads = allFiles.reduce((sum, file) => sum + parseInt(file.download_count || 0), 0);
            document.getElementById('totalDownloads').textContent = totalDownloads;

            // Calculate total size if available
            const totalSize = allFiles.reduce((sum, file) => sum + parseInt(file.file_size || 0), 0);
            const sizeInMB = (totalSize / (1024 * 1024)).toFixed(2);
            document.getElementById('totalSize').textContent = sizeInMB + ' MB';
        }

        // ============================================
        // CHAT NOTIFICATIONS
        // ============================================

        function fetchUnreadMessages() {
            fetch('../chat_action.php?action=get_total_unread')
                .then(response => response.json())
                .then(data => {
                    const badge = document.getElementById('chat-notification-badge');
                    if (data.success && data.total_unread > 0) {
                        badge.textContent = data.total_unread;
                        badge.style.display = 'block';
                    } else {
                        badge.style.display = 'none';
                    }
                })
                .catch(error => console.error('Error fetching unread messages:', error));
        }

        // Close modal on outside click
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });

        function showAlert(title, message, isSuccess = true) {
            document.getElementById('alertTitle').innerText = title;
            document.getElementById('alertTitle').style.color = isSuccess ? "#4CAF50" : "#F44336";
            document.getElementById('alertMessage').innerText = message;
            document.getElementById('alertModal').style.display = 'flex';
        }

        function closeAlertModal() {
            document.getElementById('alertModal').style.display = 'none';
        }
    </script>
</body>

</html>