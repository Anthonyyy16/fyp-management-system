<?php
/**
 * Admin Dashboard Backend Logic
 * Handles all data fetching for the admin dashboard
 */

session_start();

// Permission check
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'committee') {
    header("location: ../index.php");
    exit;
}

require_once '../db_connect.php';

/**
 * Fetch all available batches
 */
function fetchBatches($conn) {
    $batches = [];
    $batch_result = $conn->query("SELECT DISTINCT batch_year FROM users WHERE batch_year IS NOT NULL ORDER BY batch_year DESC");
    while ($row = $batch_result->fetch_assoc()) {
        $batches[] = $row['batch_year'];
    }
    return $batches;
}

/**
 * Get current batch from GET parameter or default to latest
 */
function getCurrentBatch($batches) {
    if (isset($_GET['batch']) && in_array($_GET['batch'], $batches)) {
        return $_GET['batch'];
    }
    return !empty($batches) ? $batches[0] : '';
}

/**
 * Fetch user counts by role for a specific batch
 */
function fetchUserCounts($conn, $batch_year) {
    $counts = ['student' => 0, 'supervisor' => 0, 'committee' => 0, 'admin' => 0];
    
    if (empty($batch_year)) {
        return $counts;
    }
    
    // Count students by batch_year
    $sql = "SELECT role, COUNT(*) as count FROM users WHERE batch_year = ? GROUP BY role";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $batch_year);
        $stmt->execute();
        $user_count_result = $stmt->get_result();
        while ($row = $user_count_result->fetch_assoc()) {
            if (isset($counts[$row['role']])) {
                $counts[$row['role']] = $row['count'];
            }
        }
        $stmt->close();
    }
    
    // Count supervisors from groups table (distinct supervisor_id for this batch)
    $sql_sup = "SELECT COUNT(DISTINCT supervisor_id) as sup_count FROM groups WHERE batch_year = ? AND supervisor_id IS NOT NULL";
    if ($stmt_sup = $conn->prepare($sql_sup)) {
        $stmt_sup->bind_param("s", $batch_year);
        $stmt_sup->execute();
        $sup_result = $stmt_sup->get_result();
        if ($row = $sup_result->fetch_assoc()) {
            $counts['supervisor'] = (int)$row['sup_count'];
        }
        $stmt_sup->close();
    }
    
    // Count committees from batch_committees table (distinct committee_id for this batch)
    $sql_committee = "SELECT COUNT(DISTINCT committee_id) as committee_count FROM batch_committees WHERE batch_year = ?";
    if ($stmt_committee = $conn->prepare($sql_committee)) {
        $stmt_committee->bind_param("s", $batch_year);
        $stmt_committee->execute();
        $committee_result = $stmt_committee->get_result();
        if ($row = $committee_result->fetch_assoc()) {
            $counts['committee'] = (int)$row['committee_count'];
        }
        $stmt_committee->close();
    }
    
    return $counts;
}

/**
 * Calculate total users (student + supervisor + committee)
 */
function calculateTotalUsers($counts) {
    return $counts['student'] + $counts['supervisor'] + $counts['committee'];
}

/**
 * Fetch recent announcements for a batch
 */
function fetchAnnouncements($conn, $batch_year, $limit = 3) {
    $announcements = [];
    
    if (empty($batch_year)) {
        return $announcements;
    }
    
    $announcement_result = $conn->prepare("SELECT title, created_at FROM announcements WHERE batch_year = ? ORDER BY created_at DESC LIMIT ?");
    $announcement_result->bind_param("si", $batch_year, $limit);
    $announcement_result->execute();
    $result = $announcement_result->get_result();
    while ($row = $result->fetch_assoc()) {
        $announcements[] = $row;
    }
    $announcement_result->close();
    
    return $announcements;
}

/**
 * Fetch upcoming deadlines for a batch
 */
function fetchDeadlines($conn, $batch_year, $limit = 3) {
    $deadlines = [];
    
    if (empty($batch_year)) {
        return $deadlines;
    }
    
    $deadline_result = $conn->prepare("SELECT title, due_date FROM deadlines WHERE batch_year = ? AND due_date >= CURDATE() ORDER BY due_date ASC LIMIT ?");
    $deadline_result->bind_param("si", $batch_year, $limit);
    $deadline_result->execute();
    $result = $deadline_result->get_result();
    while ($row = $result->fetch_assoc()) {
        $deadlines[] = $row;
    }
    $deadline_result->close();
    
    return $deadlines;
}

// Fetch all data
$batches = fetchBatches($conn);
$current_batch = getCurrentBatch($batches);
$counts = fetchUserCounts($conn, $current_batch);
$total_users = calculateTotalUsers($counts);
$announcements = fetchAnnouncements($conn, $current_batch);
$deadlines = fetchDeadlines($conn, $current_batch);
?>
