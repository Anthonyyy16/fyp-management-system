<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'committee') {
    header("location: ../index.php");
    exit;
}
require_once '../db_connect.php';


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Supervisors & Moderators</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="admin.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<body>
    <div class="navbar">
        <h2>FYP System - Moderator Management</h2>
        <div class="button-group">
            <a href="Comm_Dashboard.php"><button>Dashboard</button></a>
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>
    <div class="main-container">
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Committee Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li ><a href="Comm_Dashboard.php"><span class="material-icons">dashboard</span>Dashboard</a></li>
                <li><a href="Comm_Announcements.php"><span class="material-icons">campaign</span>Announcements</a></li>
                <li><a href="Comm_Deadline.php"><span class="material-icons">event</span>Global Deadlines</a></li>
                <li><a href="Comm_Allocation.php"><span class="material-icons">assignment_ind</span>Project Allocation</a></li>
                <li><a href="Comm_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <li class="active"><a href="Comm_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li>
            </ul>
        </div>

        <div class="main-content">
            <div class="content-header">
                <h1>Manage Moderators by Batch</h1>
                <p>Assign moderators (supervisors) to project groups by batch year.</p>
            </div>

            <div class="card">
                <!-- Batch Selector -->
                <div class="filters" style="margin-bottom: 20px;">
                    <select id="batchFilter" class="filter-select">
                        <option value="">Select Batch Year...</option>
                    </select>
                </div>

                <!-- Success Message -->
                <div id="successMessage" style="display: none; background-color: #d4edda; color: #155724; padding: 12px; border: 1px solid #c3e6cb; border-radius: var(--radius); margin-bottom: 15px;">
                    Moderator updated successfully!
                </div>

                <!-- Error Message -->
                <div id="errorMessage" style="display: none; background-color: #f8d7da; color: #721c24; padding: 12px; border: 1px solid #f5c6cb; border-radius: var(--radius); margin-bottom: 15px;"></div>

                <!-- Groups Table -->
                <div class="data-table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Supervisor</th>
                                <th>Current Moderator</th>
                                <th>Assign New Moderator</th>
                            </tr>
                        </thead>
                        <tbody id="groupsTableBody">
                            <tr>
                                <td colspan="3" style="text-align: center; color: var(--muted);">Select a batch year to view groups</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const batchFilter = document.getElementById('batchFilter');
            const groupsTableBody = document.getElementById('groupsTableBody');
            const successMessage = document.getElementById('successMessage');
            const errorMessage = document.getElementById('errorMessage');
            let supervisors = [];

            
            const init = async () => {
                try {
                    
                    const batchesResponse = await fetch('moderator_action.php?action=fetch_batches');
                    const batches = await batchesResponse.json();
                    
                    
                    batches.forEach(batch => {
                        const option = document.createElement('option');
                        option.value = batch.batch_year;
                        option.textContent = batch.batch_year;
                        batchFilter.appendChild(option);
                    });

                    
                    const supervisorsResponse = await fetch('moderator_action.php?action=fetch_supervisors');
                    supervisors = await supervisorsResponse.json();
                } catch (error) {
                    console.error('Error initializing:', error);
                }
            };

            
            batchFilter.addEventListener('change', async () => {
                const batchYear = batchFilter.value;
                
                if (!batchYear) {
                    groupsTableBody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: var(--muted);">Select a batch year to view groups</td></tr>';
                    return;
                }

                groupsTableBody.innerHTML = '<tr><td colspan="3" style="text-align: center;">Loading...</td></tr>';

                try {
                    const response = await fetch(`moderator_action.php?action=fetch_groups_by_batch&batch_year=${encodeURIComponent(batchYear)}`);
                    const groups = await response.json();

                    if (!Array.isArray(groups) || groups.length === 0) {
                        groupsTableBody.innerHTML = '<tr><td colspan="3" style="text-align: center;">No groups found for this batch.</td></tr>';
                        return;
                    }

                    groupsTableBody.innerHTML = '';
                    groups.forEach(group => {
                        const tr = document.createElement('tr');
                        
                        
                        let selectHtml = '<select class="moderator-select" data-group-id="' + group.id + '" style="padding: 8px; border: 1px solid var(--border-color); border-radius: var(--radius);">';
                        selectHtml += '<option value="">-- Select Supervisor --</option>';
                        supervisors.forEach(sup => {
                            const selected = sup.id == group.moderator_id ? 'selected' : '';
                            selectHtml += `<option value="${sup.id}" ${selected}>${sup.name}</option>`;
                        });
                        selectHtml += '</select>';

                        tr.innerHTML = `
                            <td>${group.supervisor_name || '(None)'}</td>
                            <td>${group.moderator_name || '(None)'}</td>
                            <td>
                                ${selectHtml}
                                <button class="update-btn" data-group-id="${group.id}" style="margin-left: 10px; padding: 8px 12px; background-color: var(--primary); color: white; border: none; border-radius: var(--radius); cursor: pointer;">Update</button>
                            </td>
                        `;
                        groupsTableBody.appendChild(tr);
                    });

                    
                    document.querySelectorAll('.update-btn').forEach(btn => {
                        btn.addEventListener('click', updateModerator);
                    });
                } catch (error) {
                    console.error('Error fetching groups:', error);
                    groupsTableBody.innerHTML = '<tr><td colspan="3" style="text-align: center; color: red;">Error loading groups</td></tr>';
                }
            });

            
            async function updateModerator(e) {
                const btn = e.target;
                const groupId = btn.dataset.groupId;
                const select = document.querySelector(`.moderator-select[data-group-id="${groupId}"]`);
                const moderatorId = select.value;

                if (!moderatorId) {
                    alert('Please select a supervisor');
                    return;
                }

                try {
                    const response = await fetch('moderator_action.php?action=update_moderator', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            group_id: parseInt(groupId),
                            moderator_id: parseInt(moderatorId)
                        })
                    });

                    const result = await response.json();

                    if (result.success) {
                        successMessage.style.display = 'block';
                        errorMessage.style.display = 'none';
                        setTimeout(() => {
                            successMessage.style.display = 'none';
                        }, 3000);
                        
                        
                        const batchYear = batchFilter.value;
                        if (batchYear) {
                            batchFilter.dispatchEvent(new Event('change'));
                        }
                    } else {
                        errorMessage.textContent = result.message || 'Failed to update moderator';
                        errorMessage.style.display = 'block';
                        successMessage.style.display = 'none';
                    }
                } catch (error) {
                    console.error('Error updating moderator:', error);
                    errorMessage.textContent = 'Error updating moderator';
                    errorMessage.style.display = 'block';
                    successMessage.style.display = 'none';
                }
            }

            
            init();
        });
    </script>
</body>

</html>
