<?php
// Include backend logic
require_once 'admin_dashboard_backend.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Committee Dashboard - FYP System</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="admin_dashboard.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<body>

    <!-- Navbar -->
    <div class="navbar">
        <h2>FYP System - Committee Dashboard</h2>
        <div class="button-group">
            <div class="contact-items">
                <div class="notification-badge-wrapper">
                    <a href="../chat.php"><button><span class="material-icons">question_answer</span>Chat</button></a>
                    <span class="notification-badge" id="chat-notification-badge" style="display: none;"></span>
                </div>
            </div>
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>

    <!-- Main Layout Container -->
    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Committee Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li class="active"><a href="Comm_Dashboard.php"><span class="material-icons">dashboard</span>Dashboard</a></li>
                <li><a href="Comm_Announcements.php"><span class="material-icons">campaign</span>Announcements</a></li>
                <li><a href="Comm_Deadline.php"><span class="material-icons">event</span>Global Deadlines</a></li>
                <li><a href="Comm_Allocation.php"><span class="material-icons">assignment_ind</span>Project Allocation</a></li>
                <li><a href="Comm_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <li><a href="Comm_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="content-header">
                <h1>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h1>
                <p>Here is a summary of the system status.</p>
            </div>

            <!-- Batch Filter Form -->
            <div class="card">
                <form method="GET" action="Comm_Dashboard.php" class="filters">
                    <label for="batch">Showing stats for batch:</label>
                    <select name="batch" id="batch" class="filter-select" onchange="this.form.submit()">
                        <?php if (empty($batches)): ?>
                            <option>No batches found</option>
                        <?php else: ?>
                            <?php foreach ($batches as $batch): ?>
                                <option value="<?php echo htmlspecialchars($batch); ?>" <?php echo ($batch === $current_batch) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($batch); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </form>
            </div>

            <!-- Stats Cards -->
            <div class="card-deck">
                <div class="stat-card">
                    <div class="stat-card-icon blue">
                        <span class="material-icons">groups</span>
                    </div>
                    <div class="stat-card-info">
                        <h2><?php echo $total_users; ?></h2>
                        <p>Total Users in Batch</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon green">
                        <span class="material-icons">school</span>
                    </div>
                    <div class="stat-card-info">
                        <h2><?php echo $counts['student']; ?></h2>
                        <p>Students</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon orange">
                        <span class="material-icons">person</span>
                    </div>
                    <div class="stat-card-info">
                        <h2><?php echo $counts['supervisor']; ?></h2>
                        <p>Supervisors</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-card-icon purple">
                        <span class="material-icons">gavel</span>
                    </div>
                    <div class="stat-card-info">
                        <h2><?php echo $counts['committee']; ?></h2>
                        <p>Committees</p>
                    </div>
                </div>
            </div>

            <!-- New Data Display Sections -->
            <div class="additional-info-deck">
                <div class="card">
                    <h3>Recent Announcements</h3>
                    <ul class="info-list">
                        <?php if (empty($announcements)): ?>
                            <li>No recent announcements.</li>
                        <?php else: ?>
                            <?php foreach ($announcements as $announcement): ?>
                                <li>
                                    <strong><?php echo htmlspecialchars($announcement['title']); ?></strong>
                                    <small>Posted on: <?php echo date('d M Y', strtotime($announcement['created_at'])); ?></small>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
                <div class="card">
                    <h3>Upcoming Deadlines</h3>
                    <ul class="info-list">
                        <?php if (empty($deadlines)): ?>
                            <li>No upcoming deadlines.</li>
                        <?php else: ?>
                            <?php foreach ($deadlines as $deadline): ?>
                                <li>
                                    <strong><?php echo htmlspecialchars($deadline['title']); ?></strong>
                                    <small>Due by: <?php echo date('d M Y', strtotime($deadline['due_date'])); ?></small>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="content-header" style="margin-top: 30px;">
                <h2>Quick Actions</h2>
            </div>

            <div class="action-deck">
                
                <a href="Comm_Announcements.php" class="action-card">
                    <span class="material-icons">campaign</span>
                    <h4>Post Announcement</h4>
                    <p>Create and publish system-wide announcements.</p>
                </a>
                <a href="Comm_Deadline.php" class="action-card">
                    <span class="material-icons">event</span>
                    <h4>Set Deadlines</h4>
                    <p>Manage global submission deadlines for all students.</p>
                </a>
                <a href="Comm_Allocation.php" class="action-card">
                    <span class="material-icons">assignment_ind</span>
                    <h4>Projects Allocation</h4>
                    <p>Oversee and manage student-supervisor pairings.</p>
                </a>

                <a href="Comm_Files.php" class="action-card">
                    <span class="material-icons">folder</span>
                    <h4>File Management</h4>
                    <p>Upload and manage downloadable files for students.</p>
                </a>

                <a href="Comm_Moderator.php" class="action-card">
                    <span class="material-icons">supervisor_account</span>
                    <h4>Moderator Management</h4>
                    <p>Manage all moderators in the system.</p>
                </a>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            fetchUnreadMessages();
            // ...
        });

        function fetchUnreadMessages() {
            fetch('../chat_action.php?action=get_total_unread')
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    const badge = document.getElementById('chat-notification-badge');
                    if (data.success && data.total_unread > 0) {
                        
                        badge.textContent = data.total_unread;
                        badge.style.display = 'block';
                    } else {
                        
                        badge.style.display = 'none';
                    }
                })
                .catch(error => {
                    
                    console.error('Error fetching unread messages count:', error);
                });
        }
    </script>
</body>

</html>