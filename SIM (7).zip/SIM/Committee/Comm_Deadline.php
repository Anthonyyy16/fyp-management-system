<?php
session_start();

if (!isset($_SESSION['loggedin']) || !in_array($_SESSION['role'], ['admin', 'committee'])) {
    header("Location: ../index.php");
    exit();
}
require_once '../db_connect.php';


$batch_years = [];
$result = $conn->query("SELECT DISTINCT batch_year FROM users WHERE batch_year IS NOT NULL AND batch_year != '' ORDER BY batch_year DESC");
while ($row = $result->fetch_assoc()) {
    $batch_years[] = $row['batch_year'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Deadline Management - Committee</title>
    <link rel="stylesheet" href="../index.css">
    <link rel="stylesheet" href="admin.css"> 
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <style>
        
        .form-group label {
            flex: 1 1 100%;
        }

        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .form-group-full {
            grid-column: 1 / -1;
            
        }
    </style>
</head>

<body>
    <div class="navbar">
        <h2>Committee Panel - Deadline Management</h2>
        <div class="button-group">
            <a href="../logout.php"><button>Logout</button></a>
        </div>
    </div>

    <div class="main-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <h3>Committee Menu</h3>
            </div>
            <ul class="sidebar-menu">
                <li ><a href="Comm_Dashboard.php"><span class="material-icons">dashboard</span>Dashboard</a></li>
                <li><a href="Comm_Announcements.php"><span class="material-icons">campaign</span>Announcements</a></li>
                <li class="active"><a href="Comm_Deadline.php"><span class="material-icons">event</span>Global Deadlines</a></li>
                <li><a href="Comm_Allocation.php"><span class="material-icons">assignment_ind</span>Project Allocation</a></li>
                <li><a href="Comm_Files.php"><span class="material-icons">folder</span>File Management</a></li>
                <li><a href="Comm_ModeratorMngm.php"><span class="material-icons">supervisor_account</span>Moderator Management</a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="content-header">
                <h1>Manage Deadlines</h1>
                <p>Set and manage submission deadlines for all batches.</p>
            </div>

            <!-- Add/Edit Deadline Card -->
            <div class="card">
                <h3 id="formTitle">Set a New Deadline</h3>
                <form id="deadlineForm">
                    <input type="hidden" id="deadlineId" name="id">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" id="title" name="title" placeholder="e.g., Final Report Submission" required>
                        </div>
                        <div class="form-group">
                            <label for="due_date">Due Date & Time</label>
                            <input type="datetime-local" id="due_date" name="due_date" required>
                        </div>
                        <div class="form-group">
                            <label for="batch_year">Applicable Batch</label>
                            <select id="batch_year" name="batch_year" required>
                                <option value="" disabled selected>Select a batch</option>
                                <?php foreach ($batch_years as $year): ?>
                                    <option value="<?php echo htmlspecialchars($year); ?>"><?php echo htmlspecialchars($year); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group form-group-full">
                            <label for="description">Description (Optional)</label>
                            <textarea id="description" name="description" rows="3" placeholder="Provide a brief description of the submission requirements."></textarea>
                        </div>
                    </div>
                    <div class="form-buttons">
                        <button type="button" class="btn secondary" id="cancelBtn" style="display: none;">Cancel Edit</button>
                        <button type="submit" class="btn primary">Save Deadline</button>
                    </div>
                </form>
            </div>

            <!-- Deadlines Table Card -->
            <div class="card">
                <h3>Existing Deadlines</h3>
                <div class="filters" style="margin-bottom: 20px;">
                    <label for="batchFilter" style="margin-right: 10px; font-weight: 500;">Filter by Batch:</label>
                    <select id="batchFilter" class="filter-select">
                        <option value="all">All Batches</option>
                        <?php foreach ($batch_years as $year): ?>
                            <option value="<?php echo htmlspecialchars($year); ?>"><?php echo htmlspecialchars($year); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="data-table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Title & Description</th>
                                <th>Applicable Batch</th>
                                <th>Due Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="deadlineTableBody">
                            <!-- JavaScript will populate this area -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const deadlineForm = document.getElementById('deadlineForm');
            const deadlineTableBody = document.getElementById('deadlineTableBody');
            const formTitle = document.getElementById('formTitle');
            const deadlineIdInput = document.getElementById('deadlineId');
            const cancelBtn = document.getElementById('cancelBtn');
            const batchFilter = document.getElementById('batchFilter');
            let editMode = false;
            let allDeadlines = []; 

            
            const fetchDeadlines = () => {
                deadlineTableBody.innerHTML = '<tr><td colspan="4" style="text-align:center;">Loading...</td></tr>';
                fetch('admin_action.php?action=fetch_deadlines')
                    .then(res => res.json())
                    .then(data => {
                        allDeadlines = data; 
                        renderDeadlines(data);
                    });
            };

            
            const renderDeadlines = (data) => {
                const selectedBatch = batchFilter.value;
                
                
                let filteredData = data;
                if (selectedBatch !== 'all') {
                    filteredData = data.filter(deadline => deadline.batch_year === selectedBatch);
                }

                deadlineTableBody.innerHTML = '';
                if (filteredData.length === 0) {
                    deadlineTableBody.innerHTML = '<tr><td colspan="4" style="text-align:center;">No deadlines set yet.</td></tr>';
                    return;
                }
                filteredData.forEach(deadline => {
                    const tr = document.createElement('tr');
                    
                    const dueDate = new Date(deadline.due_date).toLocaleString('en-GB', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        hour12: true
                    });
                    tr.innerHTML = `
                    <td>
                        <strong>${deadline.title}</strong>
                        <p style="margin: 4px 0 0; color: var(--muted); font-size: 0.9em;">${deadline.description || ''}</p>
                    </td>
                    <td>${deadline.batch_year}</td>
                    <td>${dueDate}</td>
                    <td class="actions-cell">
                        <button class="btn-icon edit-btn" data-deadline='${JSON.stringify(deadline)}' title="Edit"><span class="material-icons">edit</span></button>
                        <button class="btn-icon delete-btn" data-id="${deadline.id}" title="Delete"><span class="material-icons">delete</span></button>
                    </td>
                `;
                    deadlineTableBody.appendChild(tr);
                });
            };

            
            const resetForm = () => {
                deadlineForm.reset();
                deadlineIdInput.value = '';
                formTitle.textContent = 'Set a New Deadline';
                deadlineForm.querySelector('button[type="submit"]').textContent = 'Save Deadline';
                cancelBtn.style.display = 'none';
                editMode = false;
            };

            
            deadlineForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const formData = new FormData(deadlineForm);
                const data = Object.fromEntries(formData.entries());

                const url = editMode ? 'admin_action.php?action=update_deadline' : 'admin_action.php?action=create_deadline';

                fetch(url, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(data)
                    })
                    .then(res => res.json())
                    .then(response => {
                        if (response.success) {
                            resetForm();
                            fetchDeadlines(); 
                        } else {
                            alert(response.message || 'An error occurred.');
                        }
                    });
            });

            
            deadlineTableBody.addEventListener('click', (e) => {
                const target = e.target.closest('button');
                if (!target) return;

                const id = target.dataset.id;

                
                if (target.classList.contains('edit-btn')) {
                    const deadlineData = JSON.parse(target.dataset.deadline);
                    formTitle.textContent = 'Edit Deadline';
                    deadlineForm.querySelector('button[type="submit"]').textContent = 'Save Changes';

                    
                    deadlineIdInput.value = deadlineData.id;
                    document.getElementById('title').value = deadlineData.title;
                    document.getElementById('description').value = deadlineData.description;
                    
                    const localDate = new Date(deadlineData.due_date);
                    localDate.setMinutes(localDate.getMinutes() - localDate.getTimezoneOffset());
                    document.getElementById('due_date').value = localDate.toISOString().slice(0, 16);

                    document.getElementById('batch_year').value = deadlineData.batch_year;

                    cancelBtn.style.display = 'inline-flex';
                    editMode = true;
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    }); 
                }

                
                if (target.classList.contains('delete-btn')) {
                    if (confirm('Are you sure you want to delete this deadline?')) {
                        fetch('admin_action.php?action=delete_deadline', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/json'
                                },
                                body: JSON.stringify({
                                    id: id
                                })
                            })
                            .then(res => res.json())
                            .then(response => {
                                if (response.success) {
                                    fetchDeadlines(); 
                                } else {
                                    alert(response.message || 'Failed to delete.');
                                }
                            });
                    }
                }
            });

            
            cancelBtn.addEventListener('click', resetForm);

            
            batchFilter.addEventListener('change', () => {
                renderDeadlines(allDeadlines);
            });

            
            fetchDeadlines();
        });
    </script>
</body>

</html>