#!/usr/bin/env python3
"""
Analyze the relationship between deadlines and supervisor workload
in a Final Year Project Management System.
"""

import mysql.connector
from mysql.connector import Error
from datetime import datetime, timedelta
from collections import defaultdict
import json
import sys


db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'test123',
    'port': 3306,
    'use_unicode': True,
    'charset': 'utf8mb4'
}

def connect_db():
    """Connect to the database"""
    try:
        conn = mysql.connector.connect(**db_config)
        if conn.is_connected():
            return conn
    except Error as e:
        print(f"❌ Database connection error: {e}")
        print(f"   Config: {db_config}")
        sys.exit(1)

def get_deadline_supervisor_analysis():
    """
    Get analysis of the relationship between deadlines and supervisor workload
    """
    conn = connect_db()
    if not conn:
        return None
    
    cursor = conn.cursor(dictionary=True)
    
    # Query: For each upcoming deadline, which supervisors will be affected
    query = """
    SELECT 
        DATE(d.due_date) as deadline_date,
        d.title as deadline_title,
        d.batch_year,
        sup.name as supervisor_name,
        COUNT(DISTINCT s.id) as student_count,
        COALESCE(sd.capacity, 10) as supervisor_capacity
    FROM 
        deadlines d
    LEFT JOIN 
        users s ON (s.batch_year = d.batch_year AND s.role = 'student' AND s.status = 'active')
    LEFT JOIN 
        users sup ON (s.supervisor_id = sup.id AND sup.role = 'supervisor')
    LEFT JOIN 
        supervisor_details sd ON sup.id = sd.user_id
    WHERE 
        DATE(d.due_date) >= CURDATE()
    GROUP BY 
        DATE(d.due_date), d.id, d.title, d.batch_year, sup.id, sup.name, sd.capacity
    ORDER BY 
        DATE(d.due_date) ASC, student_count DESC
    """
    
    try:
        cursor.execute(query)
        results = cursor.fetchall()
        return results
    except Error as e:
        print(f"Query error: {e}")
        return None
    finally:
        cursor.close()
        conn.close()

def get_most_popular_supervisors():
    """
    Get the most popular supervisors (with the highest number of students)
    """
    conn = connect_db()
    if not conn:
        return None
    
    cursor = conn.cursor(dictionary=True)
    
    query = """
    SELECT 
        sup.id,
        sup.name,
        COUNT(DISTINCT s.id) as student_count,
        COALESCE(sd.capacity, 10) as capacity,
        ROUND((COUNT(DISTINCT s.id) / COALESCE(sd.capacity, 10)) * 100, 1) as utilization_percent
    FROM 
        users sup
    LEFT JOIN 
        users s ON (s.supervisor_id = sup.id AND s.role = 'student' AND s.status = 'active')
    LEFT JOIN 
        supervisor_details sd ON sup.id = sd.user_id
    WHERE 
        sup.role = 'supervisor' AND sup.status = 'active'
    GROUP BY 
        sup.id, sup.name, sd.capacity
    ORDER BY 
        student_count DESC
    """
    
    try:
        cursor.execute(query)
        results = cursor.fetchall()
        return results
    except Error as e:
        print(f"Query error: {e}")
        return None
    finally:
        cursor.close()
        conn.close()

def analyze_deadline_impact():
    """
    Analyze the impact of each deadline on supervisor workload
    """
    results = get_deadline_supervisor_analysis()
    
    if not results:
        print("No deadline data found")
        return
    
    # Group by deadline
    by_deadline = defaultdict(list)
    for row in results:
        deadline_key = f"{row['deadline_date']} - {row['deadline_title']}"
        if row['supervisor_name']:  # Only count students with supervisors
            by_deadline[deadline_key].append({
                'supervisor': row['supervisor_name'],
                'students': row['student_count'],
                'capacity': row['supervisor_capacity'],
                'batch': row['batch_year']
            })
    
    print("\n" + "="*80)
    print("📊 Deadline and Supervisor Workload Analysis")
    print("="*80)
    
    for deadline, supervisors in sorted(by_deadline.items()):
        print(f"\n📅 {deadline}")
        print("-" * 80)
        
        # Sort by number of students
        supervisors_sorted = sorted(supervisors, key=lambda x: x['students'], reverse=True)
        
        total_affected = sum(s['students'] for s in supervisors_sorted)
        print(f"   Affected Supervisors: {len(supervisors_sorted)}")
        print(f"   Affected Students: {total_affected}\n")
        
        for sup in supervisors_sorted:
            utilization = (sup['students'] / sup['capacity']) * 100
            status = "🔴 Overload" if utilization > 100 else ("🟡 High Load" if utilization > 75 else "🟢 Normal")
            print(f"   • {sup['supervisor']:20} │ {sup['students']:2} students │ "
                  f"{sup['capacity']:2} capacity │ {utilization:5.1f}% │ {status}")

def analyze_popular_supervisors():
 
    results = get_most_popular_supervisors()
    
    if not results:
        print("No supervisor data found")
        return
    
    print("\n" + "="*80)
    print("⭐ Most Popular Supervisors Analysis (by number of students)")
    print("="*80 + "\n")
    
    max_students = max(r['student_count'] for r in results) if results else 0
    
    for i, row in enumerate(results, 1):
        is_popular = row['student_count'] == max_students and max_students > 0
        indicator = "⭐" if is_popular else "  "
        status = "Overloaded" if row['utilization_percent'] > 100 else ("High" if row['utilization_percent'] > 75 else "Normal")
        
        print(f"{indicator} {i:2}. {row['name']:20} │ Students: {row['student_count']:2} │ "
              f"Capacity: {row['capacity']:2} │ Utilization: {row['utilization_percent']:6.1f}% │ Status: {status}")

def main():
    """Main function"""
    print("\n🎓 FYP System - Deadline and Supervisor Workload Analysis\n")
    
    # Analyze deadline impact
    analyze_deadline_impact()
    
    # Analyze most popular supervisors
    analyze_popular_supervisors()
    
    print("\n" + "="*80)
    print("✅ Analysis Completed\n")

if __name__ == "__main__":
    main()
