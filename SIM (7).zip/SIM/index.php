<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FYP Management System - Login</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
          
        .form-group {
            display: block;
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            color: #6B7280;
            font-weight: 500;
        }
   
        /* Style for error messages */
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 12px;
            border: 1px solid #f5c6cb;
            border-radius: var(--radius);
            margin-bottom: 15px;
            text-align: center;
            font-size: 14px;
        }

        /* Password visibility toggle */
        .password-group {
            position: relative;
            display: flex;
            align-items: center;
        }

        .password-group input {
            flex: 1;
            width: 100%;
            padding: 10px 12px;
            padding-right: 45px;
            border-radius: var(--radius);
            border: 1px solid #d1d5db;
            background: #fff;
            color: #111827;
            font-size: 14px;
            outline: none;
            transition: all 120ms ease;
        }

        .password-group input:focus {
            border-color: #3B82F6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }

        .toggle-password {
            position: absolute;
            right: 12px;
            background: none;
            border: none;
            cursor: pointer;
            color: #1E3A8A;
            font-size: 18px;
            padding: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: opacity 0.2s;
            width: 40px;
            height: 40px;
        }

        .toggle-password:hover {
            opacity: 0.7;
        }

        .toggle-password:focus {
            outline: none;
        }

        /* 为非密码输入框添加统一样式 */
        .form-group input[type="email"] {
            width: 100%;
            padding: 10px 12px;
            border-radius: var(--radius);
            border: 1px solid #d1d5db;
            background: #fff;
            color: #111827;
            font-size: 14px;
            outline: none;
            transition: all 120ms ease;
        }

        .form-group input[type="email"]:focus {
            border-color: #3B82F6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.2);
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <h2>Final Year Project System</h2>
        <div class="button-group">
            <button onclick="setRole('student')" class="active">Student</button>
            <button onclick="setRole('supervisor')">Supervisor</button>
            <button onclick="setRole('committee')">Committee</button>
            <button onclick="setRole('admin')">Admin</button>
        </div>
    </div>
    
    <!-- Login Form -->
    <div class="login-container">
        <h2 id="role-title">Student Login</h2>

        <?php
        if (isset($_GET['success'])) {
            $success = $_GET['success'];
            $message = '';
            switch ($success) {
                case 'registered':
                    $message = 'Registration successful! Please login with your email and password.';
                    break;
                case 'email_verified':
                    $message = 'Email verified successfully! You can now login with your credentials.';
                    break;
                default:
                    $message = 'Operation completed successfully.';
                    break;
            }
            echo '<div style="background-color: #dcfce7; color: #166534; padding: 12px; border: 1px solid #bbf7d0; border-radius: var(--radius); margin-bottom: 15px; text-align: center; font-size: 14px;">' . htmlspecialchars($message) . '</div>';
        }
        
        if (isset($_GET['error'])) {
            $error = $_GET['error'];
            $message = '';
            switch ($error) {
                case 'invalid_credentials':
                    $message = 'Invalid email, password, or role selected.';
                    break;
                case 'empty_fields':
                    $message = 'Please fill in all required fields.';
                    break;
                case 'server_error':
                    $message = 'A server error occurred. Please try again later.';
                    break;
                case 'maintenance_mode':
                    $message = 'System is currently under maintenance. Only admins can login at this time.';
                    break;
                case 'committee_batch_mismatch':
                    $message = 'You are not assigned as a committee member for the current batch. Please contact the administrator.';
                    break;
                default:
                    $message = 'An unknown error occurred.';
                    break;
            }
            echo '<div class="error-message">' . htmlspecialchars($message) . '</div>';
        }
        ?>

        <form id="loginForm" action="login_process.php" method="POST">
            
            <input type="hidden" name="role" id="role-input" value="student">

            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-group">
                    <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    <button type="button" class="toggle-password" id="togglePassword" title="Show/Hide password">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>

        <div class="links">
            <a href="Forgot_password.php">Forgot Password?</a> |
            <a id="register-link" href="register.php">Register</a>
        </div>
    </div>

    <script>
        const roleTitle = document.getElementById("role-title");
        const roleInput = document.getElementById("role-input");
        const navButtons = document.querySelectorAll(".navbar .button-group button");
        const registerLink = document.getElementById("register-link");
        const passwordInput = document.getElementById("password");
        const togglePasswordBtn = document.getElementById("togglePassword");

        // Toggle password visibility
        togglePasswordBtn.addEventListener("click", (e) => {
            e.preventDefault();
            const isPasswordVisible = passwordInput.type === "text";
            passwordInput.type = isPasswordVisible ? "password" : "text";
            
            // Update icon
            const icon = togglePasswordBtn.querySelector("i");
            icon.classList.toggle("fa-eye");
            icon.classList.toggle("fa-eye-slash");
        });

        function setRole(role) {
            // Update the form role and the hidden input's value
            const capitalizedRole = role.charAt(0).toUpperCase() + role.slice(1);
            roleTitle.innerText = capitalizedRole + " Login";
            roleInput.value = role;

            // Update active button style
            navButtons.forEach(btn => {
                if (btn.textContent.toLowerCase() === role) {
                    btn.classList.add("active");
                } else {
                    btn.classList.remove("active");
                }
            });

            // Enable/disable register link based on role
            if (role === 'student') {
                registerLink.style.pointerEvents = 'auto';
                registerLink.style.opacity = '1';
                registerLink.style.cursor = 'pointer';
            } else {
                registerLink.style.pointerEvents = 'none';
                registerLink.style.opacity = '0.5';
                registerLink.style.cursor = 'not-allowed';
            }
        }

        // Set the initial active button on page load
        document.addEventListener('DOMContentLoaded', () => {
            setRole('student');
        });
    </script>

</body>
</html>

