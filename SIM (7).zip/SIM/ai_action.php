<?php
// ai_action.php - Enhanced AI System with Proposal Analysis & Enhanced Q&A
session_start();
header('Content-Type: application/json');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$DEBUG_MODE = false; 

require_once 'db_connect.php'; 

$GEMINI_API_KEY = 'AIzaSyAUbaoqgmmaeOD0V7L7PtoZbgnd14wsEJI'; 

if ($conn->connect_error) {
    $error_message = "DB Connection Failed: " . $conn->connect_error;
    if ($DEBUG_MODE) {
        echo json_encode(['success' => false, 'reply' => $error_message]);
        exit();
    }
}

$inputJSON = file_get_contents('php://input');
$data = json_decode($inputJSON, true);
$user_message = $data['message'] ?? '';
$reset_history = $data['reset'] ?? false;
$request_type = $data['type'] ?? 'chat'; // 'chat', 'analyze_proposal', 'review_proposal'
$proposal_title = $data['proposal_title'] ?? '';
$proposal_text = $data['proposal_text'] ?? ''; 


if (!isset($_SESSION['ai_history'])) {
    $_SESSION['ai_history'] = [];
}

if ($reset_history) {
    $_SESSION['ai_history'] = [];
    echo json_encode(['success' => true, 'reply' => 'AI Session has been reset.']);
    exit();
}

// ======= HANDLE DIFFERENT REQUEST TYPES =======

// 1. PROPOSAL QUALITY ANALYSIS
if ($request_type === 'analyze_proposal') {
    if (empty($proposal_title) || empty($proposal_text)) {
        echo json_encode(['success' => false, 'reply' => 'Please provide proposal title and text for analysis.']);
        exit();
    }
    
    $analysis_prompt = "
You are an expert FYP (Final Year Project) evaluator. Please analyze this student proposal and provide a detailed quality assessment.

**Proposal Title:** $proposal_title

**Proposal Content:**
$proposal_text

---

Please provide a structured analysis with the following:

1. **Overall Score** (1-10): Give a numerical score
2. **Content Completeness** (1-10): Is all necessary information included?
3. **Clarity & Organization** (1-10): Is the proposal well-structured and clear?
4. **Feasibility** (1-10): Is the project realistic and achievable?
5. **Innovation/Uniqueness** (1-10): Does it show creativity and originality?

6. **Strengths** (list 3-5 key strengths)
7. **Weaknesses** (list 3-5 areas that need improvement)
8. **Improvement Suggestions** (specific actionable recommendations)
9. **Questions for Student** (what clarifications are needed?)

Format your response in a clear, structured way that a supervisor can easily read.
Please answer in the SAME LANGUAGE as the proposal.
";
    
    callGeminiAPI($analysis_prompt);
    exit();
}

// 2. PROPOSAL REVIEW (Supervisor Assistance)
if ($request_type === 'review_proposal') {
    if (empty($proposal_title) || empty($proposal_text)) {
        echo json_encode(['success' => false, 'reply' => 'Please provide proposal title and text for review.']);
        exit();
    }
    
    $review_prompt = "
You are an experienced FYP supervisor assistant. Provide feedback for this student proposal that the supervisor can use to give meaningful feedback.

**Proposal Title:** $proposal_title

**Proposal Content:**
$proposal_text

---

As a supervisor assistant, please provide:

1. **Initial Assessment**: What is your first impression? (2-3 sentences)

2. **Recommendation**: Should this be APPROVED, APPROVED_WITH_CHANGES, or REJECTED?

3. **Key Feedback Points** (3-5 items):
   - What works well
   - What needs improvement
   - Specific concerns or suggestions

4. **Suggested Feedback Message** (draft a response the supervisor can send to the student):
   - Be constructive and encouraging
   - Highlight what's good
   - Suggest specific improvements
   - Provide guidance on next steps

5. **Required Changes** (if applicable):
   - List specific changes needed before approval
   - Priority (Critical/High/Medium/Low)

Please make your feedback professional, encouraging, and actionable.
Please answer in the SAME LANGUAGE as the proposal.
";
    
    callGeminiAPI($review_prompt);
    exit();
}

// 3. ENHANCED Q&A CHATBOT (Default)
if (empty($user_message)) {
    echo json_encode(['success' => false, 'reply' => 'Please say something.']);
    exit();
}


$student_id = $_SESSION['user_id'] ?? 0;
$student_name = $_SESSION['name'] ?? 'Student';

if ($DEBUG_MODE) {
    $context_data = "--- DEBUG INFO ---\n";
    $context_data .= "Session User ID: $student_id\n";
    $context_data .= "Session User Name: $student_name\n";
    $context_data .= "Is Authenticated: " . (isset($_SESSION['loggedin']) ? 'YES' : 'NO') . "\n";
    $context_data .= "--- Context Data from Database (if successful) ---\n";
} else {
    $context_data = "Current Date: " . date('Y-m-d') . "\n";
    $context_data .= "User Name: $student_name\n";
}

try {
    if ($student_id > 0) {
        $stmt = $conn->prepare("
            SELECT u_sup.name as supervisor_name, u_sup.email as supervisor_email
            FROM users u_stu
            LEFT JOIN users u_sup ON u_stu.supervisor_id = u_sup.id
            WHERE u_stu.id = ?
        ");
        $stmt->bind_param('i', $student_id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($row = $res->fetch_assoc()) {
            if ($row['supervisor_name']) {
                $context_data .= "My Supervisor is: " . $row['supervisor_name'] . " (" . $row['supervisor_email'] . ")\n";
            } else {
                $context_data .= "I do not have a supervisor assigned yet.\n";
            }
        }
        $stmt->close();

        $stmt = $conn->prepare("
            SELECT title, due_date 
            FROM deadlines 
            WHERE due_date >= CURDATE() 
            ORDER BY due_date ASC 
            LIMIT 3
        ");
        $stmt->execute();
        $res = $stmt->get_result();
        $context_data .= "\nUpcoming Deadlines:\n";
        while ($row = $res->fetch_assoc()) {
            $context_data .= "- " . $row['title'] . " is due on " . $row['due_date'] . "\n";
        }
        $stmt->close();
        
    } else {
        $context_data .= "Warning: User is not logged in or session expired.\n";
    }
} catch (Exception $e) {
    $context_data .= "Database Query Error: " . $e->getMessage() . "\n";
}

// ======= HELPER FUNCTION TO CALL GEMINI API =======
function callGeminiAPI($prompt) {
    global $GEMINI_API_KEY, $DEBUG_MODE;
    
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $GEMINI_API_KEY;
    
    $contents = [
        [
            'role' => 'user',
            'parts' => [
                ['text' => $prompt]
            ]
        ]
    ];
    
    $post_data = json_encode(['contents' => $contents]);
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $response_json = curl_exec($ch);
    
    if (curl_errno($ch)) {
        $error_msg = curl_error($ch);
        curl_close($ch);
        echo json_encode(['success' => false, 'reply' => "Connection Error (CURL): $error_msg"]);
        exit();
    }
    
    curl_close($ch);
    $response_data = json_decode($response_json, true);
    
    if (isset($response_data['candidates'][0]['content']['parts'][0]['text'])) {
        $reply = $response_data['candidates'][0]['content']['parts'][0]['text'];
        echo json_encode(['success' => true, 'reply' => $reply]);
    } else {
        $api_error = $response_data['error']['message'] ?? 'Unknown API Error';
        error_log("Gemini API Error: " . $api_error);
        echo json_encode([
            'success' => false, 
            'reply' => "Sorry, I cannot answer right now. (API/JSON Error: " . htmlspecialchars($api_error) . ")"
        ]);
    }
}

// ENHANCED SYSTEM INSTRUCTION FOR Q&A
$system_instruction = "
You are a helpful academic assistant for a Final Year Project (FYP) system called 'FYP-Bot'.

You are knowledgeable about:
1. **FYP System Process**: Proposal submission, deadline management, supervision assignment
2. **Academic Writing**: Help with report structure, proposal writing, documentation
3. **Project Management**: Timeline planning, task breakdown, progress tracking
4. **Common FYP Issues**: How to handle feedback, what makes a good proposal, time management
5. **System Features**: How to use the FYP system, navigate dashboards, submit work
6. **General Academic Support**: Research guidance, best practices, common mistakes

When answering:
- Be friendly, supportive, and encouraging
- Provide specific, actionable advice
- Ask clarifying questions if needed
- Answer in the SAME LANGUAGE that the user uses (Chinese/English)
- Reference the student's specific context when relevant

--- Context Data from Database ---
$context_data
--- End Context ---
";

$contents = [
    [
        'role' => 'user', 
        'parts' => [
            ['text' => $system_instruction]
        ]
    ]
];

foreach ($_SESSION['ai_history'] as $msg) {
    $contents[] = [
        'role' => $msg['role'],
        'parts' => [
            ['text' => $msg['text']]
        ]
    ];
}

$contents[] = [
    'role' => 'user',
    'parts' => [
        ['text' => $user_message]
    ]
];

if ($DEBUG_MODE) {
    $debug_output = "DEBUG MODE ACTIVE.\n\nSystem Instruction: " . $system_instruction . "\n\nFull Conversation History Sent to AI:\n";
    foreach ($contents as $c) {
        $debug_output .= "[" . strtoupper($c['role']) . "]: " . $c['parts'][0]['text'] . "\n---\n";
    }
    echo json_encode([
        'success' => true, 
        'reply' => $debug_output . "\n(AI API call was skipped.)"
    ]);
    exit();
}

$url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $GEMINI_API_KEY;
$post_data = json_encode(['contents' => $contents]);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response_json = curl_exec($ch);

if (curl_errno($ch)) {
    $error_msg = curl_error($ch);
    curl_close($ch);
    echo json_encode(['success' => false, 'reply' => "Connection Error (CURL): $error_msg"]);
    exit();
}

curl_close($ch);
$response_data = json_decode($response_json, true);

if (isset($response_data['candidates'][0]['content']['parts'][0]['text'])) {
    $reply = $response_data['candidates'][0]['content']['parts'][0]['text'];
    
    $_SESSION['ai_history'][] = [
        'role' => 'user',
        'text' => $user_message
    ];
    $_SESSION['ai_history'][] = [
        'role' => 'model',
        'text' => $reply
    ];
    
    echo json_encode(['success' => true, 'reply' => $reply]);
} else {
    $api_error = $response_data['error']['message'] ?? 'Unknown API Error';
    error_log("Gemini API Error: " . $api_error);
    
    echo json_encode([
        'success' => false, 
        'reply' => "Sorry, I cannot answer right now. (API/JSON Error: " . htmlspecialchars($api_error) . ")"
    ]);
}
?>