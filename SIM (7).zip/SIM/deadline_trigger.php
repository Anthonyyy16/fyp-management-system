<?php

/**
 * deadline_trigger.php
 * This script checks all upcoming deadlines (within the next 7 days)
 * and sends notifications and emails to the related students and groups
 * if notifications have not already been sent.
 *
 * Usage:
 * 1. Run manually:
 *    php deadline_trigger.php
 *
 * 2. Set up a cron job:
 *    0 0 * * * php /path/to/deadline_trigger.php
 *    (runs once daily at midnight)
 *
 * To run automatically, choose one of the following options:
 *
 * Option 1: Windows Task Scheduler (recommended)
 *     Open Task Scheduler (search "Task Scheduler")
 *     Right-click → Create Basic Task...
 *     Fill in the following:
 *       Name: Deadline Trigger
 *       Trigger: Daily → set time to 00:00 (midnight)
 *       Action: Start a program
 *       Program/script: C:\php\php.exe  (replace with your PHP executable path)
 *       Add arguments (optional): "d:\Final year project\Coding\RealCoding\deadline_trigger.php"
 *       Start in (optional): "d:\Final year project\Coding\RealCoding\"
 *     Click "Finish"
 *
 * Option 2: Linux/Mac Cron
 *     Edit crontab:
 *       crontab -e
 *     Add the following line to run daily at midnight:
 *       0 0 * * * /usr/bin/php /path/to/deadline_trigger.php
 */

require_once 'db_connect.php';
require_once 'notification_functions.php';
require_once 'email_config.php';


error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn->query("SET SESSION sql_mode=''");
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);


function log_message($message)
{
    $timestamp = date('Y-m-d H:i:s');
    echo "[{$timestamp}] {$message}\n";
    error_log("[{$timestamp}] {$message}");
}

try {
    log_message("========== Deadline Trigger Started ==========");

    
    $today = date('Y-m-d');
    $deadline_start = strtotime($today);
    $deadline_end = strtotime($today . ' +7 days');

    $deadline_start_str = date('Y-m-d', $deadline_start);
    $deadline_end_str = date('Y-m-d', $deadline_end);

    log_message("Checking deadlines between {$deadline_start_str} and {$deadline_end_str}");

    
    $stmt = $conn->prepare("
        SELECT DISTINCT
            d.id as deadline_id,
            d.title,
            d.description,
            d.due_date,
            d.batch_year,
            g.id as group_id,
            g.supervisor_id,
            GROUP_CONCAT(DISTINCT u.id) as student_ids,
            GROUP_CONCAT(DISTINCT u.name) as student_names,
            GROUP_CONCAT(DISTINCT u.email) as student_emails
        FROM deadlines d
        LEFT JOIN users u ON u.batch_year = d.batch_year AND u.role = 'student'
        LEFT JOIN groups g ON u.group_id = g.id
        WHERE DATE(d.due_date) >= ? AND DATE(d.due_date) <= ?
        GROUP BY d.id
        ORDER BY d.due_date ASC
    ");

    $stmt->bind_param('ss', $deadline_start_str, $deadline_end_str);
    $stmt->execute();
    $result = $stmt->get_result();
    $deadlines = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    if (empty($deadlines)) {
        log_message("No deadlines found in the next 7 days.");
        log_message("========== Deadline Trigger Completed ==========\n");
        exit(0);
    }

    log_message("Found " . count($deadlines) . " deadline(s) in the next 7 days");

    
    foreach ($deadlines as $deadline) {
        $deadline_id = $deadline['deadline_id'];
        $title = $deadline['title'];
        $due_date = $deadline['due_date'];
        $batch_year = $deadline['batch_year'];
        $student_ids = $deadline['student_ids'];
        $student_names = $deadline['student_names'];
        $student_emails = $deadline['student_emails'];

        log_message("Processing deadline: {$title} (batch: {$batch_year}, due: {$due_date})");

        
        if (empty($student_ids)) {
            log_message("  ⚠ Skipping: No students assigned to this deadline");
            continue;
        }

        
        $stmt_check = $conn->prepare("
            SELECT COUNT(*) as count
            FROM notifications
            WHERE type = 'deadline_reminder' 
            AND message LIKE ?
            AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)
        ");
        $search_pattern = "%{$title}%";
        $stmt_check->bind_param('s', $search_pattern);
        $stmt_check->execute();
        $check_result = $stmt_check->get_result()->fetch_assoc();
        $stmt_check->close();

        if ($check_result['count'] > 0) {
            log_message("  ✓ Already notified in the last 24 hours (skipping)");
            continue;
        }

        
        $days_until = ceil((strtotime($due_date) - time()) / (24 * 60 * 60));

        log_message("  Days until deadline: {$days_until}");

        
        if (!empty($student_ids) && !empty($student_emails)) {
            $student_id_array = explode(',', $student_ids);
            $student_name_array = explode(',', $student_names);
            $student_email_array = explode(',', $student_emails);

            foreach ($student_id_array as $idx => $student_id) {
                $student_id = trim($student_id);
                $student_name = isset($student_name_array[$idx]) ? trim($student_name_array[$idx]) : 'Student';
                $student_email = isset($student_email_array[$idx]) ? trim($student_email_array[$idx]) : '';

                if (empty($student_email)) {
                    log_message("  ⚠ No email for student {$student_name}");
                    continue;
                }

                
                $formatted_due_date = date('M d, Y H:i', strtotime($due_date));
                $notif_message = "Reminder: The deadline for '{$title}' is approaching in {$days_until} day(s).\n\nDue Date: {$formatted_due_date}\n\nPlease ensure you submit your work before the deadline.";

                try {
                    $result = createNotificationAndEmail(
                        $conn,
                        $student_id,
                        null,  
                        'deadline_reminder',
                        null,  // submission_id
                        $notif_message,
                        $student_email,
                        null   // appointment_id
                    );

                    if ($result) {
                        log_message("  ✓ Notification sent to {$student_name} ({$student_email})");
                    } else {
                        log_message("  ✗ Failed to send notification to {$student_name}");
                    }
                } catch (Exception $e) {
                    log_message("  ✗ Error sending to {$student_name}: " . $e->getMessage());
                }
            }
        }
    }

    log_message("========== Deadline Trigger Completed Successfully ==========\n");
} catch (Exception $e) {
    log_message("✗ FATAL ERROR: " . $e->getMessage());
    log_message("========== Deadline Trigger Failed ==========\n");
    exit(1);
} finally {
    $conn->close();
}
